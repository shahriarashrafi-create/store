/* Store v0.50 — approved Steps 41–50: notifications, personalization, campaigns, API-ready catalog, educational content, production readiness. */
(function(){
  const PREV_RENDER_50=render;
  const PREV_SETTINGS=settings;
  const PREV_SKIN_PROFILE=skinProfile;
  const PREV_SEARCH_PAGE=searchPage;
  const PREV_ACTIVE_BANNER=activeBanner;
  const PREV_BANNER_TARGET=bannerTarget;

  const ARTICLES=[
    {id:'skin-type',title:'چطور نوع پوستت را بهتر بشناسی؟',excerpt:'چند نشانه ساده برای شناخت بهتر پوست و انتخاب آگاهانه‌تر محصول.',category:'مراقبت پوست',tags:['پوست خشک','پوست چرب','پوست مختلط','راهنمای انتخاب'],minutes:4,cover:'onboarding-discover.svg',body:[['شناخت اولیه','نوع پوست می‌تواند روی انتخاب شوینده، آبرسان و ضدآفتاب اثر بگذارد. بهتر است رفتار پوست را در چند روز و بدون تغییرات شدید روتین مشاهده کنی.'],['به چه چیزهایی توجه کنیم؟','احساس کشیدگی بعد از شست‌وشو، برق افتادن بخش‌های مختلف صورت و واکنش به محصولات از نشانه‌های قابل توجه هستند.'],['یادآوری مهم','این راهنما تشخیص پزشکی نیست. اگر تحریک، التهاب یا مشکل پایدار داری، بررسی تخصصی توسط پزشک یا متخصص پوست مناسب‌تر است.']],related:[2,4,1]},
    {id:'dry-routine',title:'روتین ساده برای پوست خشک',excerpt:'یک روتین کوتاه و قابل‌فهم برای حفظ رطوبت پوست خشک.',category:'روتین‌ها',tags:['خشکی','آبرسان','پوست خشک'],minutes:5,cover:'onboarding-details.svg',body:[['شروع ساده','روتین لازم نیست شلوغ باشد. شوینده ملایم، آبرسان مناسب و ضدآفتاب معمولاً پایه یک روتین روزانه هستند.'],['ترتیب پیشنهادی','شوینده → محصول آبرسان/مرطوب‌کننده → ضدآفتاب در روز.'],['نکته Store','محصول جدید را مرحله‌ای وارد روتین کن تا اگر حساسیتی ایجاد شد، علت آن قابل تشخیص‌تر باشد.']],related:[2,4,1]},
    {id:'sunscreen-guide',title:'راهنمای استفاده بهتر از ضدآفتاب',excerpt:'چه زمانی استفاده کنیم و چرا تمدید ضدآفتاب مهم است؟',category:'راهنمای انتخاب',tags:['ضدآفتاب','روتین روز'],minutes:3,cover:'hero-products-v2.svg',body:[['زمان استفاده','ضدآفتاب معمولاً آخرین مرحله روتین مراقبتی صبح است و باید قبل از قرار گرفتن در معرض آفتاب استفاده شود.'],['تمدید','میزان نیاز به تمدید به شرایط محیط، تعریق و مدت حضور در فضای باز بستگی دارد.'],['اطلاعات محصول','همیشه دستور مصرف رسمی همان محصول را در اولویت قرار بده.']],related:[1]},
    {id:'hair-routine',title:'روتین ساده برای موهای آسیب‌دیده',excerpt:'چطور شست‌وشو و مراقبت بعد از حمام را ساده و منظم کنیم.',category:'مراقبت مو',tags:['موی آسیب‌دیده','خشکی مو'],minutes:4,cover:'consultation.svg',body:[['شست‌وشوی ملایم','نوع شامپو و دفعات شست‌وشو باید با شرایط مو و کف سر هماهنگ باشد.'],['مراقبت ساقه','ماسک یا محصول مراقبتی روی ساقه مو می‌تواند بخشی از روتین باشد؛ دستور محصول را رعایت کن.'],['چه زمانی مراجعه کنیم؟','ریزش قابل‌توجه یا تغییر ناگهانی وضعیت مو نیازمند بررسی حرفه‌ای است.']],related:[5,8]},
    {id:'ingredients-basics',title:'ترکیبات محصول را چطور بخوانیم؟',excerpt:'به‌جای ترس از اسم‌های پیچیده، بر اطلاعات معتبر و کاربرد محصول تمرکز کنیم.',category:'ترکیبات',tags:['ترکیبات','راهنمای انتخاب'],minutes:6,cover:'onboarding-details.svg',body:[['فهرست ترکیبات چیست؟','فهرست INCI نام استاندارد ترکیبات آرایشی و بهداشتی است. وجود یک ترکیب به‌تنهایی برای نتیجه‌گیری درباره کیفیت محصول کافی نیست.'],['ادعاهای محصول','ادعاهای محصول باید با اطلاعات رسمی و معتبر هماهنگ باشند؛ Store نباید ادعای درمان قطعی ایجاد کند.'],['حساسیت‌ها','اگر سابقه حساسیت مشخص داری، ترکیبات مرتبط را با دقت بیشتری بررسی کن.']],related:[3,6,7]}
  ];
  window.STORE_ARTICLES=ARTICLES;

  function ensureStep50State(){
    state.notifications=Array.isArray(state.notifications)?state.notifications:[];
    state.notificationPreferences={order_updates:true,payment_updates:true,shipping_updates:true,promotions:false,new_products:false,reminders:false,...(state.notificationPreferences||{})};
    state.personalizationEnabled=state.personalizationEnabled!==false;
    state.recommendationFeedback=state.recommendationFeedback||{};
    state.campaignAnalytics=state.campaignAnalytics||{};
    state.articleId=state.articleId||null;
    state.contentQuery=state.contentQuery||'';
    state.apiStatus=state.apiStatus||'local';
    state.lastApiSyncAt=state.lastApiSyncAt||null;
    state.runtimeErrors=Array.isArray(state.runtimeErrors)?state.runtimeErrors.slice(-20):[];
  }

  function uid(prefix='n'){return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}
  function nowFa(ts){try{return new Date(ts).toLocaleString('fa-IR')}catch(e){return''}}

  const NotificationService={
    add(input){ensureStep50State();const dedupe=input.dedupeKey&&state.notifications.find(n=>n.dedupeKey===input.dedupeKey);if(dedupe)return dedupe;const n={id:uid('ntf'),type:'info',title:'Store',body:'',targetType:null,targetId:null,priority:'info',isRead:false,createdAt:Date.now(),...input};state.notifications.unshift(n);state.notifications=state.notifications.slice(0,100);save();return n},
    unread(){ensureStep50State();return state.notifications.filter(n=>!n.isRead).length},
    markRead(id){const n=state.notifications.find(x=>x.id===id);if(n)n.isRead=true;save()},
    markAll(){state.notifications.forEach(n=>n.isRead=true);save();render()},
    clearRead(){state.notifications=state.notifications.filter(n=>!n.isRead);save();render()},
    open(id){const n=state.notifications.find(x=>x.id===id);if(!n)return;n.isRead=true;save();if(n.targetType==='order'&&n.targetId){state.selectedOrderId=n.targetId;go('orderDetail');return}if(n.targetType==='product'&&n.targetId){go('product',{productId:Number(n.targetId)});return}if(n.targetType==='campaign'){go('products');return}if(n.targetType==='article'&&n.targetId){openArticle(n.targetId);return}render()}
  };
  window.NotificationService=NotificationService;
  window.notificationUnreadCount=()=>NotificationService.unread();
  window.notificationBadgeMarkup=function(){const c=NotificationService.unread();return c?`<b class="notificationBadge">${c>99?'99+':num(c)}</b>`:''};

  function syncOrderNotifications(){
    ensureStep50State();
    for(const o of state.orders||[]){
      for(const ev of o.statusEvents||[]){
        const key=`order:${o.id}:${ev.key}:${ev.at||''}`;
        let type='order',title='به‌روزرسانی سفارش',body=ev.label||o.status||'وضعیت سفارش تغییر کرد';
        if(ev.key==='payment_confirmation'){type='payment';title='پرداخت سفارش';body='پرداخت سفارش تأیید شد.'}
        if(ev.key==='shipped'){type='shipping';title='سفارش ارسال شد';body='سفارش شما تحویل شرکت حمل شده است.'}
        if(ev.key==='delivered'){type='shipping';title='سفارش تحویل شد';body='وضعیت سفارش به تحویل‌شده تغییر کرد.'}
        NotificationService.add({dedupeKey:key,type,title,body,targetType:'order',targetId:o.id,priority:['cancelled','rejected'].includes(ev.key)?'critical':'action',createdAt:ev.at||o.createdAt||Date.now()});
      }
      if(o.paymentStatus==='rejected')NotificationService.add({dedupeKey:`pay-rejected:${o.id}`,type:'payment',title:'پرداخت تأیید نشد',body:o.payment?.rejectionReason||'رسید پرداخت نیاز به اصلاح یا ارسال مجدد دارد.',targetType:'order',targetId:o.id,priority:'critical'});
      if(o.paymentStatus==='pending_confirmation')NotificationService.add({dedupeKey:`pay-pending:${o.id}`,type:'payment',title:'رسید پرداخت ثبت شد',body:'رسید شما ثبت شده و در انتظار بررسی است.',targetType:'order',targetId:o.id,priority:'info'});
    }
  }

  function notificationIcon(type){return type==='shipping'?'truck':type==='payment'?'bank-card':type==='promotion'?'coupon':type==='article'?'info':'bell'}
  function notificationCard(n){return `<button class="notificationItem ${n.isRead?'read':'unread'}" onclick="NotificationService.open('${n.id}')"><span class="notificationIcon">${icon(notificationIcon(n.type),'icon-md')}</span><span class="notificationCopy"><span class="notificationTop"><b>${escapeHtml(n.title)}</b><small>${escapeHtml(nowFa(n.createdAt))}</small></span><span>${escapeHtml(n.body)}</span></span>${!n.isRead?'<i class="unreadDot"></i>':''}</button>`}
  notifications=function(){ensureStep50State();const list=[...state.notifications].sort((a,b)=>Number(b.createdAt)-Number(a.createdAt));const action=list.length?`<button class="textLink" onclick="NotificationService.markAll()">خواندن همه</button>`:'';return `${header(false)}<main class="pageIn notificationsPage">${pageTitle('اعلان‌ها',action)}<div class="notificationTabs"><button class="active">همه</button><button onclick="go('notificationSettings')">تنظیمات</button></div>${list.length?`<div class="notificationList">${list.map(notificationCard).join('')}</div>`:emptyState('empty-orders.svg','اعلان جدیدی نداری','وضعیت سفارش‌ها و پیام‌های مهم Store اینجا نمایش داده می‌شود.','','')}</main>`};

  window.toggleNotificationPref=function(key){state.notificationPreferences[key]=!state.notificationPreferences[key];save();render()};
  function prefRow(key,title,sub,locked=false){const on=state.notificationPreferences[key]!==false;return `<label class="prefRow"><span><b>${title}</b><small>${sub}</small></span><button class="switch ${on?'on':''}" ${locked?'disabled':''} onclick="event.preventDefault();${locked?'':`toggleNotificationPref('${key}')`}"><i></i></button></label>`}
  window.requestBrowserNotifications=async function(){if(!('Notification' in window)){toast('اعلان مرورگر در این محیط در دسترس نیست');return}try{const p=await Notification.requestPermission();toast(p==='granted'?'اعلان مرورگر فعال شد':'مجوز اعلان داده نشد')}catch(e){toast('فعال‌سازی اعلان انجام نشد')}};
  window.notificationSettingsPage=function(){return `${header(false)}<main class="pageIn">${pageTitle('تنظیمات اعلان‌ها')}<section class="panel prefPanel"><h3>عملیاتی</h3>${prefRow('order_updates','سفارش‌ها','ثبت و تغییر وضعیت سفارش',true)}${prefRow('payment_updates','پرداخت','تأیید، رد یا نیاز به رسید جدید',true)}${prefRow('shipping_updates','ارسال','ارسال و رهگیری مرسوله',true)}</section><section class="panel prefPanel"><h3>بازاریابی</h3>${prefRow('promotions','تخفیف‌ها و کمپین‌ها','پیشنهادهای بازاریابی اختیاری')}${prefRow('new_products','محصولات جدید','معرفی محصولات تازه')}${prefRow('reminders','یادآوری‌ها','یادآوری‌های اختیاری Store')}</section><button class="btn outline block" onclick="requestBrowserNotifications()">فعال‌سازی Push مرورگر</button><div class="notice">اعلان‌های داخل اپ منبع اصلی وضعیت سفارش هستند. Push فقط برای اطلاع‌رسانی سریع و با اجازه کاربر استفاده می‌شود.</div></main>`};

  function normalizeText(s=''){return String(s).replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/\u200c/g,' ').replace(/\s+/g,' ').trim().toLowerCase()}
  function preferenceTokens(){const x=state.user?.skinProfile||{},raw=[x.skinType,x.hairType,x.concerns,state.need,...(state.favs||[]).map(id=>products.find(p=>p.id===id)?.need)].filter(Boolean).join(' ');return normalizeText(raw).split(/[،,\s]+/).filter(t=>t.length>2)}
  function recommendationScore(p){let score=0;const tokens=preferenceTokens(),hay=normalizeText([p.skinType,p.need,p.subCategory,p.desc,...(p.features||[])].join(' '));for(const t of tokens)if(hay.includes(t))score+=3;if(state.favs.includes(p.id))score+=1;if(Number(p.stock||0)>0)score+=1;if(p.isNew)score+=.2;return score}
  function recommendationReason(p){const profile=state.user?.skinProfile||{};if(profile.skinType&&normalizeText([p.skinType,p.desc,p.need].join(' ')).includes(normalizeText(profile.skinType)))return `مرتبط با پوست ${profile.skinType}`;if(profile.hairType&&p.category==='مو')return `مرتبط با پروفایل موی شما`;if((state.favs||[]).some(id=>products.find(x=>x.id===id)?.need===p.need))return `بر اساس علاقه‌مندی‌های شما`;return 'انتخاب مرتبط از Store'}
  window.personalizedProducts=function(){const list=products.filter(p=>Number(p.stock||0)>0);if(!state.user||!state.personalizationEnabled)return [...list].sort((a,b)=>Number(b.stock)-Number(a.stock)).slice(0,4);return [...list].sort((a,b)=>recommendationScore(b)-recommendationScore(a)||Number(b.isNew)-Number(a.isNew)).slice(0,4)};
  window.personalizedHomeSection=function(){if(!state.user||!state.personalizationEnabled)return'';const list=personalizedProducts();return `<section class="section homeSection personalizedSection">${sectionHead('پیشنهاد برای شما','بر اساس پروفایل و فعالیت‌های شما')}<div class="productRow">${list.map(p=>`<div class="recommendationWrap">${productCard(p,true)}<span class="recommendReason">${escapeHtml(recommendationReason(p))}</span></div>`).join('')}</div></section>`};

  skinProfile=function(){if(!state.user)return PREV_SKIN_PROFILE();const x=state.user.skinProfile||{};return infoPage('پروفایل پوست و مو','consultation',`<div class="notice">این اطلاعات اختیاری است و برای پیشنهاد بهتر محصول استفاده می‌شود؛ تشخیص پزشکی نیست.</div><div class="form" style="margin-top:12px"><div class="field"><label>نوع پوست</label><select id="skinProfileType"><option value="">انتخاب نشده</option>${['چرب','خشک','مختلط','معمولی','حساس'].map(v=>`<option ${x.skinType===v?'selected':''}>${v}</option>`).join('')}</select></div><div class="field"><label>نوع مو</label><select id="hairProfileType"><option value="">انتخاب نشده</option>${['خشک','چرب','معمولی','رنگ‌شده','آسیب‌دیده'].map(v=>`<option ${x.hairType===v?'selected':''}>${v}</option>`).join('')}</select></div><div class="field"><label>نیازها یا حساسیت‌ها</label><textarea id="profileConcerns" placeholder="اختیاری">${escapeHtml(x.concerns||'')}</textarea></div><label class="prefRow inlinePref"><span><b>پیشنهادهای شخصی‌سازی‌شده</b><small>با استفاده از پروفایل، خریدها و علاقه‌مندی‌ها</small></span><button class="switch ${state.personalizationEnabled?'on':''}" onclick="event.preventDefault();state.personalizationEnabled=!state.personalizationEnabled;save();render()"><i></i></button></label><button class="btn primary block" onclick="saveSkinProfile()">ذخیره پروفایل</button><button class="btn outline block" onclick="clearSkinProfile()">حذف اطلاعات پوست و مو</button></div>`)};

  const CampaignService={
    impression(id){if(!id)return;const k=`campaign-seen:${id}`;if(sessionStorage.getItem(k))return;sessionStorage.setItem(k,'1');const x=state.campaignAnalytics[id]||{impressions:0,clicks:0};x.impressions++;state.campaignAnalytics[id]=x;save()},
    click(id){if(!id)return;const x=state.campaignAnalytics[id]||{impressions:0,clicks:0};x.clicks++;state.campaignAnalytics[id]=x;save();try{StoreApi.event?.({event:'campaign_click',campaign_id:id})}catch(e){}}
  };
  window.CampaignService=CampaignService;
  activeBanner=function(type){const b=PREV_ACTIVE_BANNER(type);if(b)CampaignService.impression(b.id);return b};
  window.trackCampaignClick=id=>CampaignService.click(id);
  bannerTarget=function(b){const target=PREV_BANNER_TARGET(b);return b?.id?`trackCampaignClick('${String(b.id).replace(/'/g,"\\'")}');${target}`:target};

  function articleCard(a){const search=normalizeText([a.title,a.excerpt,a.tags.join(' ')].join(' '));return `<article class="articleCard" data-search="${escapeHtml(search)}" onclick="openArticle('${a.id}')"><img class="asset" src="${A}illustrations/${a.cover}" alt=""><div><span>${escapeHtml(a.category)} · ${num(a.minutes)} دقیقه</span><h3>${escapeHtml(a.title)}</h3><p>${escapeHtml(a.excerpt)}</p></div></article>`}
  window.educationalHomeSection=function(){return `<section class="section homeSection educationHome">${sectionHead('راهنمای مراقبت','آموزش کوتاه برای انتخاب آگاهانه‌تر','مشاهده همه',"go('articles')")}<div class="articleHorizontal">${ARTICLES.slice(0,3).map(articleCard).join('')}</div></section>`};
  window.openArticle=function(id){state.articleId=id;save();go('article',{articleId:id})};
  window.filterArticlesLocal=function(value){state.contentQuery=value;save();const q=normalizeText(value);document.querySelectorAll('.articlesPage .articleCard').forEach(el=>el.hidden=!!q&&!String(el.dataset.search||'').includes(q))};
  window.articlesPage=function(){return `${header(false)}<main class="pageIn articlesPage">${pageTitle('راهنمای مراقبت')}<div class="contentSearch"><input value="${escapeHtml(state.contentQuery||'')}" placeholder="جست‌وجو در راهنماها..." oninput="filterArticlesLocal(this.value)"></div><div class="articleGrid">${ARTICLES.map(articleCard).join('')}</div></main>`};
  window.articlePage=function(){const a=ARTICLES.find(x=>x.id===state.articleId)||ARTICLES[0];const related=products.filter(p=>a.related.includes(p.id));return `${header(false)}<main class="pageIn articlePage">${pageTitle('راهنمای Store')}<article class="articleDetail"><img class="articleCover asset" src="${A}illustrations/${a.cover}" alt=""><span class="articleMeta">${escapeHtml(a.category)} · ${num(a.minutes)} دقیقه مطالعه</span><h1>${escapeHtml(a.title)}</h1><p class="articleLead">${escapeHtml(a.excerpt)}</p>${a.body.map(([h,p])=>`<section><h2>${escapeHtml(h)}</h2><p>${escapeHtml(p)}</p></section>`).join('')}<div class="notice">مطالب آموزشی Store جایگزین تشخیص یا درمان پزشکی نیستند.</div></article>${related.length?`<section class="section">${sectionHead('محصولات مرتبط')}<div class="productRow">${related.map(p=>productCard(p,true)).join('')}</div></section>`:''}</main>`};
  window.educationalSearchSection=function(){const q=normalizeText(state.query||'');if(!q)return'';const list=ARTICLES.filter(a=>normalizeText([a.title,a.excerpt,a.tags.join(' ')].join(' ')).includes(q)).slice(0,4);return list.length?`<section class="section contentResults">${sectionHead('راهنماهای مرتبط',`${num(list.length)} مطلب`)}<div class="articleGrid compactArticles">${list.map(articleCard).join('')}</div></section>`:''};
  searchPage=function(){let html=PREV_SEARCH_PAGE();const extra=educationalSearchSection();return extra?html.replace('</main>',`${extra}</main>`):html};

  const PREV_ABOUT=about;
  about=function(){return infoPage('درباره Store','info',`<p><strong>Store</strong> یک فروشگاه تخصصی پوست و مو با هویت «${BRAND.tagline}» است.</p><p class="brandRule">این Build نقشه‌راه تأییدشده <strong>قدم‌های ۱ تا ۶۰</strong> را پوشش می‌دهد: فروشگاه کامل، Backend/API واقعی، Auth، PostgreSQL، Admin مستقل، سفارش و پرداخت Server-side، Object Storage، اتصال API، Deploy، E2E و Release Candidate.</p><div class="summaryRow"><span>نسخه</span><b>${escapeHtml(window.StoreConfig.version)}</b></div><div class="summaryRow"><span>محیط</span><b>${escapeHtml(window.StoreConfig.environment)}</b></div>`)};

  settings=function(){return infoPage('تنظیمات برنامه','settings',`<div class="settingsStack"><button class="settingsAction" onclick="go('notificationSettings')">${icon('bell','icon-md')}<span><b>تنظیمات اعلان‌ها</b><small>اعلان عملیاتی و بازاریابی</small></span></button><button class="settingsAction" onclick="go('skinProfile')">${icon('consultation','icon-md')}<span><b>شخصی‌سازی</b><small>${state.personalizationEnabled?'فعال':'غیرفعال'} · پروفایل پوست و مو</small></span></button><button class="settingsAction" onclick="go('articles')">${icon('info','icon-md')}<span><b>راهنمای مراقبت</b><small>مقالات و آموزش‌های Store</small></span></button><button class="settingsAction" onclick="replayOnboarding()">${icon('refresh','icon-md')}<span><b>مشاهده دوباره معرفی Store</b><small>Onboarding سه‌مرحله‌ای را دوباره ببین</small></span></button><div class="notice"><b>وضعیت داده:</b> ${state.apiStatus==='connected'?'متصل به API':'داده محلی / حالت آزمایشی'}${state.lastApiSyncAt?` · آخرین همگام‌سازی ${escapeHtml(nowFa(state.lastApiSyncAt))}`:''}</div></div>`)};

  const CatalogService={
    async hydrate(){if(!window.StoreApi?.baseUrl)return false;try{await StoreApi.refreshSession().catch(()=>false);if(AuthService.currentUser())state.user=AuthService.currentUser();const [p,c,b]=await Promise.all([StoreApi.products(),StoreApi.categories(),StoreApi.campaigns()]);if(Array.isArray(p)&&p.length){products.splice(0,products.length,...p.map(normalizeApiProduct))}if(Array.isArray(c)&&c.length){categories.splice(0,categories.length,...c.map(x=>({id:x.id,name:x.name,title:x.name,slug:x.slug,image:x.imageKey||x.image||'needs.svg',parentId:x.parentId||null,order:x.sortOrder||0,active:x.active!==false,description:x.description||''})))}if(Array.isArray(b)&&b.length){banners.splice(0,banners.length,...b)}state.apiStatus='connected';state.lastApiSyncAt=Date.now();save();render();return true}catch(e){state.apiStatus='local';save();return false}}
  };
  window.CatalogService=CatalogService;

  function logRuntimeError(kind,message){ensureStep50State();state.runtimeErrors.push({kind,message:String(message||'unknown').slice(0,400),at:Date.now()});state.runtimeErrors=state.runtimeErrors.slice(-20);save();try{StoreApi.event?.({event:'client_error',kind,message:String(message||'').slice(0,400)})}catch(e){}}
  window.addEventListener('error',e=>logRuntimeError('js',e.message));
  window.addEventListener('unhandledrejection',e=>logRuntimeError('promise',e.reason?.message||String(e.reason||'promise rejection')));

  const oldHome=home;
  home=function(){let html=oldHome();const extras=`${personalizedHomeSection()}${educationalHomeSection()}`;return html.replace('</main><nav class="bottomNav"',`${extras}</main><nav class="bottomNav"`)};

  render=function(){ensureStep50State();syncOrderNotifications();if(state.page==='notificationSettings'){document.body.style.overflow='';document.body.classList.add('subpage');document.getElementById('app').innerHTML=notificationSettingsPage();updateNetworkStatus();return}if(state.page==='articles'){document.body.style.overflow='';document.body.classList.add('subpage');document.getElementById('app').innerHTML=articlesPage();updateNetworkStatus();return}if(state.page==='article'){document.body.style.overflow='';document.body.classList.add('subpage');document.getElementById('app').innerHTML=articlePage();updateNetworkStatus();return}PREV_RENDER_50();};

  Object.assign(window,{articlesPage,articlePage,notificationSettingsPage});
  ensureStep50State();syncOrderNotifications();save();render();
  setTimeout(()=>CatalogService.hydrate(),600);
})();
