# Store Backend Scaffold

This folder remains an architecture scaffold; the APK still runs local demo data.

Target production backend decisions through Step 13:

- Node.js REST API
- PostgreSQL
- Object storage for receipt images
- Mobile number + password authentication initially
- Passwords must be hashed server-side using a production-grade password hashing algorithm (for example Argon2id or bcrypt with appropriate parameters); never store plaintext passwords
- Session/access + refresh token design
- Login rate limiting and failed-attempt protection
- SMS/OTP can be added later without replacing the frontend navigation model
- Password reset is support-assisted until a verified OTP/email flow exists
