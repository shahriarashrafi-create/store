# Implementation — Steps 14–20

## Step 14 — Profile

- Guest Profile با CTA ورود و دسترسی به پشتیبانی، قوانین، درباره Store و Onboarding
- Profile کاربر با نام، شماره Mask شده، Tier، Points و Progress
- Quick Actions و خلاصه وضعیت سفارش‌ها
- گروه‌بندی منوها: حساب، خدمات، تنظیمات و پشتیبانی
- اطلاعات شخصی، پروفایل پوست/مو، امنیت و حذف حساب به‌صورت مسیرهای مستقل

## Step 15 — Header

- Header مشترک ولی Contextual برای Home / Products / Cart / Profile
- Search از Header جدا و در محتوای Home/Products قرار گرفت
- Subpage Header با Back + Title + Action اختیاری
- Sticky Header و Safe Area CSS
- Compact شدن Header Home هنگام Scroll

## Step 16 — Home

ترتیب Home:

1. Header
2. Search
3. Hero
4. Categories
5. Needs
6. Best sellers / popular fallback
7. Consultation banner
8. Special offers
9. Campaign banner
10. New products
11. Loyalty card برای کاربر واردشده

برای جلوگیری از ادعای نادرست پرفروش، اگر داده سفارش وجود نداشته باشد عنوان بخش به «محبوب‌های Store» تغییر می‌کند.

## Step 17 — Banners

`data.js` دارای مدل Banner با فیلدهای زیر است:

- id / type
- title / subtitle
- image
- ctaText / target
- startAt / endAt
- active / priority / position

در MVP فقط یک Hero ثابت نمایش داده می‌شود و Slider وجود ندارد.

## Step 18 — Categories

- دسته‌های سطح اصلی با slug پایدار
- زیرشاخه‌ها با parentId
- نمایش فقط دسته‌هایی که محصول فعال دارند
- Product دارای آرایه categories و needs برای آماده‌سازی چنددسته‌ای
- Deep Link نمونه: `#category/skin-care`

## Step 19 — Product Card

- Standard و Compact از یک تابع مشترک
- تصویر با aspect کنترل‌شده
- نام دوخطی
- قیمت و قیمت قبلی
- حداکثر دو Badge
- سه وضعیت موجودی: موجود / محدود / ناموجود
- CTA هوشمند: Add to Cart برای محصول ساده، Product Detail برای Variant

## Step 20 — Product List

- Grid دو ستون موبایل و سه ستون در عرض‌های بزرگ‌تر
- Category Tabs و Subcategory Chips
- Filter/Sort sticky
- Active Filter Chips + Clear all
- Sort: پیشنهادی، پرفروش‌ترین، جدیدترین، ارزان‌ترین، گران‌ترین، بیشترین تخفیف
- Empty State
- بارگذاری تدریجی با IntersectionObserver
- visibleLimit و Scroll/Filter state در Navigation حفظ می‌شود

## Backend readiness

`backend/sql/schema.sql` برای Category، Need، Banner، Profile و روابط Product آماده شده است. پنل مدیریت اصلی طبق Roadmap در Step 45 ساخته خواهد شد.
