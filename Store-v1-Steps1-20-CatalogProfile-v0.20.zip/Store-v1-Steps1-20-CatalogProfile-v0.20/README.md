# Store v0.20 — Steps 1–20

این بسته ادامه مستقیم نسخه v0.13 است و تصمیم‌های تأییدشده قدم‌های ۱۴ تا ۲۰ را روی معماری قبلی اعمال می‌کند.

## تغییرات اصلی

- پروفایل کامل برای مهمان و کاربر واردشده، با گروه‌بندی حساب، خدمات، تنظیمات و پشتیبانی
- Mask شماره موبایل، سطح وفاداری، امتیاز و پیشرفت تا سطح بعد
- خلاصه وضعیت سفارش‌ها و Quick Actionهای سفارش، علاقه‌مندی، مشاوره و امتیاز
- اطلاعات شخصی قابل ویرایش، پروفایل اختیاری پوست و مو، تغییر رمز محلی و مسیر جدا برای حذف حساب
- Header زمینه‌محور و Sticky با Safe Area و حالت Compact در Home
- Home بازطراحی‌شده با Search، Hero ثابت، دسته‌بندی‌های دارای محصول، Needها، محصولات محبوب/پرفروش، مشاوره، پیشنهاد ویژه، کمپین و محصولات جدید
- مدل Banner آماده پنل مدیریت با type، CTA، target، start/end، active، priority و position
- مدل Category چندسطحی و slug-based، مخفی‌سازی دسته‌های خالی و زیرشاخه‌های قابل انتخاب
- Product Card واحد در دو حالت Standard/Compact، با موجودی، تخفیف، علاقه‌مندی و CTA هوشمند برای Variant
- Product List دو/سه‌ستونه Responsive، Active Filter Chips، Sort کامل، Empty State و بارگذاری تدریجی
- Deep Link دسته‌ها با slug پایدار
- Schema آینده Backend برای users/categories/needs/products/banners و رابطه‌های چنددسته‌ای

## Build

ZIP را در ریشه Repository `store` قرار دهید. Workflow فعلی GitHub Actions پروژه Android Gradle را پیدا کرده و Debug APK را می‌سازد.

- versionCode: 20
- versionName: `0.20-steps1-20-catalog-profile`

Backend همچنان Scaffold است و Runtime واقعی فروشگاه هنوز به API/Database متصل نشده است.
