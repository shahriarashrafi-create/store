const CACHE='store-v020-shell';
const CORE=['./','./index.html','./css/tokens.css','./css/components.css','./css/pages.css','./js/config.js','./js/data.js','./js/storage.js','./js/api.js','./js/router.js','./js/app.js','./assets/icons/logo-mark.svg','./assets/illustrations/onboarding-discover.svg','./assets/illustrations/onboarding-details.svg','./assets/illustrations/onboarding-consult.svg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return r}).catch(()=>caches.match('./index.html'))))});
