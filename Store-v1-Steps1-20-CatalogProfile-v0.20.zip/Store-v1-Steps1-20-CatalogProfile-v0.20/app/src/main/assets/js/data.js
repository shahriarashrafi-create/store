const A='assets/';
const products=[
{id:1,sku:'TR-SUN-50',name:'کرم ضدآفتاب تراست',brand:'تراست',skinType:'همه',desc:'محافظت روزانه پوست',category:'پوست',categories:['پوست'],subCategory:'ضدآفتاب',need:'ضدآفتاب',needs:['ضدآفتاب'],price:288000,oldPrice:340000,rating:4.8,reviews:124,img:'sunscreen.svg',stock:18,volume:'50 میلی‌لیتر',variants:['بی‌رنگ','رنگی'],createdAt:'2026-08-15',features:['SPF 50+','بافت سبک','مناسب مصرف روزانه'],use:'۱۵ دقیقه قبل از قرار گرفتن در معرض آفتاب استفاده شود و در صورت نیاز تمدید شود.',ingredients:'اطلاعات ترکیبات در نسخه واقعی از کاتالوگ رسمی محصول دریافت می‌شود.'},
{id:2,sku:'TR-CLN-200',name:'ژل شستشوی صورت تراست',brand:'تراست',skinType:'چرب',desc:'پاکسازی و تنظیم چربی',category:'پوست',categories:['پوست'],subCategory:'شوینده',need:'جوش و چربی',needs:['جوش و چربی'],price:245000,oldPrice:245000,rating:4.7,reviews:89,img:'cleanser.svg',stock:12,volume:'200 میلی‌لیتر',createdAt:'2026-06-10',features:['پاکسازی ملایم','حس سبک','مناسب روتین روزانه'],use:'روی پوست مرطوب ماساژ داده و سپس آبکشی شود.',ingredients:'اطلاعات تخصصی محصول بعداً از منبع رسمی تکمیل می‌شود.'},
{id:3,sku:'TR-AGE-30',name:'سرم جوان‌ساز تراست',brand:'تراست',skinType:'معمولی',desc:'مراقبت ضدچروک و شفافیت',category:'پوست',categories:['پوست'],subCategory:'سرم',need:'جوان‌سازی',needs:['جوان‌سازی'],price:408000,oldPrice:450000,rating:4.9,reviews:201,img:'antiage.svg',stock:7,volume:'30 میلی‌لیتر',createdAt:'2026-09-12',isNew:true,features:['بافت سرمی','روتین شب','مراقبت ضدچروک'],use:'چند قطره روی پوست تمیز استفاده شود.',ingredients:'اطلاعات ترکیبات نسخه فعلی نمایشی است.'},
{id:4,sku:'TR-HYD-50',name:'کرم آبرسان صورت تراست',brand:'تراست',skinType:'خشک',desc:'رطوبت‌رسان و نرم‌کننده',category:'پوست',categories:['پوست'],subCategory:'آبرسان',need:'خشکی',needs:['خشکی'],price:268000,oldPrice:268000,rating:4.6,reviews:75,img:'hydrator.svg',stock:15,volume:'50 میلی‌لیتر',createdAt:'2026-05-05',features:['رطوبت‌رسان','نرم‌کننده','بافت کرمی'],use:'صبح و شب روی پوست تمیز استفاده شود.',ingredients:'اطلاعات رسمی محصول در مرحله اتصال کاتالوگ افزوده می‌شود.'},
{id:5,sku:'TR-SHP-250',name:'شامپو تقویت‌کننده مو تراست',brand:'تراست',skinType:'مو',desc:'مراقبت از موهای ضعیف',category:'مو',categories:['مو'],subCategory:'شامپو',need:'ریزش مو',needs:['ریزش مو'],price:338000,oldPrice:398000,rating:4.7,reviews:92,img:'shampoo.svg',stock:20,volume:'250 میلی‌لیتر',createdAt:'2026-07-25',features:['مراقبت مو','شستشوی روزانه','تقویت روتین'],use:'مقدار کافی روی مو و کف سر مرطوب استفاده و سپس آبکشی شود.',ingredients:'اطلاعات ترکیبات در نسخه فروش واقعی تکمیل می‌شود.'},
{id:6,sku:'TR-ACN-30',name:'ژل کنترل جوش تراست',brand:'تراست',skinType:'چرب',desc:'مناسب پوست چرب و مستعد جوش',category:'پوست',categories:['پوست'],subCategory:'مراقبت تخصصی',need:'جوش و چربی',needs:['جوش و چربی'],price:198000,oldPrice:220000,rating:4.8,reviews:110,img:'acne.svg',stock:3,volume:'30 میلی‌لیتر',createdAt:'2026-08-01',features:['مصرف موضعی','بافت سبک','مناسب پوست چرب'],use:'طبق راهنمای رسمی محصول استفاده شود.',ingredients:'نسخه آزمایشی؛ اطلاعات تخصصی نیازمند منبع رسمی است.'},
{id:7,sku:'TR-SPT-30',name:'سرم مراقبت از لک تراست',brand:'تراست',skinType:'مختلط',desc:'روتین شفافیت پوست',category:'پوست',categories:['پوست'],subCategory:'سرم',need:'لک',needs:['لک'],price:385000,oldPrice:420000,rating:4.6,reviews:67,img:'serum.svg',stock:5,volume:'30 میلی‌لیتر',createdAt:'2026-09-28',isNew:true,features:['سرم سبک','روتین پوستی','مراقبت از لک'],use:'طبق راهنمای رسمی محصول روی پوست تمیز استفاده شود.',ingredients:'اطلاعات رسمی در نسخه متصل به کاتالوگ تکمیل می‌شود.'},
{id:8,sku:'TR-MSK-200',name:'ماسک مراقبت مو تراست',brand:'تراست',skinType:'مو',desc:'برای موهای خشک و آسیب‌دیده',category:'مو',categories:['مو'],subCategory:'ماسک مو',need:'موی آسیب‌دیده',needs:['موی آسیب‌دیده'],price:310000,oldPrice:350000,rating:4.5,reviews:54,img:'mask.svg',stock:11,volume:'200 میلی‌لیتر',createdAt:'2026-04-18',features:['نرم‌کننده','مراقبت ساقه مو','مناسب موهای خشک'],use:'پس از شستشو روی ساقه مو استفاده و سپس آبکشی شود.',ingredients:'اطلاعات ترکیبات نسخه فعلی نمایشی است.'}
];

const categories=[
{id:'skin',name:'پوست',title:'مراقبت پوست',slug:'skin-care',image:'skin.svg',parentId:null,order:1,active:true,description:'محصولات مراقبت روزانه و تخصصی پوست'},
{id:'hair',name:'مو',title:'مراقبت مو',slug:'hair-care',image:'hair.svg',parentId:null,order:2,active:true,description:'محصولات مراقبت از مو و کف سر'},
{id:'body',name:'بدن',title:'مراقبت بدن',slug:'body-care',image:'needs.svg',parentId:null,order:3,active:true,description:'در صورت وجود محصول در کاتالوگ نمایش داده می‌شود'},
{id:'beauty',name:'زیبایی',title:'زیبایی',slug:'beauty',image:'needs.svg',parentId:null,order:4,active:true,description:'فقط در صورت وجود محصول واقعی نمایش داده می‌شود'},
{id:'skin-cleanser',name:'شوینده',title:'شوینده',slug:'cleanser',parentId:'skin',order:1,active:true},
{id:'skin-hydrator',name:'آبرسان',title:'آبرسان',slug:'hydrator',parentId:'skin',order:2,active:true},
{id:'skin-sunscreen',name:'ضدآفتاب',title:'ضدآفتاب',slug:'sunscreen',parentId:'skin',order:3,active:true},
{id:'skin-serum',name:'سرم',title:'سرم',slug:'serum',parentId:'skin',order:4,active:true},
{id:'skin-special',name:'مراقبت تخصصی',title:'مراقبت تخصصی',slug:'skin-special',parentId:'skin',order:5,active:true},
{id:'hair-shampoo',name:'شامپو',title:'شامپو',slug:'shampoo',parentId:'hair',order:1,active:true},
{id:'hair-mask',name:'ماسک مو',title:'ماسک مو',slug:'hair-mask',parentId:'hair',order:2,active:true}
];

const needInfo={
'جوش و چربی':['acne.svg','کنترل چربی و جوش'],'لک':['spots.svg','روشن‌تر و یکنواخت‌تر'],'خشکی':['dryness.svg','آبرسانی عمیق'],'جوان‌سازی':['antiage.svg','مراقبت ضدچروک'],'ریزش مو':['hairloss.svg','تقویت روتین مو'],'ضدآفتاب':['sun.svg','محافظت روزانه'],'موی آسیب‌دیده':['damaged-hair.svg','مراقبت و نرمی']
};

const banners=[
{id:'hero-main',type:'hero',title:'انتخاب درست، مراقبت بهتر',subtitle:'محصول مناسب پوست و موی خودت را ساده‌تر پیدا کن.',image:'hero-products-v2.svg',ctaText:'شروع انتخاب',target:{page:'products'},startAt:null,endAt:null,active:true,priority:100,position:'home-top'},
{id:'consult-home',type:'consultation',title:'نمی‌دونی کدوم محصول برای تو مناسبه؟',subtitle:'با راهنمای پوست و مو انتخاب دقیق‌تری داشته باش.',image:'consultation.svg',ctaText:'شروع راهنمایی',target:{page:'consult'},startAt:null,endAt:null,active:true,priority:80,position:'home-middle'},
{id:'campaign-special',type:'campaign',title:'پیشنهادهای ویژه Store',subtitle:'محصولات دارای تخفیف را یکجا ببین.',image:'hero-products.svg',ctaText:'مشاهده پیشنهادها',target:{page:'products',sort:'discount'},startAt:null,endAt:null,active:true,priority:60,position:'home-lower'}
];

const BRAND={name:'Store',descriptor:'فروشگاه تخصصی پوست و مو',tagline:'انتخاب درست، مراقبت بهتر',campaign:'زیبایی از انتخاب درست شروع می‌شود'};
