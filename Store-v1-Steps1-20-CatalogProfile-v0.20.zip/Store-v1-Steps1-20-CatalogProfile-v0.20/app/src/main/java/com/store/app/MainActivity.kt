package com.store.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

@Suppress("DEPRECATION")
class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var root: FrameLayout
    private lateinit var splash: View
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val handler = Handler(Looper.getMainLooper())
    private val launchAt = System.currentTimeMillis()
    private var webReady = false
    private var splashDismissed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#FAFBF9")
        window.navigationBarColor = Color.parseColor("#FAFBF9")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        root = FrameLayout(this)
        webView = WebView(this).apply { setBackgroundColor(Color.parseColor("#FAFBF9")) }
        root.addView(webView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        splash = buildNativeSplash()
        root.addView(splash, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(root)

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            builtInZoomControls = false
            displayZoomControls = false
            loadWithOverviewMode = false
            useWideViewPort = false
            mediaPlaybackRequiresUserGesture = true
            defaultTextEncodingName = "utf-8"
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.addJavascriptInterface(NativeBridge(this), "NativeBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { webReady = true; dismissSplashWhenReady() }
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) dismissSplashWhenReady()
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView?, callback: ValueCallback<Array<Uri>>?, params: WebChromeClient.FileChooserParams?): Boolean {
                filePathCallback?.onReceiveValue(null); filePathCallback = callback
                val intent = try { params?.createIntent() ?: return false } catch (_: Exception) { filePathCallback = null; return false }
                return try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); true } catch (_: Exception) { filePathCallback = null; false }
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
        handler.postDelayed({ if (!splashDismissed) dismissSplash(force = true) }, 2500L)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun buildNativeSplash(): View {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(28), dp(28), dp(28), dp(28)); setBackgroundColor(Color.parseColor("#FAFBF9"))
        }
        val logo = ImageView(this).apply { setImageResource(R.drawable.ic_launcher_foreground); scaleType = ImageView.ScaleType.CENTER_INSIDE }
        wrap.addView(logo, LinearLayout.LayoutParams(dp(92), dp(92)))
        val title = TextView(this).apply { text = "Store"; textSize = 29f; setTextColor(Color.parseColor("#1C2B24")); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER }
        wrap.addView(title, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })
        val sub = TextView(this).apply { text = "انتخاب درست، مراقبت بهتر"; textSize = 13f; setTextColor(Color.parseColor("#66736D")); gravity = Gravity.CENTER }
        wrap.addView(sub, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(7) })
        wrap.alpha = 0f; wrap.scaleX = .97f; wrap.scaleY = .97f; wrap.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320).start()
        return wrap
    }
    private fun dismissSplashWhenReady() { val delay = (750L - (System.currentTimeMillis() - launchAt)).coerceAtLeast(0L); handler.postDelayed({ dismissSplash(false) }, delay) }
    private fun dismissSplash(force: Boolean) {
        if (splashDismissed || (!force && !webReady)) return
        splashDismissed = true
        splash.animate().alpha(0f).setDuration(220).withEndAction { root.removeView(splash) }.start()
    }

    class NativeBridge(private val context: Context) {
        @JavascriptInterface fun haptic() {
            try { val vibrator=context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator?:return;if(!vibrator.hasVibrator())return;if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)vibrator.vibrate(VibrationEffect.createOneShot(18,VibrationEffect.DEFAULT_AMPLITUDE))else vibrator.vibrate(18) } catch (_: Exception) {}
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { super.onActivityResult(requestCode,resultCode,data);if(requestCode==FILE_CHOOSER_REQUEST){filePathCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));filePathCallback=null} }
    override fun onBackPressed() { webView.evaluateJavascript("window.StoreBack ? StoreBack() : false") { value -> if(value=="true")return@evaluateJavascript;if(webView.canGoBack())webView.goBack()else finish() } }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }
    companion object { private const val FILE_CHOOSER_REQUEST = 9001 }
}
