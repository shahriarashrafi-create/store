# پیاده‌سازی ۴۰ تغییر UI/UX در Store v0.6

1. حذف overflow افقی و محدودسازی عرض همه صفحات و Gridها.
2. سیستم اندازه ثابت Assetها برای icon / illustration / product image.
3. Header جدید با Logo، Store، زیرعنوان، علاقه‌مندی و اعلان.
4. Search bar یکپارچه بدون دکمه حجیم جداگانه.
5. Hero کوتاه‌تر و حرفه‌ای با Asset اختصاصی و CTA.
6. دسته‌بندی‌های تصویری پوست، مو و نیاز.
7. نیازها به صورت کارت‌های تصویری افقی.
8. بخش پرفروش‌ترین‌ها با Product Card کامل.
9. بخش پیشنهاد ویژه با همان زبان طراحی.
10. Products به صورت Grid دو ستونه فروشگاهی.
11. Category tabs تصویری در Products.
12. Filter و Sort به صورت Bottom Sheet.
13. یک Product Card پایه با Variant compact/standard.
14. Product Detail با Gallery، Variant، ویژگی‌ها، روش مصرف، اطلاعات تخصصی و Related Products.
15. Cart بازطراحی‌شده با تصویر، quantity stepper، حذف و summary.
16. Profile hero جدید با Avatar، نام، موبایل، Level و Points.
17. Quick actions برای مشاوره، علاقه‌مندی، تخفیف و باشگاه.
18. Profile menu استاندارد با icon/text/chevron.
19. حذف Arrow/Shapeهای حجیم؛ فقط Navigation indicators کوچک.
20. Bottom Navigation استاندارد چهار بخشی + Cart badge.
21. پالت رنگ ثابت سبز/مینت/سفید/خاکستری و قرمز فقط alert/discount.
22. Type scale ثابت و font stack سازگار با فارسی.
23. Radius system ثابت 12/16/22/30.
24. Shadow system محدود و هماهنگ.
25. حذف Emoji از UI و استفاده از SVG/local assets.
26. Product assets یکدست محلی؛ آماده جایگزینی با تصاویر رسمی کاتالوگ.
27. Empty stateهای تصویری برای سبد، سفارش، سرچ، علاقه‌مندی و حساب.
28. Skeleton loading اولیه.
29. Snackbar استاندارد برای feedbackها.
30. Transition/animation ظریف 150–250ms.
31. Haptic feedback از Android JS bridge برای اکشن‌های اصلی.
32. حداقل tap area حدود 44px برای کنترل‌ها.
33. Login/Register با طراحی هماهنگ.
34. Checkout با سه مرحله آدرس/ارسال/پرداخت.
35. Card-to-card payment UI با Copy، Tracking number و receipt upload.
36. Order tracking timeline تصویری.
37. Consultation UI با انتخاب تصویری پوست/مو و فرم مرحله‌ای.
38. CSS component-based به جای selectorهای عمومی خطرناک.
39. Asset size guard با کلاس‌های icon-sm/md/lg، illustration و product-image.
40. Responsive rules برای عرض‌های 360 تا 480 و ساختار آماده Tablet.

## محدودیت فعلی
Backend، موجودی واقعی، قیمت واقعی، اطلاعات رسمی محصول، تأیید پرداخت و پنل مدیریت هنوز متصل نشده‌اند. این Build برای تست کامل ظاهر و جریان نسخه اول روی APK است.
