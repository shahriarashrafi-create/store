# Store v0.6 — Steps 1–6 Polished UI

نسخه آزمایشی Android فروشگاه Store بر اساس تصمیم‌های تأییدشده قدم‌های ۱ تا ۶.

## وضعیت نسخه اول
- فارسی و RTL
- بدون پیامک: ورود با شماره موبایل و رمز عبور
- بدون درگاه آنلاین: کارت‌به‌کارت + شماره پیگیری + آپلود رسید + تأیید دستی مدیر
- داده‌ها فعلاً Local هستند و برای تست UI/UX و مسیر مشتری استفاده می‌شوند
- تصاویر محصول در این Build دارایی‌های آزمایشی محلی هستند؛ در نسخه متصل به کاتالوگ با تصاویر رسمی محصول جایگزین می‌شوند

## صفحات اصلی
Home، Products، Product Detail، Favorites، Cart، Login/Register، Profile، Checkout، Orders/Tracking، Consultation، Addresses، Payment Methods، Support، Account Settings، About، Coupons، Loyalty، Notifications.

## نکات فنی
- Android WebView wrapper
- Gradle / Java 17
- Local HTML/CSS/JS و SVG assets
- Haptic bridge برای اکشن‌های اصلی
- File chooser برای آپلود رسید
- Responsive mobile layout و جلوگیری از horizontal overflow

این ZIP برای Workflow فعلی GitHub که جدیدترین ZIP ریشه Repository را build می‌کند آماده شده است.
