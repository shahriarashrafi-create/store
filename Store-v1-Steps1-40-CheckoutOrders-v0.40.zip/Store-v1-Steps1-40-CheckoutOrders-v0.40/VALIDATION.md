# VALIDATION — Store v0.40

## Passed

- `node --check` passed for every JavaScript file in Android/PWA assets and backend scaffold, including `steps31-40.js`.
- VM runtime smoke test passed for Home → Cart → Shipping → Draft Order → Payment → Receipt Result → Orders → Order Detail.
- Runtime smoke confirmed Draft Order is created before payment and Cart is preserved until successful receipt submission.
- Runtime smoke confirmed Cart is cleared only after receipt submission moves the order to `در انتظار تأیید پرداخت`.
- `manifest.webmanifest` and `backend/package.json` parse as valid JSON.
- Android Manifest, Android resource XML and all SVG assets parse successfully (95 XML/SVG files checked).
- CSS brace-balance validation passed for all stylesheets.
- `versionCode 40` and `versionName 0.40-steps1-40-checkout-orders` confirmed.
- PWA cache key is `store-v040-shell` and includes Step 31–40 JS/CSS modules.
- Storage key is `store-v040` with migration from `store-v030` and earlier builds.
- Backend SQL contains carts/cart_items, coupons/redemptions, addresses, shipping methods/shipments, payment methods, order status events and invoices.

## Step-specific checks

- Cart renders Variant, current/old price, quantity Stepper, remove, clear-cart confirmation and Coupon area.
- Quantity is capped by current local SKU stock; decrementing from 1 removes with Undo.
- Financial Summary separates product discount, Coupon, shipping and final total.
- Address model supports multiple addresses, default address, independent recipient and Order snapshot.
- Shipping methods are address-aware in the local prototype and support configurable free-shipping threshold logic.
- Checkout is three-step and creates/reuses a Draft Order before the bank-transfer receipt stage.
- Android WebView already includes `onShowFileChooser`, so receipt image selection can open the phone file/image picker.
- Receipt submission does not mark payment as approved; it moves to pending manual confirmation.
- Order History includes status filters, Order Detail, timeline, reorder with current price/stock, tracking scaffold and a simple digital invoice.

## Gradle build note

A local `:app:assembleDebug` attempt was made. It stopped before Android compilation because this environment could not resolve `services.gradle.org` while downloading Gradle 8.7 (`curl: (6) Could not resolve host`). GitHub Actions remains the final APK compile check for this ZIP.

## Production-data note

The local runtime is still a prototype. Destination bank/card data, Coupon rules, shipping rates/availability, official product price/stock, private receipt object storage and Admin payment approval must come from the real Backend before production launch. Full Admin Panel remains Step 45.
