# Implementation — Steps 31–40

## Step 31 — Cart
- Cart در Bottom Navigation و Badge تعداد
- نمایش تصویر، نام، Variant، قیمت واحد/جمع و حذف
- تغییر Variant با Bottom Sheet
- Revalidation قیمت و موجودی هنگام ورود و Checkout
- Cart مهمان در Local Storage و Merge-ready با حساب محلی
- Cross-sell محدود در انتهای سبد

## Step 32 — Quantity / Remove
- Stepper با سقف موجودی واقعی
- عدد ۱ + کاهش → حذف با Undo
- حذف تکی بدون Dialog سنگین
- خالی‌کردن کل سبد با Confirmation
- CartService مرکزی: add/remove/updateQuantity/changeVariant/validate/clear

## Step 33 — Totals / Discounts
- Gross کالاها، تخفیف محصول، Coupon، ارسال و مبلغ نهایی
- بروزرسانی Real-time
- Progress تا ارسال رایگان
- ساختار Backend-ready برای محاسبه نهایی Server-side

## Step 34 — Coupons
- ورودی Coupon در Cart
- Rule Engine برای percent / fixed / free_shipping
- minOrder / maxDiscount / stackable-ready
- خطای قابل فهم
- Backend tables برای coupons و coupon_redemptions
- دو کد DEMO داخلی فقط برای تست Local؛ در UI پیشنهاد نمی‌شوند

## Step 35 — Addresses
- چند آدرس، عنوان، گیرنده، موبایل، استان، شهر، آدرس، پلاک، واحد، کد پستی
- آدرس پیش‌فرض
- Add/Edit/Delete داخل Profile و Checkout
- Checkout بدون نیاز به خروج از فرایند
- Snapshot مستقل آدرس داخل Order

## Step 36 — Shipping
- روش‌های Post / Tipax و Courier برای شهر تهران در Prototype
- Rule وابسته به آدرس
- ETA تخمینی
- Threshold ارسال رایگان
- shipping_methods / shipments / shipment_items در schema
- Order structure آماده چند Shipment

## Step 37 — Checkout
- سه مرحله: Address → Shipping → Payment
- بدون Bottom Navigation
- حفظ State در Back/Forward
- Validation Cart قبل از ساخت Order
- Draft Order قبل از مرحله پرداخت
- بازگشت از Login به Checkout بدون از دست رفتن Cart

## Step 38 — Payment
- Bank transfer / card-to-card به‌عنوان روش MVP
- Payment Settings جدا از UI و آماده Admin
- Receipt file input با پشتیبانی WebView File Chooser موجود
- Reference/tracking code fallback
- Payment status فقط به «در انتظار تأیید» می‌رود؛ Paid واقعی نیازمند تأیید Admin/Backend است
- Retry از Order Detail

## Step 39 — Result states
- صفحه Success با متن دقیق «رسید ثبت شد و در انتظار بررسی است»
- صفحه Error قابل Retry
- Cart فقط پس از ثبت موفق Receipt پاک می‌شود
- Order حفظ می‌شود اگر کاربر پرداخت را نیمه‌کاره رها کند
- تابع showPaymentFailure برای اتصال API آینده

## Step 40 — Orders / Tracking
- Order history با فیلتر وضعیت
- Order cards: شماره، تاریخ، مبلغ، تعداد کالا و وضعیت
- Order Detail با Timeline، اقلام Snapshot، آدرس، ارسال و پرداخت
- Reorder با قیمت و موجودی فعلی
- Tracking scaffold برای carrier/tracking code
- Invoice ساده داخل اپ؛ PDF رسمی آماده اضافه‌شدن از Backend

## Architecture

قابلیت‌های v0.40 در `js/steps31-40.js` و `css/steps31-40.css` اضافه شده‌اند. ساختار نسخه ۰.۳۰ حفظ شده و Backend target schema برای ادامه قدم‌های ۴۱ تا ۵۰ توسعه یافته است.
