# Validation — Store v0.60-RC1

پاس شده:
- JavaScript syntax برای Frontend و Android assets.
- TypeScript/TSX syntax parse برای Backend و Admin.
- JSON/XML parsing.
- Android versionCode/versionName consistency.
- Frontend → Android asset sync.

Build محلی Gradle تلاش شد اما محیط ساخت به `services.gradle.org` دسترسی DNS نداشت؛ بنابراین Compile APK نهایی باید مثل قبل در GitHub Actions انجام شود.
