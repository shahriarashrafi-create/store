# Store 0.60.1 RC1 — Android manifest merge fix

- Fixed Android debug manifest merger conflict for `android:usesCleartextTraffic`.
- Debug manifest now explicitly overrides the main manifest value with `tools:replace` so local HTTP development remains available in debug builds.
- Increased Android `versionCode` to 61 and `versionName` to `0.60.1-RC1-manifest-fix`.
- No Store UI, customer flows, Admin UI, backend schema, or Steps 1–60 business logic was changed.
