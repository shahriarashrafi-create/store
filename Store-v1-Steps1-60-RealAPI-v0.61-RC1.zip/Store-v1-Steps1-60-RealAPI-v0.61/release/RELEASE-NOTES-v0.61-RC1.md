# Store v0.61-RC1 — Customer Real API

- Connected customer Store to `https://store-api.weblines.ir/api/v1`.
- Production API mode enabled.
- Product catalog hydrates from the live PostgreSQL-backed API.
- Existing local UI is kept unchanged; API data becomes the catalog source of truth when reachable.
- Android versionCode: 62.
- Android versionName: 0.61-RC1-real-api.
