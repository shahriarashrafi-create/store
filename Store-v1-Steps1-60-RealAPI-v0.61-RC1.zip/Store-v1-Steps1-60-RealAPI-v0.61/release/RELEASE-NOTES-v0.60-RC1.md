# Store v0.60-RC1

این نسخه فاز ۵۱ تا ۶۰ را روی v0.50 اضافه می‌کند.

## اصلی‌ترین تغییرات
- Backend واقعی با Fastify + TypeScript + Prisma + PostgreSQL.
- Auth واقعی با Argon2id، Access Token و Refresh Session قابل لغو.
- Product/Variant/SKU واقعی و Import Wizard برای Excel/CSV.
- Admin وب مستقل با React + TypeScript و Role/Permission.
- Order State Machine، Stock Reservation و Transaction تأیید پرداخت.
- S3-compatible Object Storage و Signed URL برای رسیدهای Private.
- اتصال API برای Catalog/Auth/Cart/Favorites/Orders/Notifications/Receipt.
- ساختار Dev/Staging/Production و Docker template.
- RC checklist و E2E plan.

## Android
- versionCode: 60
- versionName: 0.60-RC1-steps1-60-realization

## نکته
Build پیش‌فرض روی `environment:'local'` باقی مانده تا APK تستی بدون سرور همچنان باز شود. برای اتصال واقعی باید Staging/Production config و Secretها تنظیم شوند.
