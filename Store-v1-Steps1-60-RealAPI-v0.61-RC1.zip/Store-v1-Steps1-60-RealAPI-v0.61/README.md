# Store v0.61-RC1 — Real API Customer Build

این ZIP ادامه‌ی مستقیم v0.50 است و ساختار توافق‌شده را دارد:

```text
frontend/   اپ مشتری / PWA
android/    APK مشتری (Kotlin WebView wrapper)
admin/      پنل مدیریت وب React + TypeScript
backend/    Fastify + TypeScript + Prisma + PostgreSQL
docs/       معماری، Deploy و RC checklist
deploy/     قالب Local/Staging infrastructure
scripts/    Sync/Environment/Validation
```

## نکته مهم
این بسته **کد RC و زیرساخت آماده اتصال** است؛ خودش سرور Production یا Database واقعی ایجاد نمی‌کند. برای واقعی‌شدن Store باید Credentials/Domain/PostgreSQL/Object Storage محیط Staging تنظیم شوند و Migration/Deploy اجرا شود.

## Android
`android/app/build.gradle`:
- `versionCode 60`
- `versionName 0.60-RC1-steps1-60-realization`

Workflow فعلی GitHub که داخل ZIP دنبال `settings.gradle` می‌گردد، پروژه Android را در `android/` پیدا می‌کند.

## تست UI بدون Backend
پیش‌فرض `frontend/js/config.js` هنوز `environment:'local'` است تا APK تستی بدون سرور سفید نشود. برای Staging/Production از `scripts/set-environment.sh` استفاده کن.


## v0.61 Real API
- Customer catalog now uses the production API at `https://store-api.weblines.ir/api/v1`.
- `environment` is `production` and `dataMode` is `api`.
- Products, categories and campaigns hydrate from PostgreSQL through the live Store API.
- Android application id remains `com.store.app`.
