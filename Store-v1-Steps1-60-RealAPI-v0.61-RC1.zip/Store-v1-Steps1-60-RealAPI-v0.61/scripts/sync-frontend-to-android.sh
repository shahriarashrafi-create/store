#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
rm -rf "$ROOT/android/app/src/main/assets"
mkdir -p "$ROOT/android/app/src/main/assets"
cp -a "$ROOT/frontend/." "$ROOT/android/app/src/main/assets/"
echo "Frontend synced to Android assets."
