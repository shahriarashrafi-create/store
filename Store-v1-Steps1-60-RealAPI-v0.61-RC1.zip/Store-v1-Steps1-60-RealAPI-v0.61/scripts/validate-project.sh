#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
for f in "$ROOT"/frontend/js/*.js "$ROOT"/frontend/service-worker.js; do node --check "$f" >/dev/null; done
python3 - "$ROOT" <<'PY'
from pathlib import Path
import json,sys,xml.etree.ElementTree as ET
r=Path(sys.argv[1])
for p in r.rglob('*.json'): json.loads(p.read_text())
for p in list((r/'android/app/src').rglob('*.xml')): ET.parse(p)
assert "versionCode 62" in (r/'android/app/build.gradle').read_text()
assert "0.61-RC1" in (r/'frontend/js/config.js').read_text()
print('JSON/XML/version checks OK')
PY
node - "$ROOT/backend" "$ROOT/admin" <<'NODE'
const fs=require('fs'),path=require('path');const ts=require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js');const roots=process.argv.slice(2);let bad=0;function walk(d){for(const n of fs.readdirSync(d)){const p=path.join(d,n),st=fs.statSync(p);if(st.isDirectory())walk(p);else if(/\.(ts|tsx)$/.test(n)){const r=ts.transpileModule(fs.readFileSync(p,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX},reportDiagnostics:true,fileName:p});for(const x of r.diagnostics||[]){if(x.category===ts.DiagnosticCategory.Error){bad++;console.error(p,ts.flattenDiagnosticMessageText(x.messageText,' '));}}}}}for(const r of roots)walk(r);if(bad)process.exit(1);console.log('TypeScript syntax checks OK');
NODE
echo "VALIDATION OK"
