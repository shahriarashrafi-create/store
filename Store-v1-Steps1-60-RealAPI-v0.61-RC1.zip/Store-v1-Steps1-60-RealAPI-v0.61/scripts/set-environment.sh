#!/usr/bin/env bash
set -euo pipefail
ENVIRONMENT="${1:-}"
case "$ENVIRONMENT" in local|development|staging|production) ;; *) echo "Usage: $0 local|development|staging|production" >&2; exit 2;; esac
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 - "$ROOT/frontend/js/config.js" "$ENVIRONMENT" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]); env=sys.argv[2]; s=p.read_text(); s=re.sub(r"environment:'[^']+'",f"environment:'{env}'",s,count=1); p.write_text(s)
PY
"$ROOT/scripts/sync-frontend-to-android.sh"
echo "Environment set to $ENVIRONMENT"
