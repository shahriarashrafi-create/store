# Store v1.0 Launch Checklist — Step 50

## Required before public launch
- [ ] Real Trust catalog, official images and validated product copy imported.
- [ ] PostgreSQL production database migrated and backed up.
- [ ] Transactional order service completed and tested.
- [ ] Private receipt/object storage configured.
- [ ] Admin real authentication, roles/permissions and 2FA enabled.
- [ ] Shipping and payment destination settings configured from Admin.
- [ ] Notification provider configured if Push is enabled.
- [ ] Full QA matrix passed with P0=0 and P1=0.
- [ ] Staging sign-off completed.
- [ ] Production monitoring and rollback plan ready.
- [ ] Privacy, terms and return policies reviewed.
- [ ] Android signing/release keys managed outside public source.

Launch phases: Internal → Closed Beta (20–50 users) → Soft Launch → Public Launch.
