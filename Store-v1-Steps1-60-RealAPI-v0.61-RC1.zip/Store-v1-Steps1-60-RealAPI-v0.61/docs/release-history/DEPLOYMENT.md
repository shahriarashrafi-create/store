# Build & Deploy — Step 49

Recommended flow:
`Code → Static/API tests → Android/Web build → Staging → QA approval → Production → Monitoring`.

Environments are defined in `app/src/main/assets/js/config.js`: local, development, staging and production. Replace placeholder URLs only through the appropriate deployment configuration.

Android update compatibility requires the same applicationId and signing identity across releases. `versionCode` must always increase.

Secrets (database, object storage, API keys, signing secrets, Admin credentials) must live in GitHub Secrets / environment variables / secret manager, never inside this ZIP.
