# قالب Import کاتالوگ

ستون‌های پیشنهادی Excel/CSV:
`name, slug, sku, variantTitle, price, compareAtPrice, stock, brand`

در Admin ابتدا فایل Preview/Validate می‌شود؛ سپس Commit به Backend انجام می‌شود. قیمت‌ها به تومان و موجودی عدد صحیح غیرمنفی باشند.
