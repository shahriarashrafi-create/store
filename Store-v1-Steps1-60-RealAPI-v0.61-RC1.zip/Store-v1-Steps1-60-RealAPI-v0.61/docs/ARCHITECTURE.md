# معماری Store بعد از قدم ۶۰

```text
Store customer PWA ─┐
Android wrapper ─────┼──> REST API v1 / Fastify ──> PostgreSQL
Store Admin web ─────┘              │
                                    └──> S3-compatible Object Storage
```

- `frontend/`: سورس مشترک PWA و UI مشتری.
- `android/`: Kotlin/WebView wrapper؛ Assets از `frontend/` Sync می‌شوند.
- `admin/`: React + TypeScript پنل مدیریتی مستقل.
- `backend/`: Fastify + TypeScript + Prisma.
- PostgreSQL منبع حقیقت Product/Price/Stock/Order/Payment است.
- Object Storage برای تصاویر عمومی و رسیدهای Private استفاده می‌شود.
