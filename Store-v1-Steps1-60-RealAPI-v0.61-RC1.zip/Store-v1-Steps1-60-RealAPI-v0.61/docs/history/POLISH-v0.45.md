# Store v0.45 — Final UI/UX Polish for Steps 1–40

This release keeps roadmap Steps 1–40 intact and applies the approved final UI/UX polish pass plus supporting code corrections.

## Visual and UX polish
- More compact, fixed-slot product cards with cleaner price hierarchy and no fake “بدون نظر” label.
- More compact Products header, category tabs, Home hero, consultation and campaign sections.
- Removed duplicate Products filter action and improved RTL horizontal category scrolling.
- Lighter bottom navigation while preserving minimum touch targets and safe-area spacing.
- More compact cart item layout, less prominent destructive action, collapsed coupon entry and sticky checkout bar.
- Cleaner free-shipping progress, onboarding spacing, typography hierarchy, badges and muted-text contrast.
- Standard pressed/loading/disabled treatment, add-to-cart feedback, search clear/debounce behavior and offline banner.
- Improved BiDi handling, numeric formatting, long-text resilience, skeleton/layout stability and responsive rules.

## Code correctness improvements
- Guest/account cart merge sums quantities and caps by current stock.
- Cart validation no longer silently accepts changed prices; changed price snapshots require explicit acceptance.
- Reviews use approved runtime review data as the source of truth; legacy demo ratings are not surfaced as real reviews.
- Business/demo settings are centralized for later Admin/API integration.
- Service worker uses a safer navigation fallback and does not return index.html for arbitrary failed assets.

## Product imagery
Current bundled product illustrations remain local placeholders. Replace them with official Trust product photography when approved assets are available; the layout already reserves stable image space to avoid layout shift.

## Version
- Android versionCode: 45
- Android versionName: 0.45-steps1-40-final-polish
- Roadmap coverage: Steps 1–40 + final polish (this is not roadmap Step 45 / Admin Panel)
