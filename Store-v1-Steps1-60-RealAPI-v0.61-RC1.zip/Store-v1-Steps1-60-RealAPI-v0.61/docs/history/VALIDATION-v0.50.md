# Validation — Store v0.50

Checks performed before packaging:
- JavaScript syntax for all frontend JS, service worker, backend server and Admin JS
- AndroidManifest XML parse
- PWA manifest JSON parse
- All local SVG assets parse as XML
- Required v0.50 scripts/styles referenced by index.html
- versionCode/versionName verification
- Backend smoke: `/api/health` and safe demo `/api/products`
- ZIP integrity after packaging

Not claimed as executed locally:
- Android Gradle compile/APK install in this environment
- PostgreSQL integration tests without a configured database
- Production Push/Object Storage/Admin 2FA provider tests

GitHub Actions remains the source for actual Android build verification.
