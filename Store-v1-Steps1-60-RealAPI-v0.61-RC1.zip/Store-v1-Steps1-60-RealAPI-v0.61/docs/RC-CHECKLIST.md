# Store 0.60-RC1 Checklist

- [ ] PostgreSQL Staging متصل و Migration پاس
- [ ] Seed محدود و Admin Owner ساخته شده
- [ ] S3/MinIO bucket و Signed URL پاس
- [ ] Register/Login/Refresh/Logout پاس
- [ ] Product واقعی از API دیده می‌شود
- [ ] Guest Cart → Login merge پاس
- [ ] Price/Stock revalidation پاس
- [ ] Order creation و Reservation پاس
- [ ] Receipt upload → Admin review پاس
- [ ] Payment approve → stock decrement + notification + audit پاس
- [ ] Order transitions تا Delivered پاس
- [ ] Role/Permission 403 پاس
- [ ] APK/PWA روی 360/390/412/480 و Font Scale تست
- [ ] P0=0 و P1=0
