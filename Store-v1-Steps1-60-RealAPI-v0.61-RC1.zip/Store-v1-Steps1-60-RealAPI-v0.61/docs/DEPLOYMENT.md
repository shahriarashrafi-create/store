# Deploy واقعی

1. PostgreSQL و Object Storage را بساز.
2. `backend/.env.example` را به Secret/Environment واقعی تبدیل کن.
3. Backend: `npm install && npm run prisma:generate && npm run db:migrate && npm run db:seed`.
4. Admin را با `VITE_API_BASE_URL=https://staging-api.../api/v1` Build کن.
5. PWA/Android config را ابتدا `staging` کن: `./scripts/set-environment.sh staging`.
6. Health: `GET /health` و `GET /api/v1/health` باید OK باشند.
7. E2E را روی Staging اجرا کن؛ فقط بعد از P0/P1=0 وارد Production شو.

Production secrets هرگز داخل ZIP/Git قرار نگیرند.
