# Store Backend — v0.60-RC1

Backend واقعیِ فاز ۵۱ تا ۶۰ با **Node.js + TypeScript + Fastify + Prisma + PostgreSQL**.

## اجرای محلی

```bash
cp .env.example .env
npm install
npm run prisma:generate
npm run db:migrate
npm run db:seed
npm run dev
```

برای Seed کردن Owner، قبل از `db:seed` مقدارهای `SEED_ADMIN_MOBILE` و `SEED_ADMIN_PASSWORD` را فقط در محیط محلی/Secret Manager تعریف کن؛ آن‌ها را داخل Git یا ZIP قرار نده.

## مسیرهای اصلی

- Public: `/api/v1/health`, `/products`, `/products/:id`, `/categories`, `/campaigns`, `/articles`, `/search`
- Auth: `/api/v1/auth/register|login|refresh|logout|logout-all|me`
- User: `/favorites`, `/cart`, `/addresses`, `/checkout/validate`, `/orders`, `/payments/receipt/*`, `/notifications`
- Admin: `/api/v1/admin/auth/*`, `/dashboard`, `/products`, `/variants`, `/catalog/import`, `/orders`, `/payments`, `/audit-logs`

## قواعد Production

- Access token کوتاه‌عمر است؛ Refresh token خام در DB ذخیره نمی‌شود.
- Password با Argon2id Hash می‌شود.
- Order/Payment/Stock توسط Backend کنترل می‌شوند.
- ایجاد سفارش با `SERIALIZABLE` transaction و Stock Reservation انجام می‌شود.
- تأیید پرداخت، کسر موجودی، Audit و Notification در یک transaction انجام می‌شود.
- رسیدها Private هستند و فقط با Signed URL کوتاه‌عمر دیده می‌شوند.
- Secrets فقط از Environment/Secret Manager خوانده می‌شوند.
