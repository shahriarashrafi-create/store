import Fastify from 'fastify';
import cors from '@fastify/cors';
import cookie from '@fastify/cookie';
import jwt from '@fastify/jwt';
import { ZodError } from 'zod';
import { config, corsOrigins } from './lib/config.js';
import { prisma } from './lib/prisma.js';
import { AppError } from './lib/http.js';
import { authRoutes } from './routes/auth.js';
import { catalogRoutes } from './routes/catalog.js';
import { accountRoutes } from './routes/account.js';
import { commerceRoutes } from './routes/commerce.js';
import { adminRoutes } from './routes/admin.js';

export async function buildApp(){
  const app=Fastify({logger:{redact:['req.headers.authorization','req.headers.cookie','res.headers.set-cookie','body.password','body.refreshToken']},bodyLimit:2*1024*1024});
  await app.register(cors,{origin:(origin,cb)=>{if(!origin||origin==='null'||corsOrigins.includes(origin))return cb(null,true);cb(new Error('CORS_BLOCKED'),false);},credentials:true});
  await app.register(cookie);
  await app.register(jwt,{secret:config.JWT_ACCESS_SECRET});
  app.decorate('authenticateUser',async function(request:any){try{await request.jwtVerify();if(request.user.kind!=='user')throw new Error('kind');const session=await prisma.session.findFirst({where:{id:request.user.sid,userId:request.user.sub,revokedAt:null,expiresAt:{gt:new Date()}}});if(!session)throw new Error('session');}catch{throw new AppError(401,'UNAUTHORIZED');}});
  app.decorate('authenticateAdmin',async function(request:any){try{await request.jwtVerify();if(request.user.kind!=='admin')throw new Error('kind');const session=await prisma.adminSession.findFirst({where:{id:request.user.sid,adminUserId:request.user.sub,revokedAt:null,expiresAt:{gt:new Date()}}});if(!session)throw new Error('session');}catch{throw new AppError(401,'UNAUTHORIZED_ADMIN');}});

  app.get('/health',async()=>{await prisma.$queryRaw`SELECT 1`;return {service:'Store API',status:'ok',version:'0.60-RC1',database:'ok'};});
  await app.register(async api=>{await catalogRoutes(api);await authRoutes(api);await accountRoutes(api);await commerceRoutes(api);await adminRoutes(api);},{prefix:'/api/v1'});

  app.setErrorHandler((error:any,request,reply)=>{if(error instanceof ZodError)return reply.code(400).send({error:'VALIDATION_ERROR',details:error.flatten()});const status=error.statusCode||500;const code=error.code||error.message||'INTERNAL_ERROR';if(status>=500)request.log.error(error);return reply.code(status).send({error:code,details:error.details});});
  app.addHook('onClose',async()=>{await prisma.$disconnect();});
  return app;
}
