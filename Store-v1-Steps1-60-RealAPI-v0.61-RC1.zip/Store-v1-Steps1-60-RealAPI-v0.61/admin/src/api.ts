const BASE=(import.meta.env.VITE_API_BASE_URL||'http://localhost:3000/api/v1').replace(/\/$/,'');
let accessToken=sessionStorage.getItem('store-admin-access')||'';
export const setToken=(v:string)=>{accessToken=v;v?sessionStorage.setItem('store-admin-access',v):sessionStorage.removeItem('store-admin-access')};
async function raw(path:string,options:RequestInit={},retry=true){const headers=new Headers(options.headers||{});if(!(options.body instanceof FormData))headers.set('Content-Type','application/json');if(accessToken)headers.set('Authorization',`Bearer ${accessToken}`);let r=await fetch(BASE+path,{...options,headers,credentials:'include'});if(r.status===401&&retry&&!path.startsWith('/admin/auth/')){const rr=await fetch(BASE+'/admin/auth/refresh',{method:'POST',credentials:'include'});if(rr.ok){const j=await rr.json();setToken(j.accessToken);return raw(path,options,false)}}if(!r.ok){let p:any={};try{p=await r.json()}catch{};const e:any=new Error(p.error||`HTTP_${r.status}`);e.status=r.status;e.payload=p;throw e}return r.status===204?null:r.json()}
export const api={
 login:(mobile:string,password:string)=>raw('/admin/auth/login',{method:'POST',body:JSON.stringify({mobile,password})}),
 me:()=>raw('/admin/auth/me'),logout:()=>raw('/admin/auth/logout',{method:'POST'}),dashboard:()=>raw('/admin/dashboard'),
 products:()=>raw('/admin/products'),createProduct:(data:any)=>raw('/admin/products',{method:'POST',body:JSON.stringify(data)}),updateVariant:(id:string,data:any)=>raw(`/admin/variants/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
 importCatalog:(rows:any[],dryRun:boolean)=>raw('/admin/catalog/import',{method:'POST',body:JSON.stringify({rows,dryRun})}),
 orders:()=>raw('/admin/orders'),updateOrderStatus:(id:string,status:string)=>raw(`/admin/orders/${id}/status`,{method:'PATCH',body:JSON.stringify({status})}),
 payments:()=>raw('/admin/payments'),receiptUrl:(id:string)=>raw(`/admin/payments/${id}/receipt-url`),approvePayment:(id:string)=>raw(`/admin/payments/${id}/approve`,{method:'POST'}),rejectPayment:(id:string,reason:string)=>raw(`/admin/payments/${id}/reject`,{method:'POST',body:JSON.stringify({reason,needsResubmission:true})}),
 audit:()=>raw('/admin/audit-logs')
};
export {BASE};
