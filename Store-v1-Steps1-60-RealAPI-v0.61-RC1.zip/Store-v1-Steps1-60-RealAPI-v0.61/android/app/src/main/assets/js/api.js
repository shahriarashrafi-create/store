const StoreApi={
  get baseUrl(){return window.StoreConfig.api[window.StoreConfig.environment]||''},
  get enabled(){return !!this.baseUrl},
  accessToken(){try{return sessionStorage.getItem('store-api-access')||''}catch(e){return''}},
  setAccessToken(token){try{token?sessionStorage.setItem('store-api-access',token):sessionStorage.removeItem('store-api-access')}catch(e){}},
  normalizeError(payload,status){const err=new Error(payload?.error||`API_${status}`);err.status=status;err.payload=payload||{};return err},
  async refreshSession(){if(!this.enabled)return false;try{const r=await fetch(this.baseUrl+'/auth/refresh',{method:'POST',credentials:'include',headers:{Accept:'application/json'}});if(!r.ok)return false;const j=await r.json();this.setAccessToken(j.accessToken);if(j.user){state.user=apiUserToLocal(j.user);save()}return true}catch(e){return false}},
  async request(path,options={},retry=true){
    if(!this.baseUrl)throw new Error('API_NOT_CONNECTED');
    const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),Number(options.timeout||10000));
    const headers={Accept:'application/json',...(options.body instanceof FormData?{}:{'Content-Type':'application/json'}),...(options.headers||{})};
    const token=this.accessToken();if(token)headers.Authorization=`Bearer ${token}`;
    try{
      let response=await fetch(this.baseUrl+path,{...options,headers,credentials:'include',signal:controller.signal});
      if(response.status===401&&retry&&!path.startsWith('/auth/')){if(await this.refreshSession())return this.request(path,options,false)}
      if(!response.ok){let payload={};try{payload=await response.json()}catch(e){}throw this.normalizeError(payload,response.status)}
      if(response.status===204)return null;return response.json();
    }catch(e){if(e.name==='AbortError')throw new Error('API_TIMEOUT');throw e}finally{clearTimeout(timeout)}
  },
  health(){return this.request('/health',{timeout:4000})},
  register(mobile,password){return this.request('/auth/register',{method:'POST',body:JSON.stringify({mobile,password})})},
  login(mobile,password){return this.request('/auth/login',{method:'POST',body:JSON.stringify({mobile,password})})},
  me(){return this.request('/auth/me')},logout(){return this.request('/auth/logout',{method:'POST'}).finally(()=>this.setAccessToken(''))},logoutAll(){return this.request('/auth/logout-all',{method:'POST'}).finally(()=>this.setAccessToken(''))},
  products(){return this.request('/products')},product(id){return this.request('/products/'+encodeURIComponent(id))},categories(){return this.request('/categories')},campaigns(){return this.request('/campaigns')},articles(){return this.request('/articles')},search(q){return this.request('/search?q='+encodeURIComponent(q||''))},
  favorites(){return this.request('/favorites')},addFavorite(serverProductId){return this.request('/favorites/'+encodeURIComponent(serverProductId),{method:'POST'})},removeFavorite(serverProductId){return this.request('/favorites/'+encodeURIComponent(serverProductId),{method:'DELETE'})},
  cart(){return this.request('/cart')},addCart(variantId,quantity=1){return this.request('/cart/items',{method:'POST',body:JSON.stringify({variantId,quantity})})},updateCart(id,quantity){return this.request('/cart/items/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify({quantity})})},removeCart(id){return this.request('/cart/items/'+encodeURIComponent(id),{method:'DELETE'})},acceptPrices(){return this.request('/cart/accept-prices',{method:'POST'})},
  checkoutValidate(payload){return this.request('/checkout/validate',{method:'POST',body:JSON.stringify(payload)})},createOrder(payload){return this.request('/orders',{method:'POST',body:JSON.stringify(payload)})},orders(){return this.request('/orders')},order(id){return this.request('/orders/'+encodeURIComponent(id))},
  receiptPresign(payload){return this.request('/payments/receipt/presign',{method:'POST',body:JSON.stringify(payload)})},receiptComplete(payload){return this.request('/payments/receipt/complete',{method:'POST',body:JSON.stringify(payload)})},
  notifications(){return this.request('/notifications')},markNotificationRead(id){return this.request('/notifications/'+encodeURIComponent(id)+'/read',{method:'PATCH'})}
};
function apiUserToLocal(u){return {id:u.id,mobile:u.mobile,name:u.firstName||'کاربر Store',surname:u.lastName||'',email:u.email||'',skinProfile:u.skinProfile||{},points:u.points||0,tier:u.tier||'Bronze',personalizationEnabled:u.personalizationEnabled!==false}}
function normalizeApiProduct(p){
  const variants=(p.variants||[]).map(v=>({id:String(v.id),label:v.label||v.title||'اصلی',sku:v.sku,price:Number(v.price||0),oldPrice:Number(v.compareAtPrice||v.price||0),stock:Number(v.stock||0),active:v.active!==false}));
  const first=variants.find(v=>v.active)||variants[0]||null;
  const categories=(p.categories||[]).filter(Boolean);
  return {...p,id:Number(p.id),serverId:p.serverId,desc:p.shortDescription||p.description||'',category:categories[0]||'همه',subCategory:categories[1]||categories[0]||'همه',need:(p.needs||[])[0]||'همه',skinType:(p.skinTypes||[])[0]||'همه',price:Number(first?.price??p.price??0),oldPrice:Number(first?.oldPrice??p.oldPrice??p.price??0),stock:variants.reduce((s,v)=>s+Math.max(0,v.stock),0),variants,imageUrl:p.image||null,media:p.media||[],img:p.img||'serum.svg',rating:Number(p.rating||0),reviews:Number(p.reviews||0),volume:p.specs?.['حجم']||p.volume||'',use:typeof p.usage==='string'?p.usage:(p.usage?.text||''),ingredients:Array.isArray(p.ingredients)?p.ingredients.join('، '):(p.ingredients||''),features:Array.isArray(p.features)?p.features:[]};
}
window.StoreApi=StoreApi;window.apiUserToLocal=apiUserToLocal;window.normalizeApiProduct=normalizeApiProduct;
