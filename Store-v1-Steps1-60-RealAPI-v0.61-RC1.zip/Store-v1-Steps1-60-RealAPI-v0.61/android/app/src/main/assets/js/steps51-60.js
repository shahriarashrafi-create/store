/* Store v0.60-RC1 — Steps 51–60 real API integration bridge.
   Local mode remains intact for APK/UI smoke tests. Production must use API mode. */
(function(){
  const apiMode=()=>!!(window.StoreApi?.enabled&&window.StoreConfig.environment!=='local');
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const orderStatusFa={DRAFT:'پیش‌نویس',AWAITING_PAYMENT:'در انتظار پرداخت',PAYMENT_SUBMITTED:'رسید ثبت شد',PAYMENT_REVIEW:'در انتظار تأیید پرداخت',PAID:'پرداخت تأیید شد',PREPARING:'در حال آماده‌سازی',SHIPPED:'ارسال شد',DELIVERED:'تحویل شد',CANCELLED:'لغوشده',RETURNED:'مرجوعی'};
  const paymentStatusLocal={CREATED:'awaiting_receipt',SUBMITTED:'pending_confirmation',REVIEW:'pending_confirmation',APPROVED:'approved',REJECTED:'rejected',NEEDS_RESUBMISSION:'rejected'};

  function productByServerId(id){return products.find(p=>String(p.serverId||'')===String(id))||null}
  function variantForProduct(p,id){return (p?.variants||[]).find(v=>typeof v==='object'&&String(v.id)===String(id))||null}
  function localOrderFromApi(o){
    const payment=(o.payments||[])[0]||null;
    return {id:o.id,orderNumber:o.orderNumber,createdAt:new Date(o.createdAt).getTime(),date:new Date(o.createdAt).toLocaleDateString('fa-IR'),status:orderStatusFa[o.status]||o.status,statusKey:String(o.status||'').toLowerCase(),paymentStatus:paymentStatusLocal[payment?.status]||'awaiting_receipt',subtotal:Number(o.subtotal||0),productDiscount:0,couponDiscount:Number(o.discountTotal||0),shippingTotal:Number(o.shippingTotal||0),total:Number(o.finalTotal||0),addressSnapshot:o.addressSnapshot||{},shippingSnapshot:o.shippingSnapshot||{},items:(o.items||[]).map(i=>{const p=productByServerId(i.productId);return {id:p?.id||0,productId:p?.id||0,serverProductId:i.productId,variantId:i.variantId,variantLabel:i.variantSnapshot,name:i.nameSnapshot,qty:Number(i.quantity||1),unitPrice:Number(i.unitPrice||0)}}),payment:payment?{id:payment.id,trackingCode:payment.referenceNumber||'',status:payment.status}:null,paymentId:payment?.id,shipments:o.shipments||[],statusEvents:[{key:'created',label:'ثبت سفارش',at:new Date(o.createdAt).getTime()},{key:String(o.status||'').toLowerCase(),label:orderStatusFa[o.status]||o.status,at:new Date(o.updatedAt||o.createdAt).getTime()}]};
  }

  async function hydrateRemoteCart(){
    if(!apiMode()||!state.user)return false;
    try{const remote=await StoreApi.cart();state.cart=(remote.items||[]).map(i=>{const p=productByServerId(i.productId);if(!p)return null;return {id:p.id,variantId:String(i.variantId),qty:Number(i.quantity||1),priceSnapshot:Number(i.price||0),apiCartItemId:i.id}}).filter(Boolean);save();render();return true}catch(e){console.warn('cart hydrate',e);return false}
  }
  async function mergeGuestCartToServer(guestItems){
    if(!apiMode()||!state.user)return;
    for(const item of guestItems||[]){const p=products.find(x=>Number(x.id)===Number(item.id));const v=variantForProduct(p,item.variantId)||((p?.variants||[]).find(x=>typeof x==='object'));if(!v?.id)continue;try{await StoreApi.addCart(String(v.id),Number(item.qty||1))}catch(e){console.warn('guest cart merge',e)}}
    await hydrateRemoteCart();
  }
  async function hydrateRemoteFavorites(guestFavs=[]){
    if(!apiMode()||!state.user)return;
    try{for(const id of guestFavs){const p=products.find(x=>Number(x.id)===Number(id));if(p?.serverId)await StoreApi.addFavorite(p.serverId).catch(()=>{})}const list=await StoreApi.favorites();state.favs=list.map(p=>Number(p.id)).filter(Boolean);save();render()}catch(e){console.warn('favorites hydrate',e)}
  }
  async function hydrateRemoteOrders(){if(!apiMode()||!state.user)return;try{const rows=await StoreApi.orders();state.orders=rows.map(localOrderFromApi);save();render()}catch(e){console.warn('orders hydrate',e)}}
  async function hydrateRemoteNotifications(){if(!apiMode()||!state.user)return;try{const rows=await StoreApi.notifications();state.notifications=rows.map(n=>({id:n.id,type:n.type,title:n.title,body:n.body,targetType:n.targetType,targetId:n.targetId,isRead:n.isRead,priority:String(n.priority||'INFO').toLowerCase(),createdAt:new Date(n.createdAt).getTime()}));save();render()}catch(e){console.warn('notifications hydrate',e)}}
  async function syncAccountApi(){if(!apiMode()||!state.user)return;await Promise.allSettled([hydrateRemoteCart(),hydrateRemoteFavorites(),hydrateRemoteOrders(),hydrateRemoteNotifications()])}
  window.StoreRealSync={syncAccountApi,hydrateRemoteCart,hydrateRemoteOrders};

  // Login/register: merge guest state after real authentication.
  const oldLogin=window.doLogin,oldRegister=window.doRegister;
  if(oldLogin)window.doLogin=async function(){const guestCart=state.cart.map(x=>({...x})),guestFavs=[...state.favs];await oldLogin();if(state.user&&apiMode()){await mergeGuestCartToServer(guestCart);await hydrateRemoteFavorites(guestFavs);await Promise.allSettled([hydrateRemoteOrders(),hydrateRemoteNotifications()])}};
  if(oldRegister)window.doRegister=async function(){const guestCart=state.cart.map(x=>({...x})),guestFavs=[...state.favs];await oldRegister();if(state.user&&apiMode()){await mergeGuestCartToServer(guestCart);await hydrateRemoteFavorites(guestFavs)}};

  // Favorites: local instant feedback + backend source of truth for signed-in API users.
  const oldToggleFav=window.toggleFav;
  if(oldToggleFav)window.toggleFav=function(id){const p=products.find(x=>Number(x.id)===Number(id)),was=state.favs.includes(Number(id));oldToggleFav(id);if(apiMode()&&state.user&&p?.serverId){(was?StoreApi.removeFavorite(p.serverId):StoreApi.addFavorite(p.serverId)).catch(()=>{toast('همگام‌سازی علاقه‌مندی انجام نشد')})}};

  // CartService object is shared with the approved local UI; add server sync without changing local-mode behavior.
  if(window.CartService){
    const localAdd=CartService.add.bind(CartService),localRemove=CartService.remove.bind(CartService),localQty=CartService.updateQuantity.bind(CartService),localVariant=CartService.changeVariant.bind(CartService);
    CartService.add=function(id,variantId,qty=1){const ok=localAdd(id,variantId,qty);if(ok&&apiMode()&&state.user){const p=products.find(x=>Number(x.id)===Number(id)),v=variantForProduct(p,variantId)||((p?.variants||[]).find(x=>typeof x==='object'));if(v?.id)StoreApi.addCart(String(v.id),Number(qty||1)).then(r=>{const item=state.cart.find(i=>Number(i.id)===Number(id)&&String(i.variantId)===String(v.id));if(item){item.apiCartItemId=r.id;item.qty=Number(r.quantity||item.qty);save()}}).catch(()=>toast('سبد روی سرور همگام نشد'))}return ok};
    CartService.remove=function(key,allowUndo=true){const real=decodeURIComponent(key),item=state.cart.find(i=>`${Number(i.id)}:${i.variantId||'default'}`===real),remote=item?.apiCartItemId;const ok=localRemove(key,allowUndo);if(ok&&apiMode()&&state.user&&remote)StoreApi.removeCart(remote).catch(()=>toast('حذف روی سرور همگام نشد'));return ok};
    CartService.updateQuantity=function(key,delta){const real=decodeURIComponent(key),before=state.cart.find(i=>`${Number(i.id)}:${i.variantId||'default'}`===real),remote=before?.apiCartItemId;const ok=localQty(key,delta);const after=state.cart.find(i=>`${Number(i.id)}:${i.variantId||'default'}`===real);if(ok&&apiMode()&&state.user&&remote){if(after)StoreApi.updateCart(remote,Number(after.qty)).catch(()=>toast('تعداد روی سرور همگام نشد'));else StoreApi.removeCart(remote).catch(()=>{})}return ok};
    CartService.changeVariant=function(key,newVariantId){const real=decodeURIComponent(key),before=state.cart.find(i=>`${Number(i.id)}:${i.variantId||'default'}`===real),oldRemote=before?.apiCartItemId,qty=Number(before?.qty||1);const ok=localVariant(key,newVariantId);if(ok&&apiMode()&&state.user){Promise.resolve(oldRemote?StoreApi.removeCart(oldRemote):null).then(()=>StoreApi.addCart(String(newVariantId),qty)).then(()=>hydrateRemoteCart()).catch(()=>toast('تغییر گزینه روی سرور همگام نشد'))}return ok};
  }

  // Checkout step 2 creates the real order. Step 1 remains the approved address UI.
  const oldCheckoutNext=window.checkoutNextV40;
  if(oldCheckoutNext)window.checkoutNextV40=async function(){
    if(!apiMode()||Number(state.checkoutStep||1)!==2)return oldCheckoutNext();
    const address=state.addresses.find(a=>a.id===state.checkoutDraft.selectedAddressId)||state.addresses.find(a=>a.isDefault)||state.addresses[0];if(!address){toast('یک آدرس انتخاب کن');return}
    const shippingKey=state.checkoutDraft.shippingMethodId;if(!shippingKey){toast('روش ارسال را انتخاب کن');return}
    try{
      await mergeGuestCartToServer(state.cart.filter(x=>!x.apiCartItemId));
      const check=await StoreApi.checkoutValidate({couponCode:state.couponApplied?.code||undefined,shippingMethodKey:shippingKey});
      if(!check.valid){const first=check.issues?.[0];if(first?.type==='PRICE_CHANGED')toast('قیمت یک محصول تغییر کرده؛ سبد را بررسی کن');else if(first?.type==='STOCK_CHANGED')toast('موجودی یک محصول تغییر کرده؛ سبد را بررسی کن');else toast('سبد نیاز به بررسی دارد');return}
      const r=await StoreApi.createOrder({address:{title:address.title||'',recipientName:address.recipientName,recipientPhone:address.recipientPhone,province:address.province,city:address.city,addressLine:address.addressLine,plaque:address.plaque||'',unit:address.unit||'',postalCode:address.postalCode||''},shippingMethodKey:shippingKey,couponCode:state.couponApplied?.code||undefined});
      const items=state.cart.map(i=>{const p=products.find(x=>Number(x.id)===Number(i.id)),v=variantForProduct(p,i.variantId);return {id:p?.id||0,productId:p?.id||0,serverProductId:p?.serverId,variantId:i.variantId,name:p?.name||'',variantLabel:v?.label||'',qty:Number(i.qty||1),unitPrice:Number(v?.price||i.priceSnapshot||0)}});
      const o={id:r.id,orderNumber:r.orderNumber,createdAt:Date.now(),date:new Date().toLocaleDateString('fa-IR'),status:'در انتظار پرداخت',statusKey:'awaiting_payment',paymentStatus:'awaiting_receipt',subtotal:Number(check.subtotal||0),productDiscount:0,couponDiscount:Number(check.discountTotal||0),shippingTotal:Number(check.shippingTotal||0),total:Number(r.finalTotal||check.finalTotal||0),couponCode:state.couponApplied?.code||null,addressSnapshot:{...address},shippingSnapshot:{id:shippingKey,title:shippingKey},items,payment:null,paymentId:r.paymentId,shipments:[],statusEvents:[{key:'created',label:'ثبت سفارش',at:Date.now()},{key:'awaiting_payment',label:'در انتظار پرداخت',at:Date.now()}]};
      state.orders.unshift(o);state.activeOrderId=o.id;state.checkoutStep=3;save();render();window.scrollTo(0,0);
    }catch(e){console.error(e);toast(e.payload?.error==='CHECKOUT_REVALIDATION_FAILED'?'قیمت یا موجودی تغییر کرده است':'ثبت سفارش انجام نشد؛ دوباره تلاش کن')}
  };
  window.checkoutNext=window.checkoutNextV40;

  // Keep the selected File object only in memory; never serialize receipt bytes into local storage.
  const oldReceiptChanged=window.receiptChangedV40;
  if(oldReceiptChanged)window.receiptChangedV40=function(input){window.__storeReceiptFile=input.files?.[0]||null;return oldReceiptChanged(input)};
  const oldSubmitReceipt=window.submitReceiptV40;
  if(oldSubmitReceipt)window.submitReceiptV40=async function(){
    if(!apiMode())return oldSubmitReceipt();
    const o=state.orders.find(x=>x.id===state.activeOrderId)||state.orders.find(x=>x.paymentStatus==='awaiting_receipt'||x.paymentStatus==='rejected');if(!o?.paymentId){toast('اطلاعات پرداخت سفارش پیدا نشد');return}
    const file=window.__storeReceiptFile||null,reference=($('#trackV40')?.value||'').trim();if(!file&&reference.length<3){toast('تصویر رسید یا شماره پیگیری را ثبت کن');return}
    try{let storageKey,mimeType,size;if(file){const pre=await StoreApi.receiptPresign({paymentId:o.paymentId,mimeType:file.type||'image/jpeg'});const put=await fetch(pre.url,{method:'PUT',headers:{'Content-Type':file.type||'image/jpeg'},body:file});if(!put.ok)throw new Error('UPLOAD_FAILED');storageKey=pre.key;mimeType=file.type||'image/jpeg';size=file.size}
      await StoreApi.receiptComplete({paymentId:o.paymentId,storageKey,mimeType,size,referenceNumber:reference||undefined});o.paymentStatus='pending_confirmation';o.status='در انتظار تأیید پرداخت';o.statusKey='payment_review';o.payment={id:o.paymentId,trackingCode:reference,receiptName:file?.name||'',status:'REVIEW',submittedAt:Date.now()};state.cart=[];state.couponApplied=null;state.couponCode='';state.activeOrderId=null;state.checkoutStep=1;state.paymentResultData={type:'success',orderId:o.id,message:'رسید پرداخت ثبت شد و در انتظار بررسی است.'};window.__storeReceiptFile=null;save();haptic();go('paymentResult')
    }catch(e){console.error(e);state.paymentResultData={type:'error',orderId:o.id,message:'ارسال رسید کامل نشد؛ سفارش شما حفظ شده است.'};save();go('paymentResult')}
  };
  window.placeOrder=window.submitReceiptV40;

  // API-aware logout and background refresh.
  const oldLogout=window.logout;
  if(oldLogout)window.logout=function(){const r=oldLogout();if(apiMode()){StoreApi.setAccessToken('');sessionStorage.removeItem('store-api-user')}return r};
  if(apiMode())setTimeout(async()=>{try{if(!state.user&&await StoreApi.refreshSession())state.user=AuthService.currentUser();await sleep(120);if(state.user)await syncAccountApi()}catch(e){}},900);
})();
