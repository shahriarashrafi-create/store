const CACHE='store-v061-real-api-shell';
const FALLBACK_IMAGE='./assets/illustrations/empty-search.svg';
const CORE=['./','./index.html','./css/tokens.css','./css/components.css','./css/pages.css','./css/steps21-30.css','./css/steps31-40.css','./css/steps41-50.css','./js/config.js','./js/data.js','./js/storage.js','./js/api.js','./js/router.js','./js/app.js','./js/steps21-30.js','./js/steps31-40.js','./js/steps41-50.js','./js/steps51-60.js','./assets/icons/logo-mark.svg',FALLBACK_IMAGE,'./assets/illustrations/onboarding-discover.svg','./assets/illustrations/onboarding-details.svg','./assets/illustrations/onboarding-consult.svg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  const url=new URL(e.request.url);
  if(url.origin!==self.location.origin)return;
  if(e.request.mode==='navigate'){
    e.respondWith(fetch(e.request).then(r=>{if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put('./index.html',copy))}return r}).catch(()=>caches.match('./index.html')));
    return;
  }
  e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request).then(r=>{if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy))}return r}).catch(()=>e.request.destination==='image'?caches.match(FALLBACK_IMAGE):Response.error())));
});

// Step 41 push-ready hooks. A provider/backend can send Web Push payloads later.
self.addEventListener('push',event=>{
  let data={};try{data=event.data?event.data.json():{}}catch(e){data={title:'Store',body:event.data?.text()||'اعلان جدید Store'}}
  const title=data.title||'Store',options={body:data.body||'',icon:'./assets/icons/logo-mark.svg',badge:'./assets/icons/logo-mark.svg',data:{url:data.url||'./index.html#notifications'}};
  event.waitUntil(self.registration.showNotification(title,options));
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();const url=event.notification.data?.url||'./index.html#notifications';
  event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(list=>{for(const client of list){if('focus' in client){client.navigate?.(url);return client.focus()}}return self.clients.openWindow?self.clients.openWindow(url):null}));
});
