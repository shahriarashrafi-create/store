# Store v0.30 — Steps 1–30

این بسته ادامه مستقیم v0.20 است و تصمیم‌های تأییدشده قدم‌های ۲۱ تا ۳۰ را روی همه قابلیت‌های قدم‌های ۱ تا ۲۰ اضافه می‌کند.

## تغییرات اصلی v0.30

- Product Detail کامل با گالری سه‌تصویری، Thumbnail، Swipe، Fullscreen Viewer و Zoom
- Variant انتخابی با قیمت و موجودی مستقل در سطح SKU، وضعیت موجود/محدود/ناموجود و CTA ثابت پایین صفحه
- Cart آگاه از Variant و Snapshot قیمت، محدودیت تعداد بر اساس موجودی و Revalidation قبل از Checkout
- ساختار محصول برای توضیح کوتاه، نوع پوست/مو، ویژگی‌ها، مشخصات، روش مصرف، هشدارها و جایگاه در روتین
- Review بدون داده ساختگی: نمایش فقط نظرهای تأییدشده، Verified Purchase، فیلتر/مرتب‌سازی، Helpful Vote و ثبت نظر در حالت Pending برای Moderation آینده
- Related / Complementary Products با قواعد سازگاری و Cross-sell محدود در Cart
- Search فارسی با Normalization حروف فارسی/عربی، تحمل خطای تایپی محدود، پیشنهاد زنده برای Product/Category/Need، Recent Search و نتایج مشترک با Product List
- Filter چندانتخابی برای نوع پوست، نوع مو، نیاز، برند و ویژگی‌ها + بازه قیمت + فقط موجود + فقط تخفیف‌دار
- Favorites برای مهمان، Merge با حساب محلی بعد از Login، نگهداری محصول ناموجود و Sort/Category Filter ساده
- Backend schema آماده برای product_variants، product_media، reviews، helpful votes، favorites، relations و discount rules
- Assetهای گالری نمونه برای تست UI محلی

## Build

ZIP را در ریشه Repository `store` آپلود کنید. Workflow فعلی GitHub Actions پروژه Android Gradle را پیدا می‌کند و Debug APK را می‌سازد.

- versionCode: 30
- versionName: `0.30-steps1-30-product-discovery`
- PWA cache: `store-v030-shell`
- Local storage: `store-v030` با Migration از v0.20 و نسخه‌های قبل

## نکته داده واقعی

محصولات فعلی همچنان داده آزمایشی UI هستند. اطلاعات حساس مثل INCI، ادعاهای تخصصی، قیمت/موجودی واقعی، Review واقعی و SKUهای نهایی باید هنگام اتصال کاتالوگ/Backend از منبع رسمی دریافت شوند. پنل مدیریت کامل طبق Roadmap در قدم ۴۵ ساخته می‌شود.
