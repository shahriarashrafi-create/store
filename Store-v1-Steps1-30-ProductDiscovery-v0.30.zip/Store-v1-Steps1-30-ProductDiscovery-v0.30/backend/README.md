# Store Backend Scaffold — through Step 30

Target architecture: Node.js REST API + PostgreSQL + object storage.

The schema now anticipates:
- users and optional skin/hair profile
- hierarchical categories and needs
- products with structured description/usage/spec data
- product variants with SKU-level price and stock
- product media gallery
- banners/campaigns
- orders, order items and payment receipts
- loyalty ledger
- favorites
- moderated product reviews and helpful votes
- manual similar/complementary product relations
- discount-rule scaffolding

The current APK/PWA runtime still uses local prototype data. No production authentication, public API, object storage, payment gateway or Admin backend is enabled yet.
