# Implementation — Steps 21–30

## Step 21 — Product Detail
- Header فرعی با Back و Favorite
- اطلاعات تصمیم خرید قبل از توضیحات طولانی
- قیمت/تخفیف/موجودی/Variant
- CTA ثابت پایین صفحه
- Accordionهای معرفی، مناسب برای، روش مصرف، مشخصات، ترکیبات و هشدارها
- Back/Deep Link با Router موجود

## Step 22 — Gallery
- سه Media Item در نسخه آزمایشی: تصویر اصلی + بسته‌بندی + نمای نزدیک
- Swipe، Dot Counter، Thumbnail
- Fullscreen Viewer با دکمه‌های Zoom، Pinch Zoom و Swipe
- Placeholder/fallback در Product Card
- ساختار آماده افزودن Video Media در Backend

## Step 23 — Price / Discount / Stock
- Variant helper با price / compare price / stock مستقل
- Low stock threshold فعلی 3 در UI Prototype و ستون قابل تنظیم در Backend
- Cart با Variant ID و Snapshot قیمت
- Revalidation موجودی و قیمت پیش از Checkout/Place Order
- Backend `product_variants` و `discount_rules`

## Step 24 — Structured Product Content
- short description
- skin/hair types
- needs/features
- specs
- ingredients/INCI placeholder تا دریافت منبع رسمی
- warnings / claims-ready schema

## Step 25 — Usage / Expert Information
- زمان و دفعات مصرف
- مقدار مصرف
- جایگاه در روتین
- هشدارها
- Box «نکته Store» با تأکید بر راهنمای عمومی و عدم تشخیص پزشکی

## Step 26 — Reviews
- هیچ Review متنی Seed نشده است
- Rating UI از Reviewهای Approved محاسبه می‌شود
- ثبت Review با وضعیت Pending
- Verified Purchase بر اساس سفارش تحویل‌شده
- Sort/Filter، Helpful Vote و Snapshot نوع پوست/مو
- Backend moderation-ready tables

## Step 27 — Related Products
- Similar بر اساس category/subcategory/need/profile compatibility
- Complementary با ترجیح زیرگروه متفاوت و موجودی مثبت
- حذف محصول فعلی و محصول ناموجود از پیشنهادها
- Cross-sell محدود در Cart
- Backend `product_relations` برای Override دستی Admin آینده

## Step 28 — Search
- Normalization ی/ي، ک/ك، آ/ا، نیم‌فاصله و اعداد فارسی
- Fuzzy tolerance محدود برای Tokenهای طولانی
- جست‌وجو روی نام، برند، دسته، Need، Features، Skin/Hair type، حجم و SKU
- Live Suggestion برای Product/Category/Need
- Recent Search با حذف تکی/کامل
- Search Results از Product Grid/Filter/Sort مشترک استفاده می‌کند

## Step 29 — Filter & Sort
- Multi-select Skin Type / Hair Type / Need / Brand / Feature
- Category/Subcategory
- Min/Max Price
- In-stock only / Discount only
- Active Filter Chips و Clear
- Bottom Sheet با Result Count زنده
- Sort: پیشنهادی، پرفروش، جدید، ارزان، گران، بیشترین تخفیف

## Step 30 — Favorites
- Guest Favorites در Local Storage
- Merge با Favorites حساب محلی پس از Login
- Persist روی Account local scaffold
- نگهداری محصول ناموجود در Favorites
- Category filter و Sort ساده در صفحه Favorites

## Architecture

قابلیت‌های v0.30 در فایل ماژولار `js/steps21-30.js` و stylesheet مستقل `css/steps21-30.css` اضافه شده‌اند تا معماری Step 10 حفظ شود و مهاجرت Backend ساده‌تر بماند.
