# VALIDATION — Store v0.30

## Passed

- `node --check` passed for every JavaScript file in the Android/PWA assets and backend scaffold, including `steps21-30.js`.
- Runtime VM smoke test passed for Home, Product Detail, Products, Search, Favorites, Cart and Filter Sheet.
- Runtime smoke test passed for Variant-aware Add to Cart and cart total.
- Runtime smoke test confirmed Persian fuzzy search can match `ضد افتاب` to the sunscreen product after normalization.
- `manifest.webmanifest` and `backend/package.json` parse as valid JSON.
- Android Manifest, Android resource XML and all SVG assets parse successfully (95 XML/SVG files checked).
- CSS brace-balance validation passed for all stylesheets.
- All 16 new product-gallery media assets exist and parse as valid SVG.
- Conservative emoji scan found no emoji characters in main Store JS/data UI source.
- `versionCode 30` and `versionName 0.30-steps1-30-product-discovery` confirmed.
- PWA cache key updated to `store-v030-shell` and includes the Step 21–30 JS/CSS modules.
- Storage key updated to `store-v030` with migration from `store-v020` and earlier keys.
- Backend SQL includes structured product fields, variants, media, favorites, review moderation/helpful votes, product relations and discount rule scaffolds.

## Step-specific checks

- Product Detail renders gallery thumbnails, structured sections, reviews and related products.
- Gallery functions include swipe, fullscreen viewer and zoom controls/pinch handling.
- Product Cards use approved reviews only; no seeded/fake review text is added in v0.30.
- Variant price/stock is used by Product Detail, Cart and Checkout totals.
- Cart validates current local price/stock snapshot before Checkout and Place Order.
- Search normalizes Persian/Arabic character variants and uses the common Product Grid.
- Filter Sheet supports multi-select skin/hair/need/brand/feature, price range, stock-only and discount-only.
- Favorites preserve unavailable products and merge guest favorites into the local signed-in account scaffold.

## Gradle build note

A local `:app:assembleDebug` attempt was made. It could not start because this environment cannot resolve `services.gradle.org`, so the Gradle 8.7 distribution cannot be downloaded. The failure is a network/DNS limitation before Android compilation begins. GitHub Actions remains the final APK compile check, as in the previously accepted builds.

## Data note

Current catalog content is prototype/local data. Full INCI, official claims, real prices/stocks, official variant SKUs and public review data should be supplied by the real catalog/backend. The UI intentionally does not seed fake review content; new local reviews remain `pending` until future Admin moderation in Step 45.
