import test from 'node:test';
import assert from 'node:assert/strict';
test('runtime supports required Node version',()=>{const major=Number(process.versions.node.split('.')[0]);assert.ok(major>=20);});
