# Weblines Runtime Fix

Fixes the successful-build / crashing-runtime issue:
- TypeScript now compiles `src/server.ts` to `dist/server.js`.
- Docker verifies `dist/server.js` exists during build.
- Startup failures are printed as `STORE_API_STARTUP_ERROR`.
- OpenSSL is installed for Prisma compatibility on Alpine.
- `/` returns a lightweight runtime status; `/health` also checks PostgreSQL.
