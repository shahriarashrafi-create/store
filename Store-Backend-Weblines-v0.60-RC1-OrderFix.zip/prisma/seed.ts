import { PrismaClient } from '@prisma/client';
import argon2 from 'argon2';

const prisma = new PrismaClient();

async function main() {
  const roles = [
    ['owner', 'Owner', ['*']],
    ['admin', 'Admin', ['dashboard.read','products.*','orders.*','payments.*','campaigns.*','content.*','users.read','audit.read']],
    ['order_manager', 'Order Manager', ['dashboard.read','orders.*','payments.*','users.read']],
    ['catalog_manager', 'Catalog Manager', ['dashboard.read','products.*','categories.*']],
    ['content_manager', 'Content Manager', ['dashboard.read','campaigns.*','content.*']],
    ['support', 'Support', ['dashboard.read','orders.read','payments.read','users.read']]
  ] as const;
  for (const [key, title, permissions] of roles) {
    await prisma.role.upsert({ where: { key }, update: { title, permissions: [...permissions] }, create: { key, title, permissions: [...permissions] } });
  }

  const skin = await prisma.category.upsert({
    where: { slug: 'skin-care' }, update: {}, create: { name: 'مراقبت پوست', slug: 'skin-care', sortOrder: 1 }
  });
  const product = await prisma.product.upsert({
    where: { slug: 'trust-hydrating-serum-demo' },
    update: {},
    create: {
      name: 'سرم آبرسان Trust — نمونه توسعه', slug: 'trust-hydrating-serum-demo', brand: 'Trust',
      shortDescription: 'داده Seed برای تست اتصال API و PostgreSQL.', skinTypes: ['خشک','مختلط'], needs: ['خشکی'],
      categories: { create: { categoryId: skin.id, isPrimary: true } },
      variants: { create: { sku: 'TRUST-DEMO-HYD-30', title: '۳۰ میلی‌لیتر', price: 498000n, compareAtPrice: 545000n, stock: 12 } }
    }
  });

  const shipping = [
    { key: 'post', title: 'پست پیشتاز', baseCost: 75000n, etaText: '۲ تا ۵ روز کاری', priority: 1 },
    { key: 'tipax', title: 'تیپاکس', baseCost: 95000n, etaText: '۱ تا ۴ روز کاری', priority: 2 }
  ];
  for (const s of shipping) await prisma.shippingMethod.upsert({ where: { key: s.key }, update: s, create: s });

  if (process.env.SEED_ADMIN_MOBILE && process.env.SEED_ADMIN_PASSWORD) {
    const owner = await prisma.role.findUniqueOrThrow({ where: { key: 'owner' } });
    const admin = await prisma.adminUser.upsert({
      where: { mobile: process.env.SEED_ADMIN_MOBILE },
      update: {},
      create: { mobile: process.env.SEED_ADMIN_MOBILE, displayName: 'Store Owner', passwordHash: await argon2.hash(process.env.SEED_ADMIN_PASSWORD) }
    });
    await prisma.adminUserRole.upsert({ where: { adminUserId_roleId: { adminUserId: admin.id, roleId: owner.id } }, update: {}, create: { adminUserId: admin.id, roleId: owner.id } });
  }
  console.log('Seed complete:', product.slug);
}

main().finally(() => prisma.$disconnect());
