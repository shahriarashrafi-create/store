import crypto from 'node:crypto';
export const randomToken = () => crypto.randomBytes(32).toString('base64url');
export const sha256 = (value: string) => crypto.createHash('sha256').update(value).digest('hex');
export function normalizeIranMobile(input: string) {
  const digits = String(input || '').replace(/[^0-9۰-۹]/g, '').replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
  if (/^09\d{9}$/.test(digits)) return digits;
  if (/^989\d{9}$/.test(digits)) return `0${digits.slice(2)}`;
  throw Object.assign(new Error('INVALID_MOBILE'), { statusCode: 400, code: 'INVALID_MOBILE' });
}
