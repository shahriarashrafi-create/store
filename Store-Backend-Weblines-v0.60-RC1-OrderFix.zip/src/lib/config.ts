import { z } from 'zod';

const bool = z.string().optional().transform(v => String(v).toLowerCase() === 'true');
const schema = z.object({
  NODE_ENV: z.enum(['development','test','production']).default('development'),
  PORT: z.coerce.number().int().positive().default(3000),
  DATABASE_URL: z.string().min(1),
  JWT_ACCESS_SECRET: z.string().min(24),
  ACCESS_TOKEN_TTL: z.string().default('15m'),
  REFRESH_TOKEN_DAYS: z.coerce.number().int().positive().default(30),
  CORS_ORIGINS: z.string().default('http://localhost:5173,http://localhost:5174'),
  COOKIE_DOMAIN: z.string().optional(),
  COOKIE_SECURE: bool,
  S3_ENDPOINT: z.string().url().optional(),
  S3_REGION: z.string().default('us-east-1'),
  S3_BUCKET: z.string().default('store-media'),
  S3_ACCESS_KEY: z.string().optional(),
  S3_SECRET_KEY: z.string().optional(),
  S3_FORCE_PATH_STYLE: bool,
  PUBLIC_MEDIA_BASE_URL: z.string().optional(),
  FREE_SHIPPING_THRESHOLD: z.coerce.bigint().default(1500000n),
  STOCK_RESERVATION_MINUTES: z.coerce.number().int().positive().default(30)
});

export const config = schema.parse(process.env);
export const corsOrigins = config.CORS_ORIGINS.split(',').map(x => x.trim()).filter(Boolean);
