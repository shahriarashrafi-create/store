import { config } from './config.js';
export class AppError extends Error {
  statusCode: number;
  code: string;
  details?: unknown;
  constructor(statusCode: number, code: string, details?: unknown) {
    super(code); this.statusCode = statusCode; this.code = code; this.details = details;
  }
}
export function bigintToNumber(value: bigint | number | null | undefined) { return value == null ? null : Number(value); }
function mediaUrl(key:string|null|undefined){if(!key)return null;if(/^https?:\/\//i.test(key))return key;const base=(config.PUBLIC_MEDIA_BASE_URL||'').replace(/\/$/,'');return base?`${base}/${String(key).replace(/^\//,'')}`:key;}
export function publicProduct(p: any) {
  const primary = p.media?.find((m:any)=>m.isPrimary) || p.media?.[0];
  const first = p.variants?.find((v:any)=>v.active) || p.variants?.[0];
  return {
    id: p.publicId, serverId: p.id, name: p.name, slug: p.slug, brand: p.brand,
    shortDescription: p.shortDescription, description: p.description,
    features: p.features, skinTypes: p.skinTypes, hairTypes: p.hairTypes, needs: p.needs,
    ingredients: p.ingredients, usage: p.usage, warnings: p.warnings, specs: p.specs,
    active: p.active, isNew: p.isNew,
    image: mediaUrl(primary?.storageKey),
    media: (p.media||[]).map((m:any)=>({id:m.id,key:m.storageKey,url:mediaUrl(m.storageKey),isPrimary:m.isPrimary,sortOrder:m.sortOrder})),
    categories: (p.categories||[]).map((x:any)=>x.category?.name).filter(Boolean),
    variants: (p.variants||[]).map((v:any)=>({id:v.id,sku:v.sku,label:v.title,price:bigintToNumber(v.price),compareAtPrice:bigintToNumber(v.compareAtPrice),stock:v.stock,active:v.active,lowStockThreshold:v.lowStockThreshold})),
    price: bigintToNumber(first?.price), oldPrice: bigintToNumber(first?.compareAtPrice ?? first?.price), stock: first?.stock ?? 0
  };
}
