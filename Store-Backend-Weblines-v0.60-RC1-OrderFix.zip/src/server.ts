import { buildApp } from './app.js';
import { config } from './lib/config.js';

try {
  const app = await buildApp();
  await app.listen({ port: config.PORT, host: '0.0.0.0' });
  app.log.info({ port: config.PORT }, 'Store API started');
} catch (error) {
  console.error('STORE_API_STARTUP_ERROR', error);
  process.exit(1);
}
