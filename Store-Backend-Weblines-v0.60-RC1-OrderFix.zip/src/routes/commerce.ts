import type { FastifyInstance } from 'fastify';
import { Prisma } from '@prisma/client';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { AppError, bigintToNumber } from '../lib/http.js';
import { config } from '../lib/config.js';
import { presignPrivateReceipt } from '../services/storage.js';

async function activeCart(userId:string){
  return prisma.cart.findFirst({where:{userId,status:'active'},include:{items:{include:{product:true,variant:true}}}});
}
function lineSubtotal(item:any){return item.variant.price*BigInt(item.quantity);}
async function couponDiscount(code:string|undefined,subtotal:bigint,shipping:bigint){
  if(!code)return {discount:0n,shippingDiscount:0n,coupon:null as any};
  const now=new Date();const coupon=await prisma.coupon.findFirst({where:{code:code.trim().toUpperCase(),active:true,AND:[{OR:[{startsAt:null},{startsAt:{lte:now}}]},{OR:[{endsAt:null},{endsAt:{gte:now}}]}]}});
  if(!coupon)throw new AppError(400,'INVALID_COUPON');if(subtotal<coupon.minOrder)throw new AppError(400,'COUPON_MIN_ORDER',{minOrder:Number(coupon.minOrder)});
  if(coupon.type==='free_shipping')return {discount:0n,shippingDiscount:shipping,coupon};
  let d=coupon.type==='percent'?subtotal*coupon.value/100n:coupon.value;if(coupon.maxDiscount&&d>coupon.maxDiscount)d=coupon.maxDiscount;if(d>subtotal)d=subtotal;return {discount:d,shippingDiscount:0n,coupon};
}
async function validateCart(userId:string,couponCode?:string,shippingMethodRef?:string){
  const cart=await activeCart(userId);if(!cart||!cart.items.length)throw new AppError(400,'EMPTY_CART');
  const issues:any[]=[];let subtotal=0n;
  for(const i of cart.items){if(!i.product.active||!i.variant.active)issues.push({type:'VARIANT_NOT_AVAILABLE',itemId:i.id,variantId:i.variantId});if(i.quantity>i.variant.stock)issues.push({type:'STOCK_CHANGED',itemId:i.id,available:i.variant.stock});if(i.priceSnapshot!==null&&i.priceSnapshot!==i.variant.price)issues.push({type:'PRICE_CHANGED',itemId:i.id,from:Number(i.priceSnapshot),to:Number(i.variant.price)});subtotal+=lineSubtotal(i);}
  let shipping=0n;let method:any=null;if(shippingMethodRef){const isUuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(shippingMethodRef);method=isUuid?await prisma.shippingMethod.findFirst({where:{active:true,id:shippingMethodRef}}):await prisma.shippingMethod.findFirst({where:{active:true,key:shippingMethodRef}});if(!method)issues.push({type:'SHIPPING_UNAVAILABLE'});else shipping=(method.freeThreshold&&subtotal>=method.freeThreshold)?0n:method.baseCost;}
  const c=await couponDiscount(couponCode,subtotal,shipping).catch(e=>{issues.push({type:e.code||'INVALID_COUPON',details:e.details});return {discount:0n,shippingDiscount:0n,coupon:null}});
  const shippingTotal=shipping-c.shippingDiscount;const finalTotal=subtotal-c.discount+shippingTotal;
  return {cart,issues,subtotal,discount:c.discount,shippingTotal,finalTotal,method,coupon:c.coupon};
}

export async function commerceRoutes(app:FastifyInstance){
  const auth=(app as any).authenticateUser;
  app.post('/checkout/validate',{preHandler:auth},async(request:any)=>{const b=z.object({couponCode:z.string().optional(),shippingMethodId:z.string().optional(),shippingMethodKey:z.string().optional()}).parse(request.body||{});const v=await validateCart(request.user.sub,b.couponCode,b.shippingMethodId||b.shippingMethodKey);return {valid:v.issues.length===0,issues:v.issues,subtotal:bigintToNumber(v.subtotal),discountTotal:bigintToNumber(v.discount),shippingTotal:bigintToNumber(v.shippingTotal),finalTotal:bigintToNumber(v.finalTotal)};});
  app.post('/cart/accept-prices',{preHandler:auth},async(request:any)=>{const cart=await activeCart(request.user.sub);if(!cart)throw new AppError(404,'CART_NOT_FOUND');await prisma.$transaction(cart.items.map(i=>prisma.cartItem.update({where:{id:i.id},data:{priceSnapshot:i.variant.price}})));return {ok:true};});

  app.post('/orders',{preHandler:auth},async(request:any)=>{
    const addressInput=z.object({title:z.string().optional(),recipientName:z.string().min(2),recipientPhone:z.string().min(10),province:z.string().min(2),city:z.string().min(2),addressLine:z.string().min(8),plaque:z.string().optional(),unit:z.string().optional(),postalCode:z.string().optional()});
    const b=z.object({addressId:z.string().uuid().optional(),address:addressInput.optional(),shippingMethodId:z.string().optional(),shippingMethodKey:z.string().optional(),couponCode:z.string().optional()}).refine(x=>!!(x.addressId||x.address),{message:'ADDRESS_REQUIRED'}).refine(x=>!!(x.shippingMethodId||x.shippingMethodKey),{message:'SHIPPING_REQUIRED'}).parse(request.body);
    const address=b.addressId?await prisma.address.findFirst({where:{id:b.addressId,userId:request.user.sub}}):b.address;if(!address)throw new AppError(400,'ADDRESS_NOT_FOUND');
    const validated=await validateCart(request.user.sub,b.couponCode,b.shippingMethodId||b.shippingMethodKey);if(validated.issues.length)throw new AppError(409,'CHECKOUT_REVALIDATION_FAILED',validated.issues);
    const result=await prisma.$transaction(async tx=>{
      const expiresAt=new Date(Date.now()+config.STOCK_RESERVATION_MINUTES*60000);
      await tx.stockReservation.updateMany({where:{status:'RESERVED',expiresAt:{lte:new Date()}},data:{status:'EXPIRED'}});
      for(const item of validated.cart.items){
        await tx.$queryRaw(Prisma.sql`SELECT id FROM "ProductVariant" WHERE id = ${item.variantId}::uuid FOR UPDATE`);
        const variant=await tx.productVariant.findUniqueOrThrow({where:{id:item.variantId}});
        const agg=await tx.stockReservation.aggregate({_sum:{quantity:true},where:{variantId:item.variantId,status:'RESERVED',expiresAt:{gt:new Date()}}});
        const available=variant.stock-(agg._sum.quantity||0);if(item.quantity>available)throw new AppError(409,'STOCK_CHANGED',{variantId:item.variantId,available});
      }
      const order=await tx.order.create({data:{userId:request.user.sub,status:'AWAITING_PAYMENT',addressSnapshot:{title:address.title,recipientName:address.recipientName,recipientPhone:address.recipientPhone,province:address.province,city:address.city,addressLine:address.addressLine,plaque:address.plaque,unit:address.unit,postalCode:address.postalCode},shippingSnapshot:{methodId:validated.method.id,title:validated.method.title,carrier:validated.method.carrier,etaText:validated.method.etaText},subtotal:validated.subtotal,discountTotal:validated.discount,shippingTotal:validated.shippingTotal,finalTotal:validated.finalTotal,items:{create:validated.cart.items.map(i=>({productId:i.productId,variantId:i.variantId,skuSnapshot:i.variant.sku,nameSnapshot:i.product.name,variantSnapshot:i.variant.title,unitPrice:i.variant.price,compareAtPrice:i.variant.compareAtPrice,quantity:i.quantity}))},reservations:{create:validated.cart.items.map(i=>({productId:i.productId,variantId:i.variantId,quantity:i.quantity,expiresAt}))},payments:{create:{method:'bank_transfer',amount:validated.finalTotal,status:'CREATED'}}},include:{payments:true}});
      await tx.cart.update({where:{id:validated.cart.id},data:{status:'converted'}});
      return order;
    },{isolationLevel:Prisma.TransactionIsolationLevel.Serializable});
    return {id:result.id,orderNumber:result.orderNumber,status:result.status,finalTotal:Number(result.finalTotal),paymentId:result.payments[0]?.id,reservationExpiresAt:new Date(Date.now()+config.STOCK_RESERVATION_MINUTES*60000)};
  });

  app.get('/orders',{preHandler:auth},async(request:any)=>{const rows=await prisma.order.findMany({where:{userId:request.user.sub},include:{items:true,payments:true,shipments:true},orderBy:{createdAt:'desc'},take:100});return rows.map(o=>({...o,subtotal:Number(o.subtotal),discountTotal:Number(o.discountTotal),shippingTotal:Number(o.shippingTotal),finalTotal:Number(o.finalTotal),items:o.items.map(i=>({...i,unitPrice:Number(i.unitPrice),compareAtPrice:bigintToNumber(i.compareAtPrice)})),payments:o.payments.map(p=>({...p,amount:Number(p.amount)}))}));});
  app.get('/orders/:id',{preHandler:auth},async(request:any)=>{const o=await prisma.order.findFirst({where:{userId:request.user.sub,OR:[{id:request.params.id},{orderNumber:Number(request.params.id)||-1}]},include:{items:true,payments:true,shipments:true}});if(!o)throw new AppError(404,'ORDER_NOT_FOUND');return {...o,subtotal:Number(o.subtotal),discountTotal:Number(o.discountTotal),shippingTotal:Number(o.shippingTotal),finalTotal:Number(o.finalTotal)};});

  app.post('/payments/receipt/presign',{preHandler:auth},async(request:any)=>{const b=z.object({paymentId:z.string().uuid(),mimeType:z.enum(['image/jpeg','image/png','image/webp','application/pdf'])}).parse(request.body);const payment=await prisma.payment.findFirst({where:{id:b.paymentId,order:{userId:request.user.sub}}});if(!payment)throw new AppError(404,'PAYMENT_NOT_FOUND');return presignPrivateReceipt(payment.orderId,b.mimeType);});
  app.post('/payments/receipt/complete',{preHandler:auth},async(request:any)=>{const b=z.object({paymentId:z.string().uuid(),storageKey:z.string().min(8).optional(),mimeType:z.string().optional(),size:z.number().int().positive().max(10*1024*1024).optional(),referenceNumber:z.string().max(80).optional()}).refine(x=>!!(x.storageKey||x.referenceNumber),{message:'RECEIPT_OR_REFERENCE_REQUIRED'}).parse(request.body);const payment=await prisma.payment.findFirst({where:{id:b.paymentId,order:{userId:request.user.sub}}});if(!payment)throw new AppError(404,'PAYMENT_NOT_FOUND');let mediaId:string|undefined;if(b.storageKey){const media=await prisma.media.create({data:{ownerType:'PAYMENT_RECEIPT',ownerId:payment.id,storageKey:b.storageKey,mimeType:b.mimeType||'application/octet-stream',size:b.size,visibility:'PRIVATE'}});mediaId=media.id}await prisma.$transaction([prisma.payment.update({where:{id:payment.id},data:{receiptMediaId:mediaId,referenceNumber:b.referenceNumber,status:'REVIEW',submittedAt:new Date()}}),prisma.order.update({where:{id:payment.orderId},data:{status:'PAYMENT_REVIEW'}})]);return {ok:true,status:'PAYMENT_REVIEW'};});
}
