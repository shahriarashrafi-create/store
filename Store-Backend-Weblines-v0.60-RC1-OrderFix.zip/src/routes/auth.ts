import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { AppError } from '../lib/http.js';
import { normalizeIranMobile } from '../lib/security.js';
import { createUserSession, hashPassword, revokeRefresh, rotateUserSession, verifyPassword } from '../services/auth.js';
import { config } from '../lib/config.js';

const passwordSchema = z.string().min(8).max(128).regex(/[A-Za-z]/).regex(/[0-9]/);
const refreshCookie = 'store_refresh';
function cookieOpts(){return {httpOnly:true, secure:config.COOKIE_SECURE, sameSite:config.COOKIE_SECURE?'none' as const:'lax' as const, path:'/api/v1/auth', domain:config.COOKIE_DOMAIN || undefined, maxAge:config.REFRESH_TOKEN_DAYS*86400};}
function userPayload(u:any){return {id:u.id,mobile:u.mobile,firstName:u.firstName,lastName:u.lastName,email:u.email,status:u.status,skinProfile:u.skinProfile,personalizationEnabled:u.personalizationEnabled};}

export async function authRoutes(app: FastifyInstance){
  app.post('/auth/register', async (request, reply) => {
    const body=z.object({mobile:z.string(),password:passwordSchema}).parse(request.body);
    const mobile=normalizeIranMobile(body.mobile);
    if(await prisma.user.findUnique({where:{mobile}})) throw new AppError(409,'MOBILE_ALREADY_REGISTERED');
    const user=await prisma.user.create({data:{mobile,passwordHash:await hashPassword(body.password)}});
    const {session,refreshToken}=await createUserSession(user.id,request.headers['user-agent'],request.ip);
    const accessToken=await reply.jwtSign({sub:user.id,kind:'user',sid:session.id},{expiresIn:config.ACCESS_TOKEN_TTL});
    reply.setCookie(refreshCookie,refreshToken,cookieOpts());
    return {accessToken,user:userPayload(user)};
  });

  app.post('/auth/login', async (request, reply) => {
    const body=z.object({mobile:z.string(),password:z.string()}).parse(request.body);
    const mobile=normalizeIranMobile(body.mobile);
    const user=await prisma.user.findUnique({where:{mobile}});
    if(!user || user.status!=='ACTIVE' || !(await verifyPassword(user.passwordHash,body.password))) throw new AppError(401,'INVALID_CREDENTIALS');
    const {session,refreshToken}=await createUserSession(user.id,request.headers['user-agent'],request.ip);
    const accessToken=await reply.jwtSign({sub:user.id,kind:'user',sid:session.id},{expiresIn:config.ACCESS_TOKEN_TTL});
    reply.setCookie(refreshCookie,refreshToken,cookieOpts());
    return {accessToken,user:userPayload(user)};
  });

  app.post('/auth/refresh', async (request, reply) => {
    const token=request.cookies[refreshCookie]; if(!token) throw new AppError(401,'REFRESH_REQUIRED');
    const next=await rotateUserSession(token,request.headers['user-agent'],request.ip); if(!next) throw new AppError(401,'SESSION_EXPIRED');
    const accessToken=await reply.jwtSign({sub:next.user.id,kind:'user',sid:next.session.id},{expiresIn:config.ACCESS_TOKEN_TTL});
    reply.setCookie(refreshCookie,next.refreshToken,cookieOpts());
    return {accessToken,user:userPayload(next.user)};
  });

  app.post('/auth/logout', async (request, reply) => {const token=request.cookies[refreshCookie];if(token)await revokeRefresh(token);reply.clearCookie(refreshCookie,{path:'/api/v1/auth'});return {ok:true};});
  app.post('/auth/logout-all',{preHandler:(app as any).authenticateUser},async(request:any,reply)=>{await prisma.session.updateMany({where:{userId:request.user.sub,revokedAt:null},data:{revokedAt:new Date()}});reply.clearCookie(refreshCookie,{path:'/api/v1/auth'});return {ok:true};});
  app.get('/auth/me',{preHandler:(app as any).authenticateUser},async(request:any)=>{const user=await prisma.user.findUnique({where:{id:request.user.sub}});if(!user)throw new AppError(404,'USER_NOT_FOUND');return userPayload(user);});
}
