import type { FastifyInstance } from 'fastify';
import { prisma } from '../lib/prisma.js';
import { publicProduct } from '../lib/http.js';

const include={variants:{where:{active:true},orderBy:{sortOrder:'asc' as const}},media:{where:{deletedAt:null,visibility:'PUBLIC' as const},orderBy:{sortOrder:'asc' as const}},categories:{include:{category:true}}};
export async function catalogRoutes(app:FastifyInstance){
  app.get('/health',async()=>{await prisma.$queryRaw`SELECT 1`;return {service:'Store API',status:'ok',database:'ok',version:'0.60-RC1'};});
  app.get('/products',async(request:any)=>{const take=Math.min(Number(request.query?.limit||50),100);const rows=await prisma.product.findMany({where:{active:true},include,orderBy:{createdAt:'desc'},take});return rows.map(publicProduct);});
  app.get('/products/:id',async(request:any)=>{const key=String(request.params.id);const numeric=/^\d+$/.test(key)?Number(key):null;const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(key);const row=await prisma.product.findFirst({where:{active:true,OR:numeric?[{publicId:numeric}]:uuid?[{id:key}]:[{slug:key}]},include:{...include,reviews:{where:{status:'APPROVED'},orderBy:{createdAt:'desc'},take:20}}});if(!row){const e:any=new Error('PRODUCT_NOT_FOUND');e.statusCode=404;e.code='PRODUCT_NOT_FOUND';throw e;}return {...publicProduct(row),reviews:row.reviews};});
  app.get('/categories',async()=>prisma.category.findMany({where:{active:true},orderBy:[{sortOrder:'asc'},{name:'asc'}]}));
  app.get('/campaigns',async()=>{const now=new Date();return prisma.campaign.findMany({where:{active:true,AND:[{OR:[{startsAt:null},{startsAt:{lte:now}}]},{OR:[{endsAt:null},{endsAt:{gte:now}}]}]},orderBy:[{priority:'desc'},{createdAt:'desc'}]});});
  app.get('/articles',async()=>prisma.article.findMany({where:{status:'published',OR:[{publishedAt:null},{publishedAt:{lte:new Date()}}]},orderBy:{publishedAt:'desc'},take:100}));
  app.get('/search',async(request:any)=>{const q=String(request.query?.q||'').trim();if(!q)return {products:[],articles:[]};const [products,articles]=await Promise.all([prisma.product.findMany({where:{active:true,OR:[{name:{contains:q,mode:'insensitive'}},{brand:{contains:q,mode:'insensitive'}},{variants:{some:{sku:{contains:q,mode:'insensitive'}}}}]},include,take:30}),prisma.article.findMany({where:{status:'published',OR:[{title:{contains:q,mode:'insensitive'}},{excerpt:{contains:q,mode:'insensitive'}}]},take:20})]);return {products:products.map(publicProduct),articles};});
}
