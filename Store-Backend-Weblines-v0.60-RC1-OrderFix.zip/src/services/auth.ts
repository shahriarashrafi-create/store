import argon2 from 'argon2';
import { prisma } from '../lib/prisma.js';
import { config } from '../lib/config.js';
import { randomToken, sha256 } from '../lib/security.js';

const refreshExpiry = () => new Date(Date.now() + config.REFRESH_TOKEN_DAYS * 86400000);
export async function createUserSession(userId: string, deviceInfo?: string, ipInfo?: string) {
  const refreshToken = randomToken();
  const session = await prisma.session.create({ data: { userId, refreshTokenHash: sha256(refreshToken), deviceInfo, ipInfo, expiresAt: refreshExpiry() } });
  return { session, refreshToken };
}
export async function rotateUserSession(refreshToken: string, deviceInfo?: string, ipInfo?: string) {
  const hash = sha256(refreshToken);
  const current = await prisma.session.findFirst({ where: { refreshTokenHash: hash, revokedAt: null, expiresAt: { gt: new Date() } }, include: { user: true } });
  if (!current || current.user.status !== 'ACTIVE') return null;
  const next = randomToken();
  const session = await prisma.$transaction(async tx => {
    await tx.session.update({ where: { id: current.id }, data: { revokedAt: new Date() } });
    return tx.session.create({ data: { userId: current.userId, refreshTokenHash: sha256(next), deviceInfo, ipInfo, expiresAt: refreshExpiry() } });
  });
  return { user: current.user, session, refreshToken: next };
}
export async function revokeRefresh(refreshToken: string) {
  if (!refreshToken) return;
  await prisma.session.updateMany({ where: { refreshTokenHash: sha256(refreshToken), revokedAt: null }, data: { revokedAt: new Date() } });
}
export async function hashPassword(password: string) { return argon2.hash(password, { type: argon2.argon2id }); }
export async function verifyPassword(hash: string, password: string) { return argon2.verify(hash, password); }

export async function createAdminSession(adminUserId: string) {
  const refreshToken = randomToken();
  const session = await prisma.adminSession.create({ data: { adminUserId, refreshTokenHash: sha256(refreshToken), expiresAt: refreshExpiry() } });
  return { session, refreshToken };
}
export async function rotateAdminSession(refreshToken: string) {
  const current = await prisma.adminSession.findFirst({ where: { refreshTokenHash: sha256(refreshToken), revokedAt: null, expiresAt: { gt: new Date() } }, include: { adminUser: { include: { roles: { include: { role: true } } } } } });
  if (!current || current.adminUser.status !== 'ACTIVE') return null;
  const next = randomToken();
  const session = await prisma.$transaction(async tx => {
    await tx.adminSession.update({ where: { id: current.id }, data: { revokedAt: new Date() } });
    return tx.adminSession.create({ data: { adminUserId: current.adminUserId, refreshTokenHash: sha256(next), expiresAt: refreshExpiry() } });
  });
  return { admin: current.adminUser, session, refreshToken: next };
}
