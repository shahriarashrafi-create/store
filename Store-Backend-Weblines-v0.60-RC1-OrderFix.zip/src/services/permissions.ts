export function collectPermissions(admin: any) {
  return new Set<string>((admin.roles || []).flatMap((x:any) => Array.isArray(x.role?.permissions) ? x.role.permissions : []));
}
export function hasPermission(admin: any, permission: string) {
  const p = collectPermissions(admin); if (p.has('*') || p.has(permission)) return true;
  const [scope] = permission.split('.'); return p.has(`${scope}.*`);
}
