import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { config } from '../lib/config.js';
import crypto from 'node:crypto';

function client() {
  if (!config.S3_ENDPOINT || !config.S3_ACCESS_KEY || !config.S3_SECRET_KEY) throw Object.assign(new Error('STORAGE_NOT_CONFIGURED'), { statusCode: 503, code: 'STORAGE_NOT_CONFIGURED' });
  return new S3Client({ endpoint: config.S3_ENDPOINT, region: config.S3_REGION, forcePathStyle: config.S3_FORCE_PATH_STYLE, credentials: { accessKeyId: config.S3_ACCESS_KEY, secretAccessKey: config.S3_SECRET_KEY } });
}
export function safeExt(mime: string) {
  return ({'image/jpeg':'jpg','image/png':'png','image/webp':'webp','application/pdf':'pdf'} as Record<string,string>)[mime] || null;
}
export async function presignPrivateReceipt(orderId: string, mime: string) {
  const ext = safeExt(mime); if (!ext) throw Object.assign(new Error('UNSUPPORTED_FILE_TYPE'), { statusCode: 400, code: 'UNSUPPORTED_FILE_TYPE' });
  const key = `receipts/${orderId}/${Date.now()}-${crypto.randomUUID()}.${ext}`;
  const url = await getSignedUrl(client(), new PutObjectCommand({ Bucket: config.S3_BUCKET, Key: key, ContentType: mime }), { expiresIn: 300 });
  return { key, url, expiresIn: 300 };
}
export async function signedPrivateGet(key: string) {
  return getSignedUrl(client(), new GetObjectCommand({ Bucket: config.S3_BUCKET, Key: key }), { expiresIn: 300 });
}
