# Order Fix

Fixes shipping method lookup during checkout/order creation.

Previously, a shipping key such as `tipax` was also compared against the UUID `ShippingMethod.id`, which could fail in PostgreSQL before order creation. The route now detects UUID vs key and queries the correct column.
