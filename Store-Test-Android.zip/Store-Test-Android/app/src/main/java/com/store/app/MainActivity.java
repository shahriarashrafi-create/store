package com.store.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int padding = dp(28);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(padding, padding, padding, padding);
        root.setBackgroundColor(Color.rgb(247, 248, 250));
        root.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        TextView title = new TextView(this);
        title.setText("Store");
        title.setTextSize(38);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(Color.rgb(25, 28, 32));
        title.setGravity(Gravity.CENTER);

        TextView subtitle = new TextView(this);
        subtitle.setText("نسخه آزمایشی");
        subtitle.setTextSize(22);
        subtitle.setTextColor(Color.rgb(70, 75, 82));
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(16), 0, 0);

        TextView message = new TextView(this);
        message.setText("اگر این صفحه را داخل اپ می‌بینی، ساخت APK پروژه Store با موفقیت انجام شده است.");
        message.setTextSize(17);
        message.setTextColor(Color.rgb(95, 100, 108));
        message.setGravity(Gravity.CENTER);
        message.setPadding(0, dp(24), 0, 0);
        message.setLineSpacing(0f, 1.25f);

        root.addView(title);
        root.addView(subtitle);
        root.addView(message);

        setContentView(root);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
