# Store Test Android App

Minimal Android test project for verifying the GitHub Actions APK build pipeline.

Expected output after `assembleDebug`:

`app/build/outputs/apk/debug/app-debug.apk`
