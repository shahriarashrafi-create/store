# Store Backend Architecture (Step 10)

Target stack: **Node.js REST API + PostgreSQL + S3-compatible object storage**.

This folder is an architecture scaffold only; the APK currently uses local fallback data. When backend work begins, UI code should call `js/api.js` rather than talking directly to storage.

Environments: development / staging / production. Payment in MVP remains bank transfer + receipt + manual admin confirmation. SMS and online payment are not enabled.
