# Implementation status — Store v0.11

## Steps 1–10 retained
All previously approved business, audience, category, MVP, customer journey, brand, design-system, navigation and architecture decisions remain intact.

## Home refinement
- Header/search height reduced without shrinking touch targets.
- Hero height reduced and local illustration upgraded (`hero-products-v2.svg`).
- Home category cards and need cards use more compact spacing.
- Bottom navigation height reduced from 82px to 74px while keeping safe-area handling.

## Products refinement
- Added `categories/all.svg` and a dedicated visual wrapper for all category tab assets.
- Active category artwork is no longer globally inverted.
- Added catalog summary + grouped Filter / Sort actions.
- Added product metadata for demo filtering (`brand`, `skinType`).

## Filter architecture
- Product state now supports `skinType`, `brand`, and `maxPrice` in addition to category/need/query/sort.
- Filter sheet uses a temporary `filterDraft`; current catalog state does not change until the user applies the draft.
- Added live result count and price-range filtering.
- Filter choices are responsive grid chips to prevent RTL clipping/overflow.

## Version
- Android `versionCode 11`
- Android `versionName 0.11-steps1-10-ux-refine`
- PWA cache: `store-v011-shell`
- Local storage key: `store-v011`, with migration fallback to v0.10/v0.6 keys.
