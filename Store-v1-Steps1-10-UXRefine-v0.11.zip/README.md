# Store v0.11 — Steps 1–10 + Home/Products UX refinement

This ZIP keeps all approved decisions from Store steps 1–10 and refines the two screens reviewed after v0.10: **Home** and **Products / Filters**.

## What changed in v0.11
- More compact Home header and search area.
- Shorter, denser hero with a richer local SVG product/leaf illustration.
- Cleaner category cards and tighter section spacing so more storefront content is visible above the fold.
- Slightly slimmer bottom navigation while preserving Android safe-area padding.
- Products category tabs use a consistent asset frame; the active tab no longer destroys the SVG artwork with a global color filter.
- Product count and filter/sort controls are grouped into a stable catalog toolbar.
- Product cards use a tighter two-column mobile grid.
- Filter Bottom Sheet rebuilt with:
  - main category
  - skin type
  - customer need
  - brand
  - maximum price
  - live result count
  - sticky action buttons
  - draft filters that are applied only after tapping **اعمال فیلتر**
- Filter chips wrap in a responsive grid instead of overflowing or clipping long Persian labels.

## Approved MVP constraints retained
- No SMS login yet; mobile number + password.
- No online payment gateway yet; bank transfer + receipt + manual verification.
- Shared modular frontend for Android WebView/PWA, with the Step 10 backend architecture scaffold preserved.
