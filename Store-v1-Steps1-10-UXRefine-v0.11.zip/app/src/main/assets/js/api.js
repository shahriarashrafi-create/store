const StoreApi={
  get baseUrl(){return window.StoreConfig.api[window.StoreConfig.environment]||''},
  async request(path,options={}){
    if(!this.baseUrl) throw new Error('API_NOT_CONNECTED');
    const response=await fetch(this.baseUrl+path,{headers:{'Content-Type':'application/json',...(options.headers||{})},...options});
    if(!response.ok) throw new Error('API_'+response.status);
    return response.status===204?null:response.json();
  },
  products(){return this.request('/products')},
  orders(){return this.request('/orders')}
};
window.StoreApi=StoreApi;
