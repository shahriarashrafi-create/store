# VALIDATION — Store v0.13

Validation completed before packaging:

- JavaScript syntax checked with `node --check` for all frontend JS files and service worker.
- XML and SVG files parsed successfully.
- Node smoke test covered onboarding slides, login UI, register UI, forgot-password UI, Home, Products, Product Detail, guest Profile, local test registration/login, and authenticated Checkout.
- PWA manifest starts at `index.html` so first-run routing can decide between Onboarding and Home.
- New onboarding illustration files are present and included in the PWA shell cache.
- Android versionCode/versionName updated to 13 / `0.13-steps1-13-onboarding-auth`.
- Native Android splash is independent of frontend JavaScript and has a forced maximum dismissal timeout.
- ZIP integrity is checked after packaging.

## Build note
A full Android Gradle compile is intentionally left to the existing GitHub Actions workflow because this environment does not have a local Gradle distribution and external Gradle download access may be unavailable. The same repository workflow that built the earlier Store APK remains the final compile check.
