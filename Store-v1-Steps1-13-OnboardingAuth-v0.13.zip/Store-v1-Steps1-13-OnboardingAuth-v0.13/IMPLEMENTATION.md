# IMPLEMENTATION — Store v0.13

## Step 11 — Splash
Native Android overlay in `MainActivity.kt`; HTML splash is not used. WebView loads behind it.

## Step 12 — Onboarding
Three local SVG illustrations, first-run flag `onboardingCompleted`, skip/next/finish flow, and replay action from Settings.

## Step 13 — Auth
Local prototype AuthService in `js/storage.js`, separate account/session storage, login/register tabs, inline validation, remember-me, support-based reset, protected checkout/orders flow, and return-to destination.

## Architecture
Existing Steps 1–10 remain intact: common PWA/WebView frontend, modular CSS/JS, central router/state, local storage abstraction, API scaffold, PostgreSQL target schema and Android Kotlin wrapper.
