const defaults={
  page:'home',query:'',category:'همه',need:'همه',skinType:'همه',brand:'همه',maxPrice:500000,sort:'featured',
  favs:[],cart:[],orders:[],filterDraft:null,user:null,sheet:null,consultType:'پوست',returnTo:null,checkoutStep:1,
  checkoutDraft:{receiver:'',phone:'',address:'',shipping:65000,track:''},recentSearches:[],
  onboardingCompleted:false,onboardingSlide:0,authMode:'login'
};

const AuthService={
  accountsKey:'store-local-accounts-v1',persistentKey:'store-auth-session-v1',sessionKey:'store-auth-tab-v1',
  accounts(){try{return JSON.parse(localStorage.getItem(this.accountsKey)||'{}')}catch(e){return {}}},
  saveAccounts(v){localStorage.setItem(this.accountsKey,JSON.stringify(v))},
  normalizeMobile(v){return String(v||'').replace(/\D/g,'').slice(0,11)},
  validMobile(v){return /^09\d{9}$/.test(this.normalizeMobile(v))},
  validPassword(v){const s=String(v||'');return s.length>=8 && /\d/.test(s) && /[A-Za-z\u0600-\u06FF]/.test(s)},
  async digest(text){
    try{if(window.crypto&&crypto.subtle){const b=new TextEncoder().encode('store-local-v1:'+text);const d=await crypto.subtle.digest('SHA-256',b);return Array.from(new Uint8Array(d)).map(x=>x.toString(16).padStart(2,'0')).join('')}}catch(e){}
    let h=2166136261;for(const c of ('store-local-v1:'+text)){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return 'local-'+(h>>>0).toString(16)
  },
  session(){
    try{return JSON.parse(sessionStorage.getItem(this.sessionKey)||localStorage.getItem(this.persistentKey)||'null')}catch(e){return null}
  },
  setSession(mobile,remember=true){const payload={mobile,createdAt:Date.now()};sessionStorage.removeItem(this.sessionKey);localStorage.removeItem(this.persistentKey);(remember?localStorage:sessionStorage).setItem(remember?this.persistentKey:this.sessionKey,JSON.stringify(payload))},
  currentUser(){const sess=this.session();if(!sess?.mobile)return null;const a=this.accounts()[sess.mobile];return a?{name:a.name||'کاربر Store',mobile:a.mobile,points:Number(a.points||0),tier:a.tier||'Bronze'}:null},
  async register(mobile,password){mobile=this.normalizeMobile(mobile);if(!this.validMobile(mobile))throw new Error('mobile');if(!this.validPassword(password))throw new Error('password');const accounts=this.accounts();if(accounts[mobile])throw new Error('exists');accounts[mobile]={mobile,name:'کاربر Store',passwordHash:await this.digest(password),points:0,tier:'Bronze',createdAt:Date.now()};this.saveAccounts(accounts);this.setSession(mobile,true);return this.currentUser()},
  async login(mobile,password,remember=true){mobile=this.normalizeMobile(mobile);if(!this.validMobile(mobile))throw new Error('mobile');const a=this.accounts()[mobile];if(!a)throw new Error('notfound');if(a.passwordHash!==await this.digest(password))throw new Error('wrong');this.setSession(mobile,remember);return this.currentUser()},
  logout(){sessionStorage.removeItem(this.sessionKey);localStorage.removeItem(this.persistentKey)},
  updateProfile(profile){const u=this.currentUser();if(!u)return null;const accounts=this.accounts(),a=accounts[u.mobile];if(!a)return null;accounts[u.mobile]={...a,...profile,mobile:u.mobile};this.saveAccounts(accounts);return this.currentUser()}
};

const StorageService={
  key:window.StoreConfig.storageKey,
  load(){
    try{
      let raw=localStorage.getItem(this.key);
      if(!raw){for(const legacy of window.StoreConfig.legacyStorageKeys||[]){raw=localStorage.getItem(legacy);if(raw)break}}
      const parsed=raw?JSON.parse(raw):{};
      const value={...defaults,...parsed,checkoutDraft:{...defaults.checkoutDraft,...(parsed.checkoutDraft||{})}};
      value.user=AuthService.currentUser();
      if(value.onboardingCompleted!==true && parsed.onboardingCompleted!==true)value.onboardingCompleted=false;
      return value;
    }catch(e){return {...defaults,user:AuthService.currentUser(),checkoutDraft:{...defaults.checkoutDraft}}}
  },
  save(value){const persist={...value};delete persist.user;localStorage.setItem(this.key,JSON.stringify(persist))},
  async openCache(){if(!('indexedDB' in window))return null;return new Promise(resolve=>{const req=indexedDB.open('store-cache',1);req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains('kv'))req.result.createObjectStore('kv')};req.onsuccess=()=>resolve(req.result);req.onerror=()=>resolve(null)})},
  async cacheSet(key,value){const db=await this.openCache();if(!db)return;const tx=db.transaction('kv','readwrite');tx.objectStore('kv').put(value,key)},
  async cacheGet(key){const db=await this.openCache();if(!db)return null;return new Promise(resolve=>{const r=db.transaction('kv').objectStore('kv').get(key);r.onsuccess=()=>resolve(r.result??null);r.onerror=()=>resolve(null)})}
};
let state=StorageService.load();
function load(){return StorageService.load()}
function save(){StorageService.save(state)}
