# Mission Rank — Android

A compact daily gamification Android app built around one mission at a time.

## Included game rules
- 10 XP = Safe, 20 XP = Classic, 30 XP = Rank.
- Level-up requirement: `(current level + 1) × 100` XP. Overflow XP carries forward.
- Rank progression: at Rank N, complete N Rank missions to advance; from Rank 10 onward every rank requires 10 Rank missions.
- Focus Magic: toggle ON to apply its multiplier to the current and every following mission until OFF. A 25-minute focus cycle counts as one Focus Magic use. Every 5 uses raises Focus Magic by 1 level, max level 5. Multiplier is level + 1 (Lv1=x2 ... Lv5=x6).
- Boost Magic: B missions automatically receive Boost Magic multiplier. Every completed B mission counts as one use; every 5 uses raises Boost Magic by 1 level, max level 5.
- If Focus and Boost both apply, multipliers stack.
- Later missions return after roughly five other interactions.
- Delete removes a mission only for the current day.
- Daily mission status resets on a new calendar day; Level, Rank, Magic, achievements and streaks remain.
- Mission Board contains 30 slots: 25 configured missions + 5 disabled empty slots reserved for future missions.

## Current carry-over state
First install starts with the current game state from this chat:
- Level 5 — 420 / 600 XP
- Rank 6 — 0 / 6
- Focus Magic Lv1 — 0 / 5
- Boost Magic Lv1 — 4 / 5

## UI language
All interface labels are English. The mission title itself is Persian and right-aligned, as the main focus area.

## Build an APK
Open this folder in Android Studio (JDK 17+ recommended), let Gradle sync, then use:

`Build > Build App Bundle(s) / APK(s) > Build APK(s)`

Or from a terminal after the Gradle wrapper is present:

`./gradlew assembleDebug`

The APK will be created under `app/build/outputs/apk/debug/`.
