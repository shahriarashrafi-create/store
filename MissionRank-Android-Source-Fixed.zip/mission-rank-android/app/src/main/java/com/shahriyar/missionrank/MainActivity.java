package com.shahriyar.missionrank;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import java.time.LocalDate;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,11,18));
        getWindow().setNavigationBarColor(Color.rgb(8,11,18));
        setContentView(new GameView(this));
    }
}

class GameView extends View {
    static class Mission {
        String fa; int pts; boolean rank, boost, enabled;
        Mission(String fa, int pts, boolean rank, boolean boost) { this.fa=fa; this.pts=pts; this.rank=rank; this.boost=boost; this.enabled=true; }
    }

    private final Paint p = new Paint(3);
    private final Paint stroke = new Paint(3);
    private final SharedPreferences sp;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<Mission> missions = new ArrayList<>();
    private final ArrayDeque<Integer> revisitQueue = new ArrayDeque<>();
    private final HashMap<Integer,Integer> revisitAt = new HashMap<>();
    private final HashSet<Integer> doneToday = new HashSet<>(), deletedToday = new HashSet<>();
    private int cursor = 0, current = -1, actions = 0;

    private int level, levelXp, rank, rankProgress, focusLevel, focusUses, boostLevel, boostUses;
    private int totalRankDone, totalBoostDone, daySafe, dayClassic, dayRank;
    private boolean focusOn = false, showBoard=false, showAchievements=false;
    private long focusEndsAt = 0L;
    private String toast = "MISSION READY";
    private long toastUntil = 0L;
    private float pulse = 0f;
    private int dailyDone = 0;
    private long animStart = System.currentTimeMillis();

    private RectF focusRect=new RectF(), boardRect=new RectF(), achRect=new RectF(), doneRect=new RectF(), laterRect=new RectF(), deleteRect=new RectF();

    GameView(Context c) {
        super(c);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        sp = c.getSharedPreferences("mission_rank_state", Context.MODE_PRIVATE);
        p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1));
        buildMissions();
        loadState();
        resetDailyIfNeeded();
        chooseNext();
        startTicker();
    }

    private void buildMissions() {
        missions.add(new Mission("مرتب کردن اتاق",10,false,false));
        missions.add(new Mission("اصلاح صورت",10,false,false));
        missions.add(new Mission("نرمش صبحگاهی",20,false,false));
        missions.add(new Mission("روتین صبح",10,false,false));
        missions.add(new Mission("هدف بلندمدت",30,true,false));
        missions.add(new Mission("درختواره",30,true,false));
        missions.add(new Mission("برنامه زمانی",10,false,false));
        missions.add(new Mission("گروه رکورد شکن",20,false,true));
        missions.add(new Mission("گروه های کاری",20,false,false));
        missions.add(new Mission("ایده ها و خلاقیت ها",10,false,false));
        missions.add(new Mission("سناریو و ai",20,false,false));
        missions.add(new Mission("انجام ایده ها",20,false,false));
        missions.add(new Mission("تشویق سازمان",20,false,true));
        missions.add(new Mission("پیگیری سازمان",20,false,true));
        missions.add(new Mission("ارتباط سازی",30,true,false));
        missions.add(new Mission("پیش مشاوره",30,true,false));
        missions.add(new Mission("دعوت به کار",30,true,false));
        missions.add(new Mission("معرفی محصول",20,false,false));
        missions.add(new Mission("شوآف",20,false,false));
        missions.add(new Mission("آموزش دیدن",20,false,false));
        missions.add(new Mission("نوشتن آمار سازمان",20,false,false));
        missions.add(new Mission("روتین شب",10,false,false));
        missions.add(new Mission("فرمان دادن",20,false,false));
        missions.add(new Mission("کتاب خواندن",30,true,false));
        missions.add(new Mission("جلسه برگزار کردن",20,false,true));
        for(int i=26;i<=30;i++){ Mission m=new Mission("ماموریت خالی "+i,10,false,false); m.enabled=false; missions.add(m); }
    }

    private void loadState() {
        level = sp.getInt("level",5);
        levelXp = sp.getInt("levelXp",420);
        rank = sp.getInt("rank",6);
        rankProgress = sp.getInt("rankProgress",0);
        focusLevel = sp.getInt("focusLevel",1);
        focusUses = sp.getInt("focusUses",0);
        boostLevel = sp.getInt("boostLevel",1);
        boostUses = sp.getInt("boostUses",4);
        totalRankDone = sp.getInt("totalRankDone",10);
        totalBoostDone = sp.getInt("totalBoostDone",4);
    }

    private void saveMeta() {
        sp.edit().putInt("level",level).putInt("levelXp",levelXp)
          .putInt("rank",rank).putInt("rankProgress",rankProgress)
          .putInt("focusLevel",focusLevel).putInt("focusUses",focusUses)
          .putInt("boostLevel",boostLevel).putInt("boostUses",boostUses)
          .putInt("totalRankDone",totalRankDone).putInt("totalBoostDone",totalBoostDone).apply();
    }

    private void resetDailyIfNeeded(){
        String today=LocalDate.now().toString();
        String saved=sp.getString("dailyDate","");
        if(!today.equals(saved)){
            sp.edit().putString("dailyDate",today).apply();
            cursor=0; current=-1; actions=0; dailyDone=0; daySafe=dayClassic=dayRank=0;
            doneToday.clear(); deletedToday.clear(); revisitQueue.clear(); revisitAt.clear();
        }
    }

    private void chooseNext(){
        for(Integer idx:new ArrayList<>(revisitQueue)){
            Integer at=revisitAt.get(idx);
            if(at!=null && actions>=at && !doneToday.contains(idx) && !deletedToday.contains(idx)){
                revisitQueue.remove(idx); revisitAt.remove(idx); current=idx; return;
            }
        }
        while(cursor<missions.size()){
            int idx=cursor++;
            Mission m=missions.get(idx);
            if(m.enabled && !doneToday.contains(idx) && !deletedToday.contains(idx)){ current=idx; return; }
        }
        if(!revisitQueue.isEmpty()){
            Integer idx=revisitQueue.poll(); revisitAt.remove(idx); current=idx; return;
        }
        current=-1;
    }

    private int levelNeed(){ return (level+1)*100; }
    private int rankNeed(){ return rank>=10?10:rank; }
    private int focusMultiplier(){ return focusLevel+1; }
    private int boostMultiplier(){ return boostLevel+1; }

    private void completeCurrent(){
        if(current<0) return;
        Mission m=missions.get(current);
        int mult=1;
        if(focusOn) mult*=focusMultiplier();
        if(m.boost) mult*=boostMultiplier();
        int gain=m.pts*mult;
        levelXp += gain;
        boolean lvl=false, rnk=false, magic=false;
        while(levelXp>=levelNeed()){
            levelXp-=levelNeed(); level++; lvl=true;
        }
        if(m.rank){
            totalRankDone++; rankProgress++; dayRank++;
            while(rankProgress>=rankNeed()){
                rankProgress-=rankNeed(); rank++; rnk=true;
            }
        } else if(m.pts==10) daySafe++; else dayClassic++;
        if(m.boost){
            totalBoostDone++; boostUses++;
            if(boostUses>=5 && boostLevel<5){ boostUses=0; boostLevel++; magic=true; }
            if(boostLevel>=5) boostUses=5;
        }
        doneToday.add(current); dailyDone++; actions++;
        updateTaskStreak(current);
        if(lvl) flash("LEVEL UP  •  LV "+level);
        else if(rnk) flash("RANK UP  •  RANK "+rank);
        else if(magic) flash("BOOST MAGIC UP  •  x"+boostMultiplier());
        else flash("+"+gain+" XP  •  NICE MOVE!");
        saveMeta(); chooseNext(); invalidate();
    }

    private void laterCurrent(){
        if(current<0) return;
        int idx=current;
        revisitQueue.remove(idx);
        revisitQueue.add(idx);
        revisitAt.put(idx, actions+5);
        actions++;
        flash("SAVED FOR LATER  •  COMES BACK SOON");
        chooseNext(); invalidate();
    }

    private void deleteCurrent(){
        if(current<0) return;
        deletedToday.add(current); actions++;
        flash("REMOVED FOR TODAY");
        chooseNext(); invalidate();
    }

    private void updateTaskStreak(int idx){
        long today=LocalDate.now().toEpochDay();
        long last=sp.getLong("taskLast_"+idx,Long.MIN_VALUE);
        int streak=sp.getInt("taskStreak_"+idx,0);
        if(last==today-1) streak++; else if(last!=today) streak=1;
        sp.edit().putLong("taskLast_"+idx,today).putInt("taskStreak_"+idx,streak).apply();
    }

    private void toggleFocus(){
        focusOn=!focusOn;
        if(focusOn){ focusEndsAt=System.currentTimeMillis()+25*60*1000L; flash("FOCUS ON  •  x"+focusMultiplier()+" XP"); }
        else { focusEndsAt=0; flash("FOCUS OFF"); }
        invalidate();
    }

    private void focusCycleComplete(){
        focusUses++;
        if(focusUses>=5 && focusLevel<5){ focusUses=0; focusLevel++; flash("FOCUS MAGIC UP  •  x"+focusMultiplier()); }
        else flash("FOCUS SESSION COMPLETE  •  "+focusUses+"/5");
        if(focusLevel>=5) focusUses=5;
        saveMeta();
        if(focusOn) focusEndsAt=System.currentTimeMillis()+25*60*1000L;
    }

    private void startTicker(){
        handler.postDelayed(new Runnable(){ public void run(){
            pulse=(pulse+.045f)%1f;
            if(focusOn && focusEndsAt>0 && System.currentTimeMillis()>=focusEndsAt) focusCycleComplete();
            invalidate(); handler.postDelayed(this,120);
        }},120);
    }

    private void flash(String s){ toast=s; toastUntil=System.currentTimeMillis()+2400; animStart=System.currentTimeMillis(); }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c); resetDailyIfNeeded();
        float w=getWidth(), h=getHeight();
        c.drawColor(Color.rgb(8,11,18));
        drawGlow(c,w*.5f,h*.38f, w*.5f);

        // top title
        text(c,"MISSION RANK",dp(20),dp(30),Color.WHITE,Paint.Align.LEFT,true);
        text(c,"DAILY RPG",w-dp(20),dp(30),Color.rgb(125,135,155),Paint.Align.RIGHT,false);

        // compact stats row
        float y=dp(58);
        statChip(c,dp(18),y,dp(98),"LV "+level, levelXp+"/"+levelNeed());
        statChip(c,dp(122),y,dp(102),"RANK "+rank,rankProgress+"/"+rankNeed());
        statChip(c,dp(230),y,dp(116),"BOOST x"+boostMultiplier(),boostUses+"/5");

        // mini controls
        focusRect.set(dp(18),dp(108),w*.48f,dp(151));
        boardRect.set(w*.50f,dp(108),w*.73f,dp(151));
        achRect.set(w*.75f,dp(108),w-dp(18),dp(151));
        button(c,focusRect,focusOn?"FOCUS ON":"FOCUS", focusOn?Color.rgb(82,255,174):Color.rgb(32,38,52), focusOn?Color.rgb(5,20,14):Color.WHITE);
        button(c,boardRect,"BOARD",Color.rgb(32,38,52),Color.WHITE);
        button(c,achRect,"ACH",Color.rgb(32,38,52),Color.WHITE);

        if(showBoard){ drawBoard(c); return; }
        if(showAchievements){ drawAchievements(c); return; }

        if(current>=0) drawMission(c,missions.get(current)); else drawComplete(c);

        if(System.currentTimeMillis()<toastUntil){
            float alpha=Math.min(1f,(toastUntil-System.currentTimeMillis())/350f);
            p.setAlpha((int)(255*alpha));
            text(c,toast,w/2,h-dp(35),Color.rgb(125,255,180),Paint.Align.CENTER,true);
            p.setAlpha(255);
        }
    }

    private void drawMission(Canvas c,Mission m){
        float w=getWidth(), h=getHeight();
        float bob=(float)Math.sin(pulse*Math.PI*2)*dp(3);
        text(c,"NEXT MISSION",w/2,dp(188)+bob,Color.rgb(125,255,180),Paint.Align.CENTER,true);

        RectF card=new RectF(dp(18),dp(214),w-dp(18),h-dp(190));
        rounded(c,card,dp(24),Color.rgb(18,23,34));
        stroke.setColor(Color.rgb(54,65,86)); stroke.setStrokeWidth(dp(1)); c.drawRoundRect(card,dp(24),dp(24),stroke);

        String mode=m.pts==10?"SAFE":(m.pts==20?"CLASSIC":"RANK");
        String tags=mode+"  •  "+m.pts+" XP"+(m.rank?"  •  R":"")+(m.boost?"  •  B":"");
        text(c,tags,w/2,card.top+dp(42),m.rank?Color.rgb(255,215,90):(m.boost?Color.rgb(190,135,255):Color.rgb(150,160,180)),Paint.Align.CENTER,true);

        p.setTextAlign(Paint.Align.RIGHT); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); p.setTextSize(dp(31)); p.setColor(Color.WHITE);
        float tx=card.right-dp(30); float ty=(card.top+card.bottom)/2+dp(10);
        c.drawText(m.fa,tx,ty,p);

        String hype=focusOn?"FOCUS ACTIVE  •  MOVE NOW  •  x"+focusMultiplier():"GO NOW  •  CLEAR IT FAST";
        text(c,hype,w/2,card.bottom-dp(38),focusOn?Color.rgb(82,255,174):Color.rgb(255,190,75),Paint.Align.CENTER,true);

        if(focusOn){
            long left=Math.max(0,focusEndsAt-System.currentTimeMillis());
            long mm=left/60000, ss=(left/1000)%60;
            text(c,String.format(Locale.US,"%02d:%02d",mm,ss),w/2,card.bottom-dp(14),Color.rgb(150,160,180),Paint.Align.CENTER,false);
        }

        float by=h-dp(150), gap=dp(9), bw=(w-dp(36)-gap*2)/3f;
        doneRect.set(dp(18),by,dp(18)+bw,by+dp(64));
        laterRect.set(doneRect.right+gap,by,doneRect.right+gap+bw,by+dp(64));
        deleteRect.set(laterRect.right+gap,by,w-dp(18),by+dp(64));
        button(c,doneRect,"✓  DONE",Color.rgb(76,255,159),Color.rgb(5,22,14));
        button(c,laterRect,"⌛  LATER",Color.rgb(39,47,63),Color.WHITE);
        button(c,deleteRect,"×  DELETE",Color.rgb(51,31,36),Color.rgb(255,136,147));

        text(c,"TODAY "+dailyDone+" DONE  •  SAFE "+daySafe+"  CLASSIC "+dayClassic+"  RANK "+dayRank,w/2,h-dp(64),Color.rgb(125,135,155),Paint.Align.CENTER,false);
    }

    private void drawComplete(Canvas c){
        float w=getWidth(),h=getHeight();
        text(c,"DAY CLEARED",w/2,h*.42f,Color.rgb(76,255,159),Paint.Align.CENTER,true);
        text(c,"ALL ACTIVE MISSIONS ARE DONE",w/2,h*.42f+dp(38),Color.WHITE,Paint.Align.CENTER,false);
        text(c,dailyDone+" MISSIONS COMPLETE",w/2,h*.42f+dp(70),Color.rgb(145,155,175),Paint.Align.CENTER,false);
    }

    private void drawBoard(Canvas c){
        float w=getWidth();
        text(c,"MISSION BOARD  •  30 SLOTS",w/2,dp(190),Color.WHITE,Paint.Align.CENTER,true);
        float left=dp(18), top=dp(215), colW=(w-dp(54))/2f;
        for(int i=0;i<30;i++){
            int col=i<15?0:1, row=i%15;
            float x=left+col*(colW+dp(18)), y=top+row*dp(28);
            Mission m=missions.get(i);
            String mark=doneToday.contains(i)?"✓":(deletedToday.contains(i)?"×":(!m.enabled?"–":"•"));
            int color=doneToday.contains(i)?Color.rgb(76,255,159):Color.rgb(165,175,195);
            text(c,mark+" "+(i+1)+"  "+shortFa(m.fa,13),x,y,color,Paint.Align.LEFT,false);
        }
        text(c,"TAP BOARD TO CLOSE",w/2,getHeight()-dp(45),Color.rgb(125,135,155),Paint.Align.CENTER,false);
    }

    private void drawAchievements(Canvas c){
        float w=getWidth();
        text(c,"ACHIEVEMENTS",w/2,dp(190),Color.WHITE,Paint.Align.CENTER,true);
        String[] a={
            "✓ FIRST MISSION",
            hasThreeDayStreak()?"✓ 3-DAY STREAK":"○ 3-DAY STREAK",
            (daySafe>0&&dayClassic>0&&dayRank>0)?"✓ ALL 3 MODES":"○ ALL 3 MODES",
            totalRankDone>=5?"✓ 5 RANK MISSIONS":"○ 5 RANK MISSIONS",
            totalBoostDone>=5?"✓ 5 BOOST MISSIONS":"○ 5 BOOST MISSIONS",
            (focusLevel>=5||boostLevel>=5)?"✓ MASTER WIZARD":"○ MASTER WIZARD",
            rank>=5?"✓ BRONZE  •  RANK 5":"○ BRONZE  •  RANK 5",
            rank>=10?"✓ SILVER  •  RANK 10":"○ SILVER  •  RANK 10",
            rank>=20?"✓ GOLDEN  •  RANK 20":"○ GOLDEN  •  RANK 20",
            rank>=50?"✓ DIAMOND  •  RANK 50":"○ DIAMOND  •  RANK 50",
            rank>=100?"✓ MASTER  •  RANK 100":"○ MASTER  •  RANK 100"};
        float y=dp(235);
        for(String s:a){ int color=s.startsWith("✓")?Color.rgb(76,255,159):Color.rgb(120,130,150); text(c,s,dp(28),y,color,Paint.Align.LEFT,s.startsWith("✓")); y+=dp(34); }
        text(c,"TAP ACH TO CLOSE",w/2,getHeight()-dp(45),Color.rgb(125,135,155),Paint.Align.CENTER,false);
    }

    private boolean hasThreeDayStreak(){
        for(int i=0;i<missions.size();i++) if(sp.getInt("taskStreak_"+i,0)>=3) return true;
        return false;
    }

    private String shortFa(String s,int n){ return s.length()<=n?s:s.substring(0,n-1)+"…"; }

    private void statChip(Canvas c,float x,float y,float width,String top,String bottom){
        RectF r=new RectF(x,y,x+width,y+dp(40)); rounded(c,r,dp(13),Color.rgb(18,23,34));
        text(c,top,x+dp(10),y+dp(16),Color.WHITE,Paint.Align.LEFT,true);
        text(c,bottom,x+dp(10),y+dp(32),Color.rgb(125,135,155),Paint.Align.LEFT,false);
    }

    private void button(Canvas c,RectF r,String label,int bg,int fg){ rounded(c,r,dp(15),bg); text(c,label,r.centerX(),r.centerY()+dp(5),fg,Paint.Align.CENTER,true); }
    private void rounded(Canvas c,RectF r,float rad,int color){ p.setStyle(Paint.Style.FILL); p.setColor(color); c.drawRoundRect(r,rad,rad,p); }
    private void text(Canvas c,String s,float x,float y,int color,Paint.Align align,boolean bold){
        p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextAlign(align); p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL)); p.setTextSize(dp(bold?13:11)); c.drawText(s,x,y,p);
    }
    private void drawGlow(Canvas c,float x,float y,float radius){
        Paint g=new Paint(3); g.setShader(new RadialGradient(x,y,radius,Color.argb(28,74,255,166),Color.TRANSPARENT,Shader.TileMode.CLAMP)); c.drawCircle(x,y,radius,g);
    }
    private float dp(float v){ return v*getResources().getDisplayMetrics().density; }

    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_UP) return true;
        float x=e.getX(),y=e.getY();
        if(focusRect.contains(x,y)){ toggleFocus(); return true; }
        if(boardRect.contains(x,y)){ showBoard=!showBoard; showAchievements=false; invalidate(); return true; }
        if(achRect.contains(x,y)){ showAchievements=!showAchievements; showBoard=false; invalidate(); return true; }
        if(showBoard||showAchievements) return true;
        if(doneRect.contains(x,y)){ completeCurrent(); return true; }
        if(laterRect.contains(x,y)){ laterCurrent(); return true; }
        if(deleteRect.contains(x,y)){ deleteCurrent(); return true; }
        return true;
    }
}
