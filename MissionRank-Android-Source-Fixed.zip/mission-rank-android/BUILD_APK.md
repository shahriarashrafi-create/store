# Build APK

## Android Studio
1. Open this folder in Android Studio.
2. Let Gradle Sync finish.
3. Choose **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. The APK will be at:
   `app/build/outputs/apk/debug/app-debug.apk`
5. Copy that APK to your Android phone and install it.

If Android blocks installation, allow **Install unknown apps** for the app you used to open the APK (Files, Chrome, Telegram, etc.).

## GitHub Actions (no local Android SDK required)
1. Upload this project to a GitHub repository.
2. Open **Actions > Build Android APK > Run workflow**.
3. When it finishes, open the run and download artifact **MissionRank-APK**.
4. Extract it and install `app-debug.apk` on the phone.
