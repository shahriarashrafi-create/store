const defaults={
  page:'home',query:'',category:'همه',need:'همه',sort:'featured',
  favs:[],cart:[],orders:[],
  user:{name:'کاربر استور',mobile:'09123214458',points:120,tier:'Bronze'},
  sheet:null,consultType:'پوست',returnTo:null,checkoutStep:1,
  checkoutDraft:{receiver:'',phone:'',address:'',shipping:65000,track:''},
  recentSearches:[]
};

const StorageService={
  key:window.StoreConfig.storageKey,
  load(){
    try{
      let raw=localStorage.getItem(this.key);
      if(!raw){
        for(const legacy of window.StoreConfig.legacyStorageKeys||[]){
          raw=localStorage.getItem(legacy); if(raw) break;
        }
      }
      const parsed=raw?JSON.parse(raw):{};
      return {...defaults,...parsed,checkoutDraft:{...defaults.checkoutDraft,...(parsed.checkoutDraft||{})}};
    }catch(e){ return {...defaults,checkoutDraft:{...defaults.checkoutDraft}}; }
  },
  save(value){ localStorage.setItem(this.key,JSON.stringify(value)); },
  async openCache(){
    if(!('indexedDB' in window)) return null;
    return new Promise(resolve=>{
      const req=indexedDB.open('store-cache',1);
      req.onupgradeneeded=()=>{ if(!req.result.objectStoreNames.contains('kv')) req.result.createObjectStore('kv'); };
      req.onsuccess=()=>resolve(req.result); req.onerror=()=>resolve(null);
    });
  },
  async cacheSet(key,value){const db=await this.openCache();if(!db)return;const tx=db.transaction('kv','readwrite');tx.objectStore('kv').put(value,key)},
  async cacheGet(key){const db=await this.openCache();if(!db)return null;return new Promise(resolve=>{const r=db.transaction('kv').objectStore('kv').get(key);r.onsuccess=()=>resolve(r.result??null);r.onerror=()=>resolve(null)})}
};
let state=StorageService.load();
function load(){return StorageService.load()}
function save(){StorageService.save(state)}
