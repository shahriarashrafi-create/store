const MAIN_PAGES=new Set(['home','products','cart','profile']);
const navStack=[];
const scrollMemory={};
const routeSnapshotKeys=['query','category','need','sort','productId','checkoutStep'];
function routeSnapshot(){const x={};for(const k of routeSnapshotKeys)x[k]=state[k];return x}
function saveCurrentPosition(){scrollMemory[state.page]=window.scrollY||0}
function hashForState(){
  if(state.page==='product'&&state.productId)return '#product/'+state.productId;
  if(state.page==='products'&&state.category!=='همه')return '#category/'+encodeURIComponent(state.category);
  if(state.page==='products'&&state.need!=='همه')return '#need/'+encodeURIComponent(state.need);
  if(state.page==='search'&&state.query)return '#search/'+encodeURIComponent(state.query);
  return '#'+state.page;
}
function syncHash(){try{history.replaceState(null,'',hashForState())}catch(e){}}
function applyDeepLink(){
  const h=decodeURIComponent((location.hash||'#home').slice(1)); if(!h)return;
  const [kind,...rest]=h.split('/'); const value=rest.join('/');
  if(kind==='product'&&Number(value)){state.page='product';state.productId=Number(value);return}
  if(kind==='category'&&value){state.page='products';state.category=value;state.need='همه';return}
  if(kind==='need'&&value){state.page='products';state.need=value;state.category='همه';return}
  if(kind==='search'){state.page='search';state.query=value||'';return}
  const known=['home','products','cart','profile','favorites','login','checkout','orders','consult','addresses','payments','support','settings','about','coupons','loyalty','notifications','search'];
  if(known.includes(kind)) state.page=kind;
}
function go(page,extra={},options={}){
  saveCurrentPosition();
  if(!options.root && state.page!==page) navStack.push({page:state.page,scroll:window.scrollY||0,snapshot:routeSnapshot()});
  if(options.root) navStack.length=0;
  state.page=page;Object.assign(state,extra);state.sheet=null;save();syncHash();render();
  const y=options.restore?scrollMemory[page]||0:0;requestAnimationFrame(()=>window.scrollTo(0,y));haptic();
}
function goRoot(page){go(page,{}, {root:true,restore:true})}
function back(){
  if(state.sheet){state.sheet=null;document.body.style.overflow='';render();return true}
  if(state.page==='checkout'&&state.checkoutStep>1){state.checkoutStep--;save();render();window.scrollTo(0,0);return true}
  saveCurrentPosition();
  const prev=navStack.pop();
  if(prev){state.page=prev.page;Object.assign(state,prev.snapshot||{});save();syncHash();render();requestAnimationFrame(()=>window.scrollTo(0,prev.scroll||0));return true}
  const fallback={product:'products',favorites:'home',login:'home',checkout:'cart',orders:'profile',consult:'profile',addresses:'profile',payments:'profile',support:'profile',settings:'profile',about:'profile',coupons:'profile',loyalty:'profile',notifications:'home',search:'home'};
  if(fallback[state.page]){state.page=fallback[state.page];save();syncHash();render();requestAnimationFrame(()=>window.scrollTo(0,scrollMemory[state.page]||0));return true}
  return false;
}
window.StoreBack=function(){if(MAIN_PAGES.has(state.page)&&!state.sheet)return false;return back()}
