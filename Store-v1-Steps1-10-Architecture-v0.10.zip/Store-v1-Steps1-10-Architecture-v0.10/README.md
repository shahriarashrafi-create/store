# Store v0.10 — Steps 1–10

This Android ZIP is the consolidated implementation of the approved Store roadmap through Step 10.

- Steps 1–6: storefront, discovery, products, cart, mobile/password login, bank-transfer receipt flow, orders, consultation, loyalty basics.
- Step 7: Store brand identity — clean clinical beauty, tagline **انتخاب درست، مراقبت بهتر**.
- Step 8: approved design tokens (`#0F6B4B`, `#EAF7F1`, `#FAFBF9`, `#1C2B24`), 8pt spacing and consistent components.
- Step 9: central navigation stack, bottom navigation only on four root pages, dedicated search, checkout return after login, checkout steps, scroll/filter restoration and hash deep-link readiness.
- Step 10: modular frontend shared by APK/PWA, Kotlin WebView shell, storage service, API boundary, PWA manifest/service worker, and backend architecture scaffold for Node.js/PostgreSQL/S3-compatible storage.

MVP constraints remain unchanged: **no SMS** and **no online payment gateway**.
