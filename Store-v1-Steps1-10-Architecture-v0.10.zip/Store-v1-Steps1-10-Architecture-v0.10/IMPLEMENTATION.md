# Implementation status — Store steps 1–10

## Brand / design
- Store identity and approved Persian tone.
- Design system tokens centralized in `css/tokens.css`.
- SVG asset system retained; no emoji UI.

## Navigation
- Four root tabs only: Home, Products, Cart, Account.
- Subpages hide bottom navigation.
- Central route stack handles Android back and restores page scroll/filter state.
- Dedicated Search page with recent searches and live suggestions.
- Checkout preserves destination after login.
- Checkout is split into Address → Shipping → Bank transfer.
- Hash routes prepare product/category/need/search deep links.

## Architecture
- Frontend split into `css/` and `js/` modules.
- State persistence goes through `StorageService`; IndexedDB cache API is available.
- `StoreApi` is the future REST boundary.
- PWA manifest + service worker included for web deployment.
- Android wrapper migrated to Kotlin.
- `backend/` records the approved Node.js + PostgreSQL + object-storage target architecture; it is intentionally not connected in this MVP.

## MVP constraints
- Mobile + password login only; no SMS.
- Bank transfer + receipt + manual admin verification; no online gateway.
