# Store v0.45 — Steps 1–40

این بسته ادامه مستقیم v0.30 است و تصمیم‌های تأییدشده قدم‌های ۳۱ تا ۴۰ را روی قابلیت‌های قدم‌های ۱ تا ۳۰ اضافه می‌کند.

## تغییرات اصلی v0.45

- Cart کامل با Variant، قیمت واحد/جمع ردیف، تغییر Variant در Bottom Sheet، کنترل موجودی و Undo حذف
- CartService مرکزی برای add/remove/update/changeVariant/validate/clear
- Summary مالی شفاف: جمع قبل از تخفیف، تخفیف محصول، Coupon، ارسال، صرفه‌جویی و مبلغ نهایی
- Coupon Rule Engine محلی/آماده Backend برای درصدی، مبلغ ثابت و ارسال رایگان؛ اعتبارسنجی نهایی باید سمت Server باشد
- چند آدرس با گیرنده مستقل، آدرس پیش‌فرض، ویرایش/حذف و Snapshot آدرس در Order
- روش‌های ارسال وابسته به شهر/آدرس، ETA تخمینی، Threshold ارسال رایگان و ساختار آماده Shipment چندبخشی
- Checkout سه‌مرحله‌ای: آدرس → ارسال → پرداخت، بدون Bottom Navigation و با حفظ State
- ساخت Draft Order پیش از مرحله پرداخت؛ Cart تا ثبت موفق رسید پاک نمی‌شود
- پرداخت MVP با کارت‌به‌کارت/واریز بانکی، Receipt Picker اندروید، شماره پیگیری و تأیید دستی مدیر
- Success/Error flow دقیق و Idempotent-ready؛ سفارش ناقص از Order Detail قابل تکمیل است
- Orders با فیلتر وضعیت، Order Detail، Timeline، Reorder با قیمت/موجودی فعلی، Tracking scaffold و فاکتور دیجیتال ساده
- PostgreSQL schema آماده برای carts, cart_items, coupons, addresses, shipping_methods, shipments, payment_methods, order_status_events و invoices

## Build

ZIP را در ریشه Repository `store` آپلود کنید. Workflow فعلی GitHub Actions پروژه Android Gradle را پیدا می‌کند و Debug APK را می‌سازد.

- versionCode: 40
- versionName: `v0.45-steps1-40-checkout-orders`
- PWA cache: `store-v040-shell`
- Local storage: `store-v040` با Migration از v0.30 و نسخه‌های قبل

## نکته داده واقعی

اطلاعات کارت مقصد پرداخت، قوانین واقعی Coupon، قیمت/موجودی، هزینه و SLA ارسال، Receipt Storage و وضعیت‌های Admin در این Build به‌صورت Local/Prototype هستند. منبع نهایی این داده‌ها باید Backend و پنل مدیریت باشد. پنل مدیریت کامل طبق Roadmap در قدم ۴۵ ساخته می‌شود.


## v0.45 Final Polish
این نسخه منطق قدم‌های ۱ تا ۴۰ را حفظ می‌کند و ۴۵ اصلاح UI/UX تأییدشده را به‌همراه اصلاح Merge سبد مهمان/حساب، تأیید صریح تغییر قیمت، Offline fallback امن، منبع واقعی Review و Config متمرکز اعمال می‌کند. تصاویر محصول همچنان Placeholder محلی هستند و باید با تصاویر رسمی کاتالوگ جایگزین شوند.
