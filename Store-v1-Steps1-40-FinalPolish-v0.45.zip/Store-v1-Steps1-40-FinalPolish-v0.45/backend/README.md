# Store Backend Scaffold — through Step 40

Target architecture: Node.js REST API + PostgreSQL + object storage.

The schema now anticipates:
- users and optional skin/hair profile
- hierarchical categories and needs
- products with structured description/usage/spec data
- product variants with SKU-level price and stock
- product media gallery
- banners/campaigns
- favorites, moderated reviews and product relations
- carts and cart items
- coupons and redemption records
- multiple customer addresses
- orders with financial and address/shipping snapshots
- order items with SKU/variant snapshots
- shipping methods, shipments and shipment items
- payment methods and private payment receipts
- order status events and invoice snapshots
- loyalty ledger

The current APK/PWA runtime still uses local prototype data. No production authentication, public API, object storage, payment gateway or Admin backend is enabled yet. Price, stock, coupon, shipping and payment validation must become server-authoritative before production launch.
