# Store v0.50 — Steps 1–50 Complete

این بسته ادامه مستقیم `Store-v1-Steps1-40-FinalPolish-v0.45.zip` است و تصمیم‌های تأییدشده قدم‌های ۴۱ تا ۵۰ را روی نسخه نهایی قدم‌های ۱ تا ۴۰ اضافه می‌کند؛ هویت بصری و منطق خرید قبلی حفظ شده است.

## قابلیت‌های اضافه‌شده در v0.50
- Notification Center واقعی داخل اپ با Read/Unread، Badge، تنظیمات اعلان و Deep Link سفارش
- تبدیل رویدادهای واقعی Order/Payment به اعلان محلی و Push-ready Service Worker
- شخصی‌سازی Rule-based و قابل توضیح براساس پروفایل پوست/مو، علاقه‌مندی و فعالیت کاربر
- Campaign Analytics پایه برای Impression/Click و مدل کامل Campaign در PostgreSQL
- API Client کامل‌تر با Timeout، Auth header، خطاهای امن و Catalog hydration از Backend در صورت اتصال
- Backend Node.js + PostgreSQL-ready با Health/Public/Admin endpoints، Rate Limit و Security Headers
- پنل مستقل `Store Admin` برای Dashboard، Orders، Catalog، Campaigns و Audit foundation
- بخش «راهنمای مراقبت» با مقاله، Article Detail، Related Products و نتایج محتوایی در Search
- Runtime error logging محلی + ارسال اختیاری Event به Backend
- QA/static validation tooling، Deployment docs و Launch checklist
- Schema کامل برای notifications, preferences, campaigns, content, admin roles/audit و app events

## نسخه Android
- `versionCode`: 50
- `versionName`: `0.50-steps1-50-complete`
- package/applicationId: `com.store.app` بدون تغییر

## Build
ZIP را مانند قبل در ریشه Repository قرار دهید. Workflow فعلی GitHub می‌تواند پروژه Gradle داخل ZIP را پیدا و APK Debug تولید کند.

برای چک استاتیک پروژه:
```bash
./scripts/validate-project.sh
```

## Backend
Backend در `backend/` قرار دارد. بدون `DATABASE_URL` در حالت Safe Demo اجرا می‌شود؛ با PostgreSQL و اجرای `backend/sql/schema.sql`، Endpointهای خواندنی واقعی فعال می‌شوند. Order write production عمداً تا پیاده‌سازی Transaction اتمیک Fail-closed باقی مانده تا سفارش یا مبلغ جعلی ایجاد نشود.

## Admin
پنل مستقل در `admin/` است و از API مشترک استفاده می‌کند. در Production باید Login واقعی، Role/Permission سمت Server و 2FA جایگزین Token آزمایشی شوند.

## موارد وابسته به Production Environment
این ZIP عمداً داده یا سرویس واقعی را جعل نمی‌کند. تصاویر رسمی کاتالوگ Trust، PostgreSQL Production، Object Storage خصوصی رسیدها، Push Provider، Admin Auth/2FA، Order Transaction نهایی و تنظیمات واقعی ارسال/پرداخت باید در محیط واقعی متصل شوند.
