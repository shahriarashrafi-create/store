const StoreApi={
  get baseUrl(){return window.StoreConfig.api[window.StoreConfig.environment]||''},
  get enabled(){return !!this.baseUrl},
  token(){try{return sessionStorage.getItem('store-api-token')||localStorage.getItem('store-api-token')||''}catch(e){return''}},
  async request(path,options={}){
    if(!this.baseUrl) throw new Error('API_NOT_CONNECTED');
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),Number(options.timeout||8000));
    const headers={Accept:'application/json',...(options.body instanceof FormData?{}:{'Content-Type':'application/json'}),...(options.headers||{})};
    const token=this.token();if(token)headers.Authorization=`Bearer ${token}`;
    try{
      const response=await fetch(this.baseUrl+path,{...options,headers,signal:controller.signal});
      if(!response.ok){const err=new Error('API_'+response.status);err.status=response.status;try{err.payload=await response.json()}catch(e){}throw err}
      if(response.status===204)return null;
      return response.json();
    }catch(e){if(e.name==='AbortError')throw new Error('API_TIMEOUT');throw e}finally{clearTimeout(timeout)}
  },
  health(){return this.request('/health',{timeout:4000})},
  products(){return this.request('/products')},
  product(id){return this.request('/products/'+encodeURIComponent(id))},
  categories(){return this.request('/categories')},
  campaigns(){return this.request('/campaigns')},
  articles(){return this.request('/articles')},
  search(q){return this.request('/search?q='+encodeURIComponent(q||''))},
  orders(){return this.request('/orders')},
  order(id){return this.request('/orders/'+encodeURIComponent(id))},
  notifications(){return this.request('/notifications')},
  checkoutValidate(payload){return this.request('/checkout/validate',{method:'POST',body:JSON.stringify(payload)})},
  createOrder(payload){return this.request('/orders',{method:'POST',body:JSON.stringify(payload)})},
  receiptPresign(payload){return this.request('/payments/receipt/presign',{method:'POST',body:JSON.stringify(payload)})},
  event(payload){if(!this.enabled)return Promise.resolve(null);return this.request('/events',{method:'POST',body:JSON.stringify(payload),timeout:3000}).catch(()=>null)}
};
window.StoreApi=StoreApi;
