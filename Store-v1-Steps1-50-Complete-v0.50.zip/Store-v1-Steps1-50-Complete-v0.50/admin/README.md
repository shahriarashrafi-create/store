# Store Admin v0.50

پنل مدیریت مستقل Store. این پنل عمداً داخل WebView مشتری قرار نگرفته و از API مشترک استفاده می‌کند.

## اجرای محلی
1. Backend را با `DATABASE_URL` و `ADMIN_TOKEN` اجرا کنید.
2. `admin/index.html` را از یک وب‌سرور استاتیک باز کنید.
3. API Base و همان `ADMIN_TOKEN` را در صفحه ورود وارد کنید.

در Production، Token دستی باید با Login واقعی Admin، Role/Permission سمت Backend و 2FA جایگزین شود.
