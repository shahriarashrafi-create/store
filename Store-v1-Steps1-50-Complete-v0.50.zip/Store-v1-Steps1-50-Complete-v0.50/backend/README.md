# Store Backend v0.50

PostgreSQL-ready REST API for Store Steps 41–50.

## Run

```bash
npm install
cp .env.example .env
# export values from .env using your process manager
npm start
```

Without `DATABASE_URL`, the API starts in safe demo mode: health and Admin dashboard work, public catalog endpoints return empty arrays, and transactional writes fail clearly instead of inventing data.

## Main routes

Public: `/api/health`, `/api/products`, `/api/products/:id`, `/api/categories`, `/api/campaigns`, `/api/articles`, `/api/search?q=`.

User/transactional: `/api/notifications`, `/api/checkout/validate`, `/api/orders`, `/api/payments/receipt/presign`, `/api/events`.

Admin: `/api/admin/dashboard`, `/api/admin/orders`, `/api/admin/products`, `/api/admin/campaigns`, `/api/admin/audit` (requires `ADMIN_TOKEN`).

## Production rules
- Run `backend/sql/schema.sql` on PostgreSQL.
- Replace prototype user-token handling with real access/refresh-token auth.
- Implement the order transaction atomically before enabling Production writes.
- Configure private object storage for payment receipts.
- Put Admin behind real login, server-side role/permission checks and preferably 2FA.
- Keep secrets out of ZIP/Git and inject via environment/secret manager.
