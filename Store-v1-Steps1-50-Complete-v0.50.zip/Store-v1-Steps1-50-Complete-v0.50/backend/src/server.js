'use strict';
const http=require('http');
const crypto=require('crypto');
const {URL}=require('url');

const PORT=Number(process.env.PORT||3000);
const ADMIN_TOKEN=String(process.env.ADMIN_TOKEN||'');
const USER_TOKEN=String(process.env.USER_TOKEN||'');
const ALLOWED_ORIGINS=String(process.env.ALLOWED_ORIGINS||'').split(',').map(x=>x.trim()).filter(Boolean);
const BODY_LIMIT=1024*1024;
const rate=new Map();
let pool=null;

if(process.env.DATABASE_URL){
  try{
    const {Pool}=require('pg');
    pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.PGSSL==='require'?{rejectUnauthorized:false}:undefined,max:10});
  }catch(e){console.error('DATABASE_URL is set but pg is not installed:',e.message)}
}

function json(res,status,payload,extra={}){
  const body=JSON.stringify(payload);
  res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','Permissions-Policy':'camera=(), microphone=(), geolocation=()','Content-Security-Policy':"default-src 'none'; frame-ancestors 'none'",...extra});
  res.end(body);
}
function allowOrigin(req,resHeaders){
  const origin=req.headers.origin;
  if(!origin)return resHeaders;
  if(ALLOWED_ORIGINS.length===0||ALLOWED_ORIGINS.includes(origin)){resHeaders['Access-Control-Allow-Origin']=origin;resHeaders['Vary']='Origin';resHeaders['Access-Control-Allow-Headers']='Content-Type, Authorization';resHeaders['Access-Control-Allow-Methods']='GET,POST,PATCH,DELETE,OPTIONS'}
  return resHeaders;
}
function clientKey(req){return String(req.socket.remoteAddress||'unknown')}
function limited(req){const key=clientKey(req),now=Date.now(),windowMs=60000,max=120;const x=rate.get(key)||{at:now,count:0};if(now-x.at>windowMs){x.at=now;x.count=0}x.count++;rate.set(key,x);return x.count>max}
function tokenFrom(req){const h=String(req.headers.authorization||'');return h.startsWith('Bearer ')?h.slice(7):''}
function requireAdmin(req,res){if(!ADMIN_TOKEN||!crypto.timingSafeEqual(Buffer.from(tokenFrom(req).padEnd(ADMIN_TOKEN.length,'\0').slice(0,ADMIN_TOKEN.length)),Buffer.from(ADMIN_TOKEN))) {json(res,401,{error:'UNAUTHORIZED_ADMIN'});return false}return true}
function requireUser(req,res){if(!USER_TOKEN)return true;if(tokenFrom(req)!==USER_TOKEN){json(res,401,{error:'UNAUTHORIZED'});return false}return true}
function parseJson(req){return new Promise((resolve,reject)=>{let raw='',size=0;req.on('data',c=>{size+=c.length;if(size>BODY_LIMIT){reject(Object.assign(new Error('BODY_TOO_LARGE'),{status:413}));req.destroy();return}raw+=c});req.on('end',()=>{if(!raw)return resolve({});try{resolve(JSON.parse(raw))}catch(e){reject(Object.assign(new Error('INVALID_JSON'),{status:400}))}});req.on('error',reject)})}
async function query(sql,args=[]){if(!pool)throw Object.assign(new Error('DATABASE_NOT_CONFIGURED'),{status:503});return pool.query(sql,args)}
function mapProduct(r){return {id:Number(r.id),sku:r.sku,name:r.name,brand:r.brand,price:Number(r.price||0),oldPrice:Number(r.old_price||r.price||0),stock:Number(r.stock||0),active:r.active,createdAt:r.created_at,shortDescription:r.short_description,description:r.description,features:r.features||[],skinTypes:r.skin_types||[],hairTypes:r.hair_types||[],ingredients:r.ingredients||[],usage:r.usage_json||{},warnings:r.warnings||[]}}

async function publicGet(path,url,res){
  if(path==='/api/health')return json(res,200,{service:'Store API',status:'ok',database:!!pool,version:'0.50'});
  if(path==='/api/products'){
    if(!pool)return json(res,200,[]);
    const r=await query(`SELECT * FROM products WHERE active=TRUE ORDER BY created_at DESC LIMIT 200`);return json(res,200,r.rows.map(mapProduct));
  }
  if(/^\/api\/products\/\d+$/.test(path)){
    if(!pool)return json(res,404,{error:'NOT_FOUND'});const id=Number(path.split('/').pop());const r=await query('SELECT * FROM products WHERE id=$1 AND active=TRUE',[id]);if(!r.rowCount)return json(res,404,{error:'NOT_FOUND'});return json(res,200,mapProduct(r.rows[0]));
  }
  if(path==='/api/categories'){
    if(!pool)return json(res,200,[]);const r=await query('SELECT id,name,slug,image_key,parent_id,sort_order,active,description FROM categories WHERE active=TRUE ORDER BY sort_order,id');return json(res,200,r.rows.map(x=>({id:x.id,name:x.name,slug:x.slug,image:x.image_key,parentId:x.parent_id,order:x.sort_order,active:x.active,description:x.description})));
  }
  if(path==='/api/campaigns'){
    if(!pool)return json(res,200,[]);const r=await query(`SELECT * FROM campaigns WHERE active=TRUE AND (starts_at IS NULL OR starts_at<=now()) AND (ends_at IS NULL OR ends_at>=now()) ORDER BY priority DESC,id DESC`);return json(res,200,r.rows.map(x=>({id:x.campaign_key,type:'campaign',title:x.title,subtitle:x.subtitle,image:x.image_key,ctaText:x.cta_text,active:x.active,priority:x.priority,startAt:x.starts_at,endAt:x.ends_at,target:x.target_rules||{page:'products'}})));
  }
  if(path==='/api/articles'){
    if(!pool)return json(res,200,[]);const r=await query(`SELECT id,slug,title,excerpt,cover_object_key,category,tags,related_product_ids,author,published_at FROM articles WHERE status='published' AND (published_at IS NULL OR published_at<=now()) ORDER BY published_at DESC NULLS LAST,id DESC LIMIT 100`);return json(res,200,r.rows);
  }
  if(path==='/api/search'){
    const q=String(url.searchParams.get('q')||'').trim();if(!q||!pool)return json(res,200,{products:[],articles:[]});const term=`%${q}%`;const [p,a]=await Promise.all([query(`SELECT * FROM products WHERE active=TRUE AND (name ILIKE $1 OR brand ILIKE $1 OR sku ILIKE $1) ORDER BY created_at DESC LIMIT 30`,[term]),query(`SELECT id,slug,title,excerpt,category,tags,published_at FROM articles WHERE status='published' AND (title ILIKE $1 OR excerpt ILIKE $1) ORDER BY published_at DESC NULLS LAST LIMIT 20`,[term])]);return json(res,200,{products:p.rows.map(mapProduct),articles:a.rows});
  }
  return false;
}

async function userRoutes(req,path,url,res){
  if(path==='/api/notifications'&&req.method==='GET'){
    if(!requireUser(req,res))return true;if(!pool)return json(res,200,[]),true;const userId=Number(url.searchParams.get('user_id')||0);if(!userId)return json(res,400,{error:'USER_ID_REQUIRED'}),true;const r=await query('SELECT * FROM notifications WHERE user_id=$1 AND (expires_at IS NULL OR expires_at>now()) ORDER BY created_at DESC LIMIT 100',[userId]);json(res,200,r.rows);return true;
  }
  if(path==='/api/checkout/validate'&&req.method==='POST'){
    if(!requireUser(req,res))return true;const body=await parseJson(req);if(!Array.isArray(body.items)||!body.items.length){json(res,400,{error:'EMPTY_CART'});return true}if(!pool){json(res,503,{error:'DATABASE_NOT_CONFIGURED'});return true}const ids=[...new Set(body.items.map(x=>Number(x.product_id)).filter(Boolean))];const r=await query('SELECT id,price,stock,active FROM products WHERE id=ANY($1::bigint[])',[ids]);const map=new Map(r.rows.map(x=>[Number(x.id),x]));const issues=[];let subtotal=0;for(const item of body.items){const p=map.get(Number(item.product_id));if(!p||!p.active){issues.push({product_id:item.product_id,type:'inactive'});continue}if(Number(item.quantity)>Number(p.stock))issues.push({product_id:item.product_id,type:'stock',available:Number(p.stock)});subtotal+=Number(p.price)*Number(item.quantity)}json(res,200,{valid:issues.length===0,issues,subtotal,server_time:new Date().toISOString()});return true;
  }
  if(path==='/api/orders'&&req.method==='POST'){
    if(!requireUser(req,res))return true;if(!pool){json(res,503,{error:'DATABASE_NOT_CONFIGURED'});return true}json(res,501,{error:'ORDER_WRITE_REQUIRES_TRANSACTIONAL_SERVICE',message:'Use the production order service transaction before launch.'});return true;
  }
  if(path==='/api/payments/receipt/presign'&&req.method==='POST'){
    if(!requireUser(req,res))return true;json(res,501,{error:'OBJECT_STORAGE_NOT_CONFIGURED'});return true;
  }
  if(path==='/api/events'&&req.method==='POST'){
    const body=await parseJson(req);if(pool){await query('INSERT INTO app_events(event_type,event_name,metadata) VALUES($1,$2,$3::jsonb)',['client',String(body.event||'unknown'),JSON.stringify(body)]).catch(()=>{})}json(res,202,{accepted:true});return true;
  }
  return false;
}

async function adminRoutes(req,path,url,res){
  if(!path.startsWith('/api/admin/'))return false;
  if(!requireAdmin(req,res))return true;
  if(path==='/api/admin/dashboard'&&req.method==='GET'){
    if(!pool){json(res,200,{mode:'demo',sales_today:0,orders_today:0,pending_payments:0,low_stock:0});return true}
    const r=await query(`SELECT (SELECT COALESCE(sum(total),0) FROM orders WHERE created_at::date=current_date) sales_today,(SELECT count(*) FROM orders WHERE created_at::date=current_date) orders_today,(SELECT count(*) FROM orders WHERE payment_status='pending_confirmation') pending_payments,(SELECT count(*) FROM products WHERE active=TRUE AND stock<=3) low_stock`);json(res,200,r.rows[0]);return true;
  }
  if(path==='/api/admin/orders'&&req.method==='GET'){
    if(!pool){json(res,200,[]);return true}const r=await query('SELECT id,status,total,payment_status,created_at FROM orders ORDER BY created_at DESC LIMIT 200');json(res,200,r.rows);return true;
  }
  if(path==='/api/admin/products'&&req.method==='GET'){
    if(!pool){json(res,200,[]);return true}const r=await query('SELECT id,sku,name,brand,price,old_price,stock,active,created_at FROM products ORDER BY id DESC LIMIT 500');json(res,200,r.rows);return true;
  }
  if(path==='/api/admin/campaigns'&&req.method==='GET'){
    if(!pool){json(res,200,[]);return true}const r=await query('SELECT * FROM campaigns ORDER BY created_at DESC LIMIT 200');json(res,200,r.rows);return true;
  }
  if(path==='/api/admin/audit'&&req.method==='GET'){
    if(!pool){json(res,200,[]);return true}const r=await query('SELECT * FROM admin_audit_logs ORDER BY created_at DESC LIMIT 200');json(res,200,r.rows);return true;
  }
  json(res,404,{error:'ADMIN_ROUTE_NOT_FOUND'});return true;
}

const server=http.createServer(async(req,res)=>{
  const cors=allowOrigin(req,{});
  Object.entries(cors).forEach(([k,v])=>res.setHeader(k,v));
  if(req.method==='OPTIONS'){res.writeHead(204);return res.end()}
  if(limited(req))return json(res,429,{error:'RATE_LIMITED'});
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`),path=url.pathname.replace(/\/$/,'')||'/';
  try{
    if(req.method==='GET'){const handled=await publicGet(path,url,res);if(handled!==false)return}
    if(await userRoutes(req,path,url,res)!==false)return;
    if(await adminRoutes(req,path,url,res)!==false)return;
    json(res,404,{error:'NOT_FOUND'});
  }catch(e){console.error(new Date().toISOString(),req.method,path,e.message);json(res,e.status||500,{error:e.message==='DATABASE_NOT_CONFIGURED'?'DATABASE_NOT_CONFIGURED':'INTERNAL_ERROR'})}
});

server.listen(PORT,()=>console.log(`Store API v0.50 on :${PORT} (${pool?'postgres':'local/demo'} mode)`));
process.on('SIGTERM',async()=>{try{if(pool)await pool.end()}finally{server.close(()=>process.exit(0))}});
