#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS="$ROOT/app/src/main/assets"
for f in "$ASSETS"/js/*.js "$ROOT/backend/src/server.js" "$ROOT/admin/admin.js"; do node --check "$f"; done
python - <<'PY' "$ROOT"
import sys, json, xml.etree.ElementTree as ET
from pathlib import Path
root=Path(sys.argv[1])
json.loads((root/'app/src/main/assets/manifest.webmanifest').read_text())
ET.parse(root/'app/src/main/AndroidManifest.xml')
for p in (root/'app/src/main/assets/assets').rglob('*.svg'): ET.parse(p)
print('JSON/XML/SVG OK')
PY
grep -q "versionCode 50" "$ROOT/app/build.gradle"
grep -q "0.50-steps1-50-complete" "$ROOT/app/build.gradle"
grep -q "steps41-50.js" "$ASSETS/index.html"
grep -q "steps41-50.css" "$ASSETS/index.html"
echo "Store v0.50 static validation: PASS"
