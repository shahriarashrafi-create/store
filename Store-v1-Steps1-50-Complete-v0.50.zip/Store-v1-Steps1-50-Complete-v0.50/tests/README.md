# Store QA — Step 48

Release checklist must cover:
- Home → Products → Product Detail → Cart → Login → Address → Shipping → Order → Receipt → Orders.
- Cart quantity, variant, remove/undo, guest/account merge, price and stock changes.
- Checkout back/forward, offline, refresh, invalid address, free shipping, coupon.
- Receipt retry/rejection/duplicate prevention.
- Responsive widths 360/390/412/480 + tablet, Android font scale and keyboard open.
- Android WebView, Chrome Android, installed PWA and desktop Chrome.
- Security checks: XSS, SQLi, broken access control/IDOR, upload abuse, admin authorization, rate limiting.
- P0/P1 bugs must be zero before Release.

Run `../scripts/validate-project.sh` for static checks. Production E2E/API tests require a running backend and are intentionally not faked in this ZIP.
