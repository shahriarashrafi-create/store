# Store v0.2 — Steps 1 to 6

نسخه اجرایی اولیه Store برای تست APK در GitHub Actions.

این نسخه تصمیم‌های قدم‌های ۱ تا ۶ را به‌صورت رابط قابل اجرا پیاده می‌کند:
- فروشگاه فارسی RTL و Mobile-first
- دسته‌بندی و خرید بر اساس نیاز
- جست‌وجو و فیلتر
- صفحه محصول و علاقه‌مندی
- سبد خرید
- ورود آزمایشی با شماره موبایل + رمز عبور (بدون SMS)
- آدرس، ارسال و ثبت سفارش
- پرداخت کارت‌به‌کارت آزمایشی + انتخاب فایل رسید
- وضعیت سفارش و خرید مجدد
- باشگاه مشتریان پایه و درخواست مشاوره

## مهم
این نسخه Backend واقعی ندارد و داده‌ها داخل LocalStorage دستگاه نگهداری می‌شوند. قیمت‌ها، محصولات، شماره کارت و اطلاعات پرداخت نمونه/آزمایشی هستند و برای فروش واقعی استفاده نشوند.


## v0.3 fix
- Removed the HTML splash screen so the app opens directly on Home.
- Added compatibility fallbacks for older Android WebView JavaScript engines.
- Bumped Android versionCode to 3.
